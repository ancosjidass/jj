"""1.19.6: the sandbox server (sandbox_server/server.py) + the `.sb` client (modules/sandbox.py): run / write / edit / zip upload / download, jail, token, AI loop."""
from __future__ import annotations

import asyncio
import importlib
import io
import json
import os
import pathlib
import sys
import zipfile

import pytest
from aiohttp.test_utils import TestServer

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "sandbox_server"))


def load_server(tmp_path, monkeypatch):
    monkeypatch.setenv("SANDBOX_TOKEN", "t" * 24)
    monkeypatch.setenv("SANDBOX_ROOT", str(tmp_path / "ws"))
    monkeypatch.setenv("SANDBOX_ISOLATE", "0")                # one unix user: the folders of pytest are not traversable by other users (the isolation has its own test file)
    import server
    return importlib.reload(server)


def test_server_and_box_roundtrip(tmp_path, monkeypatch):
    server = load_server(tmp_path, monkeypatch)
    from modules import sandbox as S

    async def run():
        srv = TestServer(server.make_app())
        await srv.start_server()
        monkeypatch.setenv("SANDBOX_URL", str(srv.make_url("")).rstrip("/"))
        monkeypatch.setenv("SANDBOX_TOKEN", "t" * 24)
        b = S.Box("u1")
        try:
            r = await b.sh("echo hi; echo err >&2; exit 3")
            assert r["code"] == 3 and r["out"].strip() == "hi" and "err" in r["err"]
            assert "SANDBOX_TOKEN" not in (await b.sh("env"))["out"]                       # the secret never reaches a command
            await b.write("app/main.py", "print('v1')\n")
            await b.edit("app/main.py", "v1", "v2")
            assert (await b.read("app/main.py"))["text"] == "print('v2')\n"
            assert "v2" in (await b.sh("python3 app/main.py"))["out"]
            with pytest.raises(RuntimeError, match="exactly once"):
                await b.edit("app/main.py", "zzz", "a")
            with pytest.raises(RuntimeError, match="leaves the workspace"):
                await b.read("../../etc/passwd")
            await b.write("/etc/evil", "x")                                                 # an absolute path is taken inside the workspace
            assert (await b.read("etc/evil"))["text"] == "x" and not pathlib.Path("/etc/evil").exists()
            await b.sh("ln -s /etc/passwd link")                                              # a symlink out of the workspace is refused too
            with pytest.raises(RuntimeError, match="leaves the workspace"):
                await b.read("link")
            slow = await b.sh("sleep 30", timeout=1)
            assert slow["timed_out"]
            # a zip goes in (unzipped), a changed file comes out, the whole workspace comes out as a zip
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w") as zf:
                zf.writestr("proj/a.txt", "A")
            res = await b.upload("proj.zip", buf.getvalue(), extract=True)
            assert res["extracted"] == 1 and (await b.read("proj/a.txt"))["text"] == "A"
            evil = io.BytesIO()
            with zipfile.ZipFile(evil, "w") as zf:
                zf.writestr("../../escape.txt", "x")
            with pytest.raises(RuntimeError, match="leaves the workspace"):
                await b.upload("evil.zip", evil.getvalue(), extract=True)
            await b.upload("pic.gif", b"GIF89a-bytes")
            blob, name = await b.download("pic.gif")
            assert blob == b"GIF89a-bytes" and name == "pic.gif"
            blob, name = await b.download(".")
            assert name.endswith(".zip") and {"proj/a.txt", "app/main.py", "pic.gif"} <= set(zipfile.ZipFile(io.BytesIO(blob)).namelist())
            await b.reset()
            assert (await b.ls("."))["items"] == []
            # wrong token
            monkeypatch.setenv("SANDBOX_TOKEN", "x" * 24)
            with pytest.raises(RuntimeError, match="401"):
                await S.Box("u1").sh("id")
        finally:
            await srv.close()

    asyncio.run(run())


def test_parse_action_accepts_fences_and_prose():
    from modules import sandbox as S
    assert S.parse_action('```json\n{"do":[{"t":"ls"}]}\n```')["do"][0]["t"] == "ls"
    assert S.parse_action('Sure! {"say":"x","done":"ok"} bye')["done"] == "ok"
    assert S.parse_action("no json here") is None
    assert S.parse_action('{"unrelated": 1}') is None


def test_agent_loop_runs_the_ai_plan_and_sends_the_file(tmp_path, monkeypatch):
    server = load_server(tmp_path, monkeypatch)
    from modules import sandbox as S
    from tests.test_v1170 import make_db

    answers = iter([
        json.dumps({"say": "writing", "do": [{"t": "write", "path": "hello.py", "content": "print(6*7)\n"}, {"t": "sh", "cmd": "python3 hello.py"}, {"t": "send", "path": "hello.py"}]}),
        "not json at all",
        json.dumps({"done": "تمام شد: خروجی ۴۲"}),
    ])
    seen = []

    class Msg:
        id = 5
        media = None
        is_reply = False

    class Ev:
        chat_id = 77
        id = 5
        message = Msg()
        is_reply = False
        edits = []

        async def edit(self, text, **kw):
            self.edits.append(text)

        async def reply(self, text, **kw):
            seen.append(text)

    class Client:
        sent = []
        _hapoyi_me_id = 1

        def on(self, builder=None):
            def reg(fn):
                self.handler = fn
                return fn
            return reg

        async def send_file(self, chat, f, **kw):
            self.sent.append((chat, f.name, f.read()))

    async def ask(messages, **kw):
        seen.append(messages[-1]["content"])
        return next(answers), None

    async def run():
        srv = TestServer(server.make_app())
        await srv.start_server()
        monkeypatch.setenv("SANDBOX_URL", str(srv.make_url("")).rstrip("/"))
        monkeypatch.setenv("SANDBOX_TOKEN", "t" * 24)
        c = Client()
        c._hapoyi_ask_ai = ask
        c._hapoyi_is_owner = True
        S.setup(c, await make_db())
        ev = Ev()
        ev.pattern_match = type("M", (), {"group": lambda self, i: "یک فایل بساز که ۶ ضرب در ۷ را چاپ کند"})()
        try:
            await c.handler(ev)
        finally:
            await srv.close()
        assert c.sent == [(77, "hello.py", b"print(6*7)\n")]
        assert any("42" in s for s in seen)                      # the AI saw the real output of the command
        assert "تمام شد" in ev.edits[-1]

    asyncio.run(run())


def test_deploy_gives_a_preview_link_that_proxies_and_stops(tmp_path, monkeypatch):
    server = load_server(tmp_path, monkeypatch)
    import aiohttp
    from modules import sandbox as S

    async def go():
        srv = TestServer(server.make_app())
        await srv.start_server()
        base = str(srv.make_url("")).rstrip("/")
        monkeypatch.setenv("SANDBOX_URL", base)
        monkeypatch.setenv("SANDBOX_TOKEN", "t" * 24)
        b = S.Box("u7")
        try:
            await b.write("site/index.html", "<h1>hello preview</h1>")
            await b.write("site/app.js", "console.log(1)")
            res = await b.deploy("cd site && python3 -m http.server $PORT --bind 127.0.0.1", "site")
            assert res["ready"] and res["path"].startswith("/p/")
            async with aiohttp.ClientSession() as s:
                async with s.get(base + res["path"]) as r:                      # no Authorization header: the secret path is the key
                    assert r.status == 200 and "hello preview" in await r.text()
                    cookie = r.cookies.get("sbp")
                    assert cookie is not None
                async with s.get(base + "/app.js", cookies={"sbp": cookie.value}) as r:  # an absolute asset path of the page works through the cookie
                    assert r.status == 200 and "console.log" in await r.text()
                async with s.get(base + "/exec") as r:                          # the API stays closed without the token
                    assert r.status == 401
                async with s.get(base + "/p/not-a-token/") as r:
                    assert r.status == 404
            apps = (await b.apps())["apps"]
            assert [a["name"] for a in apps] == ["site"]
            assert (await b.stop_app("site"))["stopped"] == 1
            async with aiohttp.ClientSession() as s:
                async with s.get(base + res["path"]) as r:
                    assert r.status == 404
            bad = await b.deploy("exit 3", "broken")                          # an app that dies at once is reported with its log, not given a link
            assert not bad["ready"] and bad["exited"] == 3
            assert (await b.apps())["apps"] == []
        finally:
            await b.reset()
            await srv.close()
    asyncio.run(go())
