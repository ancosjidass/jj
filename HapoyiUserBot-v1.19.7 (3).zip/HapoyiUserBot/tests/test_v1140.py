"""1.14.0: AI gateway fail-over, pacing, backup/restore, shortcuts, group guard helpers."""
from __future__ import annotations

import asyncio
import pathlib
import sqlite3
import sys
import tempfile
import time
from types import SimpleNamespace

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

import pytest  # noqa: E402

from core.database import Database  # noqa: E402
from core.guard import install_handler_guard  # noqa: E402
from tests.test_regressions import ADMIN, FakeClient, FakeEvent, _dispatch, _find  # noqa: E402


# ------------------------------------------------------------------ AI gateway
class FakeResp:
    def __init__(self, status, body, headers=None):
        self.status, self._body, self.headers = status, body, headers or {}

    async def text(self):
        return self._body

    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False


class FakeSession:
    def __init__(self, script):
        self.script, self.calls = script, []

    def post(self, url, json=None, headers=None, **kw):
        self.calls.append(json["model"])
        return self.script[json["model"]]


def _chain():
    from services.ai import Entry
    return [Entry("groq", "a", "http://x", "k"), Entry("groq", "b", "http://x", "k"), Entry("nvidia", "c", "http://x", "k")]


def test_ai_chain_loading_needs_keys():
    from services import ai

    env = {"AI_CHAIN": "groq:m1,groq:m2,nvidia:m3,openrouter:free,custom:z", "GROQ_API_KEY": "g", "OPENROUTER_API_KEY": "o"}
    names = [e.name for e in ai.load_chain(env)]
    assert names == ["groq:m1", "groq:m2", "openrouter:free"]  # nvidia has no key, custom has no base
    assert ai.load_chain({}) == []


def test_ai_daily_quota_parks_entry_and_falls_over_then_recovers():
    from services import ai

    ai.PARKED.clear()
    ok = '{"choices":[{"message":{"content":"<think>x</think> سلام"}}]}'
    sess = FakeSession({"a": FakeResp(429, '{"error":"Rate limit reached for requests per day (RPD)"}'),
                        "b": FakeResp(200, ok), "c": FakeResp(200, ok)})

    async def run():
        text, who = await ai.chat([{"role": "user", "content": "hi"}], chain=_chain(), session=sess)
        assert (text, who) == ("سلام", "groq:b")
        assert ai.PARKED["groq:a"][0] > time.time() + 60  # parked until the daily reset
        await ai.chat([{"role": "user", "content": "hi"}], chain=_chain(), session=sess)
        assert sess.calls == ["a", "b", "b"]  # 'a' is not asked again while parked
        # every entry out of quota -> AIUnavailable carries the earliest reset
        sess2 = FakeSession({"b": FakeResp(429, "", {"retry-after": "120"}), "c": FakeResp(401, "bad key")})
        with pytest.raises(ai.AIUnavailable) as e:
            await ai.chat([{"role": "user", "content": "x"}], chain=_chain(), session=sess2)
        assert time.time() < e.value.reset_at
        # the next day: parked entries are tried again
        ai.PARKED["groq:a"] = (time.time() - 1, "daily quota")
        sess3 = FakeSession({"a": FakeResp(200, ok)})
        assert (await ai.chat([{"role": "user", "content": "x"}], chain=_chain(), session=sess3))[1] == "groq:a"

    asyncio.run(run())
    ai.PARKED.clear()


def test_ai_classify_and_midnight():
    from services import ai

    now = 1_800_000_000.0
    until, why = ai.classify(429, {}, "Limit: 1000 requests per day", now)
    assert why == "daily quota" and until == ai.next_utc_midnight(now) and until > now
    assert ai.classify(429, {"retry-after": "30"}, "", now)[0] == now + 35
    assert ai.classify(429, {}, "Please try again in 2m10s.", now)[0] == pytest.approx(now + 135)
    assert ai.classify(401, {}, "", now)[1].startswith("key")


def test_ai_commands_quota_and_not_configured(monkeypatch):
    from modules import ai_tools
    from services import ai
    from tests.test_v190 import Env, _db

    async def run():
        db = await _db()
        c = Env(ADMIN).c
        c._hapoyi_kind = "licensed"
        monkeypatch.setenv("AI_DAILY_PER_ACCOUNT", "1")
        ai_tools.setup(c, db)
        monkeypatch.setattr(ai, "load_chain", lambda env=None: [])
        ev = FakeEvent(c, ".ask hi")
        ev.edit = lambda t, **k: _rec(ev, t)
        ev.replies = []
        await _dispatch(c, "ask", ev)
        assert "کلید AI" in ev.replies[-1]  # not configured: quota is refunded
        monkeypatch.setattr(ai, "chat", lambda *a, **k: _ret(("جواب", "groq:a")))
        ev2 = FakeEvent(c, ".ask hi")
        ev2.edit = lambda t, **k: _rec(ev2, t)
        await _dispatch(c, "ask", ev2)
        assert "جواب" in ev2.replies[-1]
        ev3 = FakeEvent(c, ".ask again")
        ev3.edit = lambda t, **k: _rec(ev3, t)
        await _dispatch(c, "ask", ev3)
        assert "تموم شد" in ev3.replies[-1] and "فردا" in ev3.replies[-1]  # per-account daily cap

    asyncio.run(run())


async def _rec(ev, t):
    ev.replies.append(t)


async def _ret(v):
    return v


# ------------------------------------------------------------------ pacing
def test_pacer_bursts_then_slows_and_pauses_on_floodwait():
    from core.throttle import Pacer

    p = Pacer()
    waits = [p.delay_for(5, "private", False, 100.0) for _ in range(12)]
    assert waits[0] == 0 and waits[5] == 0 and waits[11] > 0  # burst of 6, then ~1 msg/s
    assert p.delay_for(6, "private", False, 100.0) == 0  # another chat is independent
    p.paused_until = 110.0
    assert p.delay_for(7, "private", False, 100.0) >= 10


# ------------------------------------------------------------------ backup / restore
def test_restore_replaces_shared_tables_and_keeps_newer_and_control_tables():
    from modules.backup_tools import validate_backup

    async def run():
        d = tempfile.mkdtemp()
        live = Database(f"{d}/live.db", control=True)
        await live.connect()
        await live.set_kv("k", "OLD")
        await live.execute("CREATE TABLE newer_table (a TEXT)")
        await live.execute("INSERT INTO newer_table VALUES ('keep')")
        await live.execute("INSERT INTO licenses(id) VALUES (1)") if False else None
        bk = Database(f"{d}/bk.db")
        await bk.connect()
        await bk.set_kv("k", "FROM_BACKUP")
        await bk.set_kv("only_in_backup", "1")
        await bk.close()
        assert validate_backup(f"{d}/bk.db") is None
        open(f"{d}/junk.db", "wb").write(b"not a database at all" * 50)
        assert validate_backup(f"{d}/junk.db") is not None
        tables, rows = await live.restore_from(f"{d}/bk.db")
        assert tables >= 1 and rows >= 2
        assert await live.get_kv("k") == "FROM_BACKUP" and await live.get_kv("only_in_backup") == "1"
        assert (await live.fetchone("SELECT a FROM newer_table"))["a"] == "keep"

    asyncio.run(run())


# ------------------------------------------------------------------ shortcuts
def test_shortcuts_steps_aliases_and_disable():
    from modules import shortcuts
    from tests.test_v190 import Env, _db

    assert shortcuts.parse_steps("mute 10m ;; sleep 3 ;; .unmute") == [".mute 10m", "sleep 3", ".unmute"]
    assert shortcuts.command_name(".Ban @x") == "ban"

    async def run():
        db = await _db()
        env = Env(ADMIN)
        c = env.c
        install_handler_guard(c)
        await shortcuts.setup(c, db)
        # disable `mute` in this chat only
        ev = FakeEvent(c, ".disable mute", chat_id=-1001)
        await _dispatch(c, "disable_cmd", ev)
        assert "غیرفعال شد" in ev.replies[0]
        probe_here = FakeEvent(c, ".mute 5m", chat_id=-1001)
        probe_there = FakeEvent(c, ".mute 5m", chat_id=-1002)
        assert c._hapoyi_cmd_blocked(probe_here) and not c._hapoyi_cmd_blocked(probe_there)
        assert not c._hapoyi_cmd_blocked(FakeEvent(c, ".enable mute", chat_id=-1001))  # protected
        await _dispatch(c, "disable_cmd", FakeEvent(c, ".enable mute", chat_id=-1001))
        assert not c._hapoyi_cmd_blocked(probe_here)
        # persian alias: `.بن @x` -> deletes the message, sends `.ban @x`
        a = FakeEvent(c, ".بن @x", chat_id=-1001)
        await _dispatch(c, "alias_runner", a)
        assert a.deleted and env.sent[-1][1] == ".ban @x"
        # normal ascii commands are ignored by the alias runner
        n = FakeEvent(c, ".ban @x", chat_id=-1001)
        await _dispatch(c, "alias_runner", n)
        assert not n.deleted
        # macro
        m = FakeEvent(c, ".macro add quiet mute 10m ;; sleep 0 ;; unmute", chat_id=-1001)
        await _dispatch(c, "macro", m)
        assert "ذخیره شد" in m.replies[0]
        r = FakeEvent(c, ".m quiet", chat_id=-1001)
        await _dispatch(c, "macro", r)
        assert [x[1] for x in env.sent[-2:]] == [".mute 10m", ".unmute"]

    asyncio.run(run())


def test_captcha_question_and_delmes_pattern():
    from modules import admin, groupguard

    q, ans = groupguard.make_question()
    a, b = (int(x) for x in q.split(" + "))
    assert ans == a + b
    c = FakeClient(perms=ADMIN)
    install_handler_guard(c)
    admin.setup(c, None)
    b_, _ = _find(c, "purge")
    for text in (".delmes 50", ".purge 50", ".delmes"):
        assert b_.pattern(text), text
