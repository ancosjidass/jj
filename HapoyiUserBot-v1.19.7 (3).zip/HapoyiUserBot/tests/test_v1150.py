"""1.15.0: AI guide (knowledge routing, owner notes, smart helper signals) and the YouTube/Instagram/TikTok downloader."""
from __future__ import annotations

import asyncio
import re
import pathlib
import sys
import tempfile
import types
from types import SimpleNamespace

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from services import knowledge as K  # noqa: E402
from tests.test_regressions import FakeClient, FakeEvent, _dispatch  # noqa: E402
from utils import dl as D  # noqa: E402


# ------------------------------------------------------------------ routing: meaning, not keywords
def test_sections_exist_and_cover_new_features():
    keys = set(K.sections())
    assert {"power", "personal", "plus", "ai", "dl"} <= keys
    assert {"later", "every", "remind"} <= set(K.section_commands("power")) | set(K.section_commands("personal"))
    assert {"guide", "aiguide", "aiknow", "dl"} <= K.known_commands()


def test_local_scoring_finds_schedule_in_several_languages():
    for q in ("چجوری یه پیام رو زمان بندی کنم؟", "how do I schedule a message", "تایم مسیج چطوره", "send later please"):
        top = K.score_sections(q)[0][0]
        assert top == "power", (q, K.score_sections(q))
    assert K.score_sections("تایمر ۵ دقیقه بذار")[0][0] == "plus"
    assert K.score_sections("از اینستا ویدیو دانلود کنم")[0][0] == "dl"


def test_normalisation_handles_arabic_letters_and_zwnj():
    assert K.norm("زمان‌بندي  كنم") == "زمان بندی کنم"
    assert K.norm("۱۲۳") == "123"


class Script:
    """ask_fn double: returns the scripted answers in order and remembers the prompts."""

    def __init__(self, *answers):
        self.answers, self.calls = list(answers), []

    async def __call__(self, messages, *, max_tokens=700, temperature=0.5):
        self.calls.append(messages)
        out = self.answers.pop(0)
        return (out, None) if not isinstance(out, tuple) else out


def test_general_question_is_a_plain_single_call(tmp_path):
    ask = Script("پایتخت فرانسه پاریسه")
    out, err = asyncio.run(K.smart_answer("پایتخت فرانسه کجاست؟", ask, store=K.KnowledgeStore(tmp_path / "k.json")))
    assert out and err is None and len(ask.calls) == 1
    assert "DOCS" not in ask.calls[0][0]["content"]  # no manual stuffed into an unrelated question


def test_confident_bot_question_uses_docs_in_one_call(tmp_path):
    ask = Script("از .later استفاده کن")
    out, _ = asyncio.run(K.smart_answer("چجوری میتونم یه پیام رو زمان بندی کنم؟ دستورش چیه", ask, store=K.KnowledgeStore(tmp_path / "k.json")))
    assert out and len(ask.calls) == 1
    system = ask.calls[0][0]["content"]
    assert "=== DOCS ===" in system and ".later" in system


def test_unknown_language_goes_through_the_router(tmp_path):
    ask = Script('{"about_bot": true, "sections": ["power", "nonexistent"]}', "cevap")
    out, _ = asyncio.run(K.smart_answer("Bir mesajı nasıl zamanlayabilirim, bu botta komut ne?", ask, store=K.KnowledgeStore(tmp_path / "k.json")))
    assert out == "cevap" and len(ask.calls) == 2
    assert "power:" in ask.calls[0][0]["content"]  # router saw the map of the bot
    assert ".later" in ask.calls[1][0]["content"]  # answering call got the routed section only


def test_router_can_say_not_about_bot(tmp_path):
    ask = Script('{"about_bot": false, "sections": []}', "عمومی")
    out, _ = asyncio.run(K.smart_answer("این بات چقدر قدیمیه؟", ask, store=K.KnowledgeStore(tmp_path / "k.json")))
    assert out == "عمومی" and "DOCS" not in ask.calls[1][0]["content"]


def test_guide_force_always_uses_docs_and_router_failure_is_not_fatal(tmp_path):
    ask = Script((None, "⏳ سهمیه"), "جواب")
    out, err = asyncio.run(K.smart_answer("سلام", ask, force=True, store=K.KnowledgeStore(tmp_path / "k.json")))
    assert out == "جواب" and err is None


def test_quota_error_is_returned_to_the_user(tmp_path):
    ask = Script((None, "⏳ سهمیهٔ امروز تموم شد"), (None, "⏳ سهمیهٔ امروز تموم شد"))  # router and answer both hit the quota
    out, err = asyncio.run(K.smart_answer("دستور تایمر چیه", ask, store=K.KnowledgeStore(tmp_path / "k.json")))
    assert out is None and "سهمیه" in err


# ------------------------------------------------------------------ owner knowledge
def test_store_add_delete_limits_and_relevance(tmp_path):
    s = K.KnowledgeStore(tmp_path / "k.json")
    a, _ = s.add("قیمت اشتراک یک ماهه ۱۵۰ هزار تومان است", "قیمت")
    b, _ = s.add("پشتیبانی در تلگرام @support هر روز ۱۰ تا ۲۲", "پشتیبانی")
    assert a == 1 and b == 2 and len(s.items()) == 2
    assert s.add("", "x")[0] is None and s.add("x" * (K.MAX_ITEM_CHARS + 1))[0] is None
    assert "۱۵۰ هزار" in s.relevant("قیمت ها چقدره")
    assert s.delete(1) and not s.delete(1) and len(s.items()) == 1
    assert s.clear() == 1 and s.relevant("قیمت") == ""


def test_owner_notes_reach_the_answer(tmp_path):
    s = K.KnowledgeStore(tmp_path / "k.json")
    s.add("اشتراک ماهانه ۱۵۰ هزار تومان", "قیمت")
    ask = Script('{"about_bot": true, "sections": []}', "۱۵۰ هزار تومان")  # router: only the owner's notes matter here
    asyncio.run(K.smart_answer("قیمت اشتراک سلف چنده؟", ask, force=True, store=s))
    assert "اشتراک ماهانه ۱۵۰ هزار تومان" in ask.calls[-1][0]["content"]


def test_import_split_makes_titled_chunks():
    text = "# قیمت\nماهانه ۱۵۰\nسه ماهه ۳۶۰\n\n# پشتیبانی\nتلگرام @x\n"
    parts = K.split_for_import(text)
    assert [t for t, _ in parts] == ["قیمت", "پشتیبانی"] and "۳۶۰" in parts[0][1]
    assert all(len(c) <= K.MAX_ITEM_CHARS for _, c in K.split_for_import("a\n" * 6000))


# ------------------------------------------------------------------ smart helper
def test_signals():
    sig = K.signal_kind
    assert sig("چرا کار نمیکنه؟؟") [0] == "confused"
    assert sig("how do i schedule this")[0] == "confused"
    assert sig("ههههه عجب")[0] == "fun" and sig("lol that's great")[0] == "fun"
    assert sig(".laterr 10m hi")[0] == "typo" and ".later" in sig(".laterr 10m hi")[1]
    assert sig("❌ انجام نشد")[0] == "error"
    assert sig("🤖 خودش بود") == (None, "")  # the helper never reacts to its own words
    assert sig(".later 10m hi") == (None, "")  # a correct command is silent
    assert sig(".5 is fine") == (None, "") and sig("سلام چطوری") == (None, "")


def test_decision_parsing_defaults_to_silence():
    assert K.parse_decision('{"say": false}') is None
    assert K.parse_decision("no json") is None
    assert K.parse_decision('{"say": true, "kind": "help", "text": "از .later بزن"}') == ("help", "از .later بزن")
    assert K.parse_decision('{"say": true, "kind": "fun", "text": "هه"}', fun_allowed=False) is None
    assert K.parse_decision('{"say": true, "kind": "rm -rf", "text": "x"}') is None
    assert K.parse_decision('{"say": true, "kind": "help", "text": "   "}') is None


def test_decision_prompt_is_anonymous_and_marks_data():
    msgs = K.decision_messages("confused", "", ["A: hi", "owner: ?"], "چیکار کنم؟", "the owner", "", True)
    assert "DATA" in msgs[0]["content"] and ">> the owner: چیکار کنم؟" in msgs[1]["content"]


# ------------------------------------------------------------------ downloader helpers
def test_url_allowlist_blocks_other_hosts():
    ok = ["https://youtu.be/abc", "https://www.youtube.com/watch?v=1", "https://m.youtube.com/shorts/x", "https://www.instagram.com/reel/C1/",
          "https://vm.tiktok.com/Z/", "https://www.tiktok.com/@u/video/1"]
    bad = ["http://localhost/x", "http://127.0.0.1:8000", "https://instagram.com.evil.com/x", "https://evil.com/?u=youtube.com",
           "file:///etc/passwd", "ftp://youtube.com/x", "https://notyoutube.com/x", "https://169.254.169.254/latest"]
    assert all(D.platform_of(u) for u in ok)
    assert not any(D.platform_of(u) for u in bad)
    assert D.platform_of("https://youtu.be/a") == "youtube" and D.platform_of("https://www.instagram.com/p/1/") == "instagram"


def test_parse_args_any_order_and_persian():
    o = D.parse_args("audio https://youtu.be/a")
    assert o["audio"] and o["url"] == "https://youtu.be/a"
    o = D.parse_args("https://youtu.be/a 480 me")
    assert o["height"] == 480 and o["me"] and not o["audio"]
    assert D.parse_args("best https://youtu.be/a")["height"] == 1080
    assert D.parse_args("info https://youtu.be/a")["info"]
    assert D.parse_args("صوت https://youtu.be/a")["audio"] and D.parse_args("بدون لینک")["url"] is None
    assert D.parse_args("999 https://youtu.be/a")["height"] == 720  # unknown quality is ignored
    assert D.extract_url("ببین (https://youtu.be/a).") == "https://youtu.be/a"


def test_parse_explicit_mp3_mp4_modes_and_picker_default():
    mp3 = D.parse_args(".dl mp3 https://youtu.be/a")
    mp4 = D.parse_args("https://youtu.be/a mp4")
    plain = D.parse_args("https://youtu.be/a")
    assert mp3["audio"] and mp3["mode_explicit"]
    assert not mp4["audio"] and mp4["mode_explicit"]
    assert not plain["mode_explicit"] and not plain["quality_explicit"]


def test_ytdlp_options_are_safe():
    o = D.build_opts("/tmp/x", audio=False, height=480, max_mb=100, cookies="/nonexistent", proxy="")
    assert o["noplaylist"] and o["max_filesize"] == 100 * 1024 * 1024 and "cookiefile" not in o and "480" in o["format"]
    assert D.build_opts("/tmp/x", audio=True, height=720, max_mb=1)["postprocessors"][0]["preferredcodec"] == "mp3"


def test_friendly_errors():
    assert "کوکی" in D.friendly_error("ERROR: Sign in to confirm you're not a bot", "youtube")
    assert "اینستاگرام" in D.friendly_error("ERROR: login required", "instagram")
    assert "سقف" in D.friendly_error("File is larger than max-filesize")
    assert "دانلود نشد" in D.friendly_error("something weird")


# ------------------------------------------------------------------ downloader flow with a fake yt-dlp
class FakeYDL:
    info = {"id": "abc", "title": "Test Video", "uploader": "Chan", "duration": 30, "is_live": False}
    fail = None

    def __init__(self, opts):
        self.opts = opts

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def extract_info(self, url, download=False):
        if FakeYDL.fail:
            raise RuntimeError(FakeYDL.fail)
        return dict(FakeYDL.info)

    def download(self, urls):
        out = pathlib.Path(self.opts["outtmpl"]).parent
        ext = "mp3" if self.opts.get("postprocessors") else "mp4"
        (out / f"abc.{ext}").write_bytes(b"x" * 2048)
        hook = (self.opts.get("progress_hooks") or [None])[0]
        if hook:
            hook({"status": "finished"})


def _downloader_env(monkeypatch=None):
    fake = types.ModuleType("yt_dlp")
    fake.YoutubeDL = FakeYDL
    sys.modules["yt_dlp"] = fake
    from modules import downloader

    client = FakeClient()
    client.sent = []

    async def send_file(target, path, **kw):
        client.sent.append((target, path, kw))

    client.send_file = send_file
    from core.database import Database

    async def mk():
        db = Database(tempfile.mktemp())
        await db.connect()
        return db

    db = asyncio.run(mk())
    return downloader, client, db


def _event(client, text):
    ev = FakeEvent(client, text)
    ev.edits = []

    async def edit(t, **k):
        ev.edits.append(t)

    ev.edit = edit
    return ev


def test_dl_downloads_sends_and_cleans_up():
    downloader, client, db = _downloader_env()

    async def run():
        downloader.FFMPEG = None
        downloader.setup(client, db)
        FakeYDL.fail = None
        ev = _event(client, ".dl 480 https://youtu.be/abc")
        assert await _dispatch(client, "dl_cmd", ev)
        return ev

    ev = asyncio.run(run())
    assert len(client.sent) == 1 and client.sent[0][0] == ev.chat_id and client.sent[0][1].endswith("abc.mp4")
    assert "Test Video" in client.sent[0][2]["caption"]
    assert ev.deleted  # the command message disappears after a successful send
    assert not list(downloader.DL_DIR.glob("tmp*"))  # work dir removed


def test_dl_audio_and_saved_messages_and_info():
    downloader, client, db = _downloader_env()

    async def run():
        downloader.FFMPEG = None
        downloader.setup(client, db)
        FakeYDL.fail = None
        a = _event(client, ".dl me audio https://www.instagram.com/reel/C1/")
        await _dispatch(client, "dl_cmd", a)
        b = _event(client, ".dl info https://www.tiktok.com/@u/video/1")
        await _dispatch(client, "dl_cmd", b)
        return a, b

    a, b = asyncio.run(run())
    assert client.sent[0][0] == "me"
    assert any("Saved Messages" in t for t in a.edits)
    assert len(client.sent) == 1 and any("Test Video" in t and "0:30" in t for t in b.edits)  # info sends nothing


def test_dl_rejects_foreign_hosts_and_ignores_plain_persian_chat():
    downloader, client, db = _downloader_env()

    async def run():
        downloader.setup(client, db)
        bad = _event(client, ".dl http://169.254.169.254/latest")
        await _dispatch(client, "dl_cmd", bad)
        chat = _event(client, "دانلود کنید اینو")
        await _dispatch(client, "dl_cmd", chat)
        return bad, chat

    bad, chat = asyncio.run(run())
    assert any("فقط لینک" in r for r in bad.replies) and not client.sent
    assert not chat.replies and not chat.edits


def test_dl_failure_message_is_friendly_and_quota_is_refunded():
    downloader, client, db = _downloader_env()

    async def run():
        downloader.setup(client, db)
        FakeYDL.fail = "ERROR: Sign in to confirm you're not a bot"
        ev = _event(client, ".dl https://youtu.be/abc")
        await _dispatch(client, "dl_cmd", ev)
        FakeYDL.fail = None
        n = int(await db.get_kv(next(iter([k for k in [downloader.datetime.now(downloader._tz()).strftime("dl_used:%Y-%m-%d")]])), 0) or 0)
        return ev, n

    ev, n = asyncio.run(run())
    assert any("کوکی" in t for t in ev.edits) and n == 0 and not client.sent


# ------------------------------------------------------------------ ai_guide module: .guide, .aiknow, .aiguide and the helper
def _guide_env(tmp_path, kind="main", answers=()):
    from core.database import Database
    from modules import ai_guide

    K.KNOWLEDGE_FILE = tmp_path / "k.json"
    client = FakeClient()
    client._hapoyi_kind = kind
    script = Script(*answers)
    client.script = script

    async def ask(messages, *, max_tokens=700, temperature=0.5):
        return await script(messages, max_tokens=max_tokens, temperature=temperature)

    client._hapoyi_ask_ai = ask

    async def iter_messages(*a, **k):
        for _ in ():
            yield _

    client.iter_messages = iter_messages

    async def mk():
        db = Database(tempfile.mktemp())
        await db.connect()
        await ai_guide.setup(client, db)
        return db

    return client, asyncio.run(mk())


def _ev(client, text):
    ev = FakeEvent(client, text)
    ev.edits = []

    async def edit(t, **k):
        ev.edits.append(t)

    ev.edit = edit
    return ev


def _run_cmd(client, name, text):
    ev = _ev(client, text)
    asyncio.run(_dispatch(client, name, ev))
    return ev


def test_guide_command_answers_from_docs(tmp_path):
    client, _db = _guide_env(tmp_path, answers=["با .later 10m متن بفرست"])
    ev = _run_cmd(client, "guide", ".guide چجوری پیام رو زمان بندی کنم دستورش چیه")
    assert re.match(r"^#\d{5} 🤖", ev.edits[-1]) and ".later" in ev.edits[-1]  # 1.17.0: every AI message starts with an id
    assert ".later" in client.script.calls[0][0]["content"]
    assert "فرمت" in _run_cmd(client, "guide", ".guide").replies[-1]


def test_aiknow_is_owner_only_and_customers_still_read_it(tmp_path):
    client, _ = _guide_env(tmp_path, kind="licensed")
    assert "فقط اکانت اصلی" in _run_cmd(client, "aiknow", ".aiknow add قیمت | ۱۵۰").replies[-1]
    assert K.KnowledgeStore(tmp_path / "k.json").items() == []
    main, _ = _guide_env(tmp_path, kind="main")
    assert "اضافه شد" in _run_cmd(main, "aiknow", ".aiknow add قیمت | ماهانه ۱۵۰ هزار").replies[-1]
    assert "قیمت" in _run_cmd(main, "aiknow", ".aiknow list").replies[-1]
    customer, _ = _guide_env(tmp_path, kind="licensed", answers=['{"about_bot": true, "sections": []}', "۱۵۰ هزار"])  # same file, other account
    _run_cmd(customer, "guide", ".guide قیمت اشتراک چنده")
    assert any("ماهانه ۱۵۰ هزار" in m[0]["content"] for m in customer.script.calls)
    assert "حذف شد" in _run_cmd(main, "aiknow", ".aiknow del 1").replies[-1]
    assert "تأیید" in _run_cmd(main, "aiknow", ".aiknow clear").replies[-1]


def _helper(client, text, chat=-1001):
    ev = _ev(client, text)
    ev.chat_id = chat
    fn = next(f for b, f in client.handlers if f.__name__ == "helper")
    asyncio.run(fn(ev))
    return ev


def test_helper_is_silent_when_off_and_speaks_only_when_ai_says_so(tmp_path):
    client, db = _guide_env(tmp_path, answers=[
        '{"say": true, "kind": "help", "text": "از .later 10m سلام استفاده کن"}',
        '{"say": false}',
        '{"say": true, "kind": "fun", "text": "هه"}'])
    assert _helper(client, "چرا کار نمیکنه؟؟").replies == [] and client.script.calls == []  # OFF by default
    assert "روشن" in _run_cmd(client, "aiguide_cmd", ".aiguide on").replies[-1]
    ev = _helper(client, "چرا کار نمیکنه؟؟")
    assert ev.replies and ev.replies[0].startswith("🤖") and ".later" in ev.replies[0]
    assert len(client.script.calls) == 1
    assert _helper(client, "باز هم گیج شدم نمیدونم").replies == [] and len(client.script.calls) == 1  # cooldown: no second AI call in the same chat
    quiet = _helper(client, "نمیدونم چیکار کنم", chat=-1002)
    assert quiet.replies == [] and len(client.script.calls) == 2  # AI said say=false -> silence
    _run_cmd(client, "aiguide_cmd", ".aiguide fun off")
    assert _helper(client, "ههههه", chat=-1003).replies == [] and len(client.script.calls) == 2  # fun is off: AI is not even asked
    assert _helper(client, "🤖 راهنما: چرا؟؟", chat=-1004).replies == []  # never reacts to its own words


def test_helper_chat_switch_where_and_daily_cap(tmp_path, monkeypatch=None):
    import os

    client, db = _guide_env(tmp_path, answers=['{"say": true, "kind": "help", "text": "راه حل"}'] * 5)
    _run_cmd(client, "aiguide_cmd", ".aiguide on")
    ev = _run_cmd(client, "aiguide_cmd", ".aiguide here off")
    assert "خاموش" in ev.replies[-1]
    assert _helper(client, "نمیدونم چی کار کنم").replies == [] and client.script.calls == []
    _run_cmd(client, "aiguide_cmd", ".aiguide here on")
    _run_cmd(client, "aiguide_cmd", ".aiguide where saved")
    _helper(client, "نمیدونم چی کار کنم")
    assert client.calls and client.calls[-1][0] == "send" and client.calls[-1][1][0] == "me"
    os.environ["AIGUIDE_DAILY"] = "1"
    try:
        _helper(client, "گیج شدم", chat=-2002)
        assert len(client.script.calls) == 1  # the daily cap stops further AI calls
    finally:
        del os.environ["AIGUIDE_DAILY"]


def test_helper_state_survives_restart(tmp_path):
    from modules import ai_guide

    client, db = _guide_env(tmp_path)
    _run_cmd(client, "aiguide_cmd", ".aiguide on")
    _run_cmd(client, "aiguide_cmd", ".aiguide ttl 7")
    again = FakeClient()

    async def boot():
        await ai_guide.setup(again, db)

    asyncio.run(boot())
    out = _run_cmd(again, "aiguide_cmd", ".aiguide status")
    assert "روشن" in out.replies[-1] and "7 ثانیه" in out.replies[-1]


def test_tiktok_webpage_error_explains_the_cause(monkeypatch):
    raw = "ERROR: [TikTok] 7695121886086270241: Unexpected response from webpage request; please report this issue"
    monkeypatch.setattr(D, "impersonation_ok", lambda: False)
    assert "curl-cffi" in D.friendly_error(raw, "tiktok")          # no browser impersonation -> install curl_cffi
    monkeypatch.setattr(D, "impersonation_ok", lambda: True)
    msg = D.friendly_error(raw, "tiktok")
    assert "YTDLP_PROXY" in msg and "curl-cffi" not in msg           # impersonation works -> IP is the problem
    assert "YTDLP_PROXY" not in D.friendly_error(raw, "youtube")     # other platforms keep the generic message
