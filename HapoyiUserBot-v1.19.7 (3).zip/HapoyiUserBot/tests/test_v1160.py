"""1.16.0: multi-provider AI (unlimited keys, dedupe, rotation, pinning), `.models` panel, server-side temp-file cleanup."""
from __future__ import annotations

import asyncio
import json
import os
import pathlib
import sys
import tempfile
import time
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

import pytest  # noqa: E402

from services import ai  # noqa: E402
from tests.test_regressions import FakeClient, FakeEvent, _dispatch  # noqa: E402
from utils import tmpclean  # noqa: E402

OK = '{"choices":[{"message":{"content":"سلام"}}]}'
MSG = [{"role": "user", "content": "hi"}]


@pytest.fixture(autouse=True)
def _clean_state(monkeypatch):
    for d in (ai.PARKED, ai.STATS, ai.USED, ai.FAILS, ai.LATENCY, ai.LAST, ai.DISCOVERED):
        d.clear()
    monkeypatch.setattr(ai, "_STATE", {"loaded": True, "persist": False, "saved": 0.0})
    for k in list(os.environ):
        if k.startswith(("AI_SOFT_", "AI_STRATEGY")):
            monkeypatch.delenv(k, raising=False)
    yield
    for d in (ai.PARKED, ai.STATS, ai.USED, ai.FAILS, ai.LATENCY, ai.LAST, ai.DISCOVERED):
        d.clear()


class Resp:
    def __init__(self, status, body, headers=None):
        self.status, self._b, self.headers = status, body, headers or {}

    async def text(self):
        return self._b

    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False


class Sess:
    """script: (model, key) -> Resp | list of Resp (consumed in order, the last one repeats)."""

    def __init__(self, script):
        self.script, self.calls = script, []

    def post(self, url, json=None, headers=None, **kw):
        key = headers["Authorization"].split()[-1]
        self.calls.append((json["model"], key))
        item = self.script[(json["model"], key)]
        if isinstance(item, list):
            return item.pop(0) if len(item) > 1 else item[0]
        return item

    def get(self, url, headers=None, **kw):
        return self.script[("GET", url)]


def _chain(*specs):
    out = []
    for prov, model, keys in specs:
        out.append(ai.Entry(prov, model, "http://x", keys[0], tuple(keys)))
    return out


# ------------------------------------------------------------------ keys: unlimited, any spelling, no duplicates
def test_keys_any_number_any_spelling_deduped():
    env = {"GROQ_API_KEY": "k1", "GROQ_API_KEY_2": "k2", "GROQ_API_KEY_10": "k10", "GROQ_API_KEYS": "k3, k4;k1\nk5",
           "GROQ_KEY_3": "k6", "GEMINI_API_KEY": "put_your_key_here", "NVIDIA_API_KEY": '"nv1"', "OTHER_API_KEY": "zzz"}
    keys = ai.collect_keys(env, "GROQ")
    assert keys == ["k1", "k3", "k4", "k5", "k2", "k6", "k10"]  # plain names first, then _2, _3 ... _10; k1 only once
    assert ai.collect_keys(env, "GEMINI") == []  # the .env.example placeholder is not a key
    assert ai.collect_keys(env, "NVIDIA") == ["nv1"]
    many = {f"MISTRAL_API_KEY_{i}": f"m{i}" for i in range(2, 60)}
    assert len(ai.collect_keys(many, "MISTRAL")) == 58  # no limit


def test_same_model_twice_is_used_once_and_models_come_from_env():
    env = {"GROQ_API_KEY": "g1", "GROQ_API_KEY_2": "g2", "GROQ_MODELS": "m1, M1 ,m2 m2", "GEMINI_API_KEY": "gm", "GEMINI_MODELS": "gx",
           "AI_PROVIDER_ORDER": "gemini,groq"}
    chain = ai.load_chain(env)
    assert [e.name for e in chain] == ["gemini:gx", "groq:m1", "groq:m2"]
    assert chain[1].all_keys == ("g1", "g2")
    # old style AI_CHAIN still works and is deduplicated too (same provider + same model, any letter case)
    env2 = {"AI_CHAIN": "groq:A, groq:a ,gemini:b,groq:c", "GROQ_API_KEY": "g", "GEMINI_API_KEY": "x"}
    assert [e.name for e in ai.load_chain(env2)] == ["groq:A", "gemini:b", "groq:c"]


def test_default_chain_uses_builtin_models_only_for_providers_with_keys():
    env = {"CEREBRAS_API_KEY": "c", "SAMBANOVA_API_KEY": "s"}
    names = [e.name for e in ai.load_chain(env)]
    assert names and all(n.split(":")[0] in {"cerebras", "sambanova"} for n in names)
    assert ai.load_chain({}) == []
    custom = ai.load_chain({"AI_CUSTOM_BASE": "http://h/v1/", "AI_CUSTOM_KEYS": "a,b", "AI_CUSTOM_MODELS": "foo"})
    assert [(e.name, e.base, e.all_keys) for e in custom] == [("custom:foo", "http://h/v1", ("a", "b"))]


# ------------------------------------------------------------------ rotation and fail-over
def test_second_key_of_same_model_is_used_when_first_runs_out_then_next_model():
    chain = _chain(("groq", "gpt", ["k1", "k2"]), ("gemini", "g", ["z"]))
    sess = Sess({("gpt", "k1"): Resp(429, "Rate limit reached for requests per day (RPD)"), ("gpt", "k2"): Resp(200, OK),
                 ("g", "z"): Resp(200, OK)})

    async def run():
        assert (await ai.chat(MSG, chain=chain, session=sess))[1] == "groq:gpt#2"  # key 2 of the SAME model, not another model
        assert sess.calls == [("gpt", "k1"), ("gpt", "k2")]
        assert (await ai.chat(MSG, chain=chain, session=sess))[1] == "groq:gpt#2"  # key 1 stays parked until the reset
        sess.script[("gpt", "k2")] = Resp(429, "", {"retry-after": "60"})
        assert (await ai.chat(MSG, chain=chain, session=sess))[1] == "gemini:g"  # both keys gone -> next model
        # nothing left anywhere -> AIUnavailable with the earliest recovery
        sess.script[("g", "z")] = Resp(429, "", {"retry-after": "300"})
        with pytest.raises(ai.AIUnavailable) as exc:
            await ai.chat(MSG, chain=chain, session=sess)
        assert time.time() < exc.value.reset_at <= time.time() + ai.MAX_PARK

    asyncio.run(run())


def test_balanced_rotates_keys_least_used_first_ordered_does_not():
    chain = _chain(("groq", "m", ["k1", "k2", "k3"]))
    sess = Sess({("m", k): Resp(200, OK) for k in ("k1", "k2", "k3")})

    async def run():
        for _ in range(6):
            await ai.chat(MSG, chain=chain, session=sess)
        used = [k for _m, k in sess.calls]
        assert {k: used.count(k) for k in ("k1", "k2", "k3")} == {"k1": 2, "k2": 2, "k3": 2}
        sess.calls.clear()
        for _ in range(3):
            await ai.chat(MSG, chain=chain, session=sess, strategy="ordered")
        assert {k for _m, k in sess.calls} == {"k1"}

    asyncio.run(run())


def test_rejected_key_parks_every_model_of_that_key_only():
    chain = _chain(("groq", "a", ["bad", "good"]), ("groq", "b", ["bad", "good"]))
    sess = Sess({("a", "bad"): Resp(401, "invalid key"), ("a", "good"): Resp(200, OK), ("b", "bad"): Resp(200, OK), ("b", "good"): Resp(200, OK)})

    async def run():
        await ai.chat(MSG, chain=chain, session=sess)
        assert ai.PARKED[ai.key_tag("groq", "bad")][0] > time.time() + 3600
        sess.calls.clear()
        for _ in range(3):
            await ai.chat(MSG, chain=chain, session=sess)
        assert all(k == "good" for _m, k in sess.calls)  # the bad key is not touched for ANY model

    asyncio.run(run())


def test_soft_cap_moves_a_unit_to_the_back_before_the_provider_cuts_it_off(monkeypatch):
    monkeypatch.setenv("AI_SOFT_GROQ", "2")
    chain = _chain(("groq", "a", ["k"]), ("gemini", "b", ["k"]))
    sess = Sess({("a", "k"): Resp(200, OK), ("b", "k"): Resp(200, OK)})

    async def run():
        got = [(await ai.chat(MSG, chain=chain, session=sess))[1] for _ in range(4)]
        assert got == ["groq:a", "groq:a", "gemini:b", "gemini:b"]
        # the over-cap unit is still the last resort when everything else is gone
        ai.park("gemini:b", time.time() + 600, "x")
        assert (await ai.chat(MSG, chain=chain, session=sess))[1] == "groq:a"

    asyncio.run(run())


def test_pinned_model_first_fallback_on_off_and_model_outside_the_chain():
    chain = _chain(("groq", "a", ["k"]), ("gemini", "b", ["k"]))
    sess = Sess({("a", "k"): Resp(200, OK), ("b", "k"): Resp(200, OK), ("zzz", "k"): Resp(200, OK)})

    async def run():
        assert (await ai.chat(MSG, chain=chain, session=sess, prefer="gemini:b"))[1] == "gemini:b"
        assert (await ai.chat(MSG, chain=chain, session=sess, prefer="gemini"))[1] == "gemini:b"  # a whole provider
        assert (await ai.chat(MSG, chain=chain, session=sess, prefer="b"))[1] == "gemini:b"  # bare model id
        ai.park("gemini:b", time.time() + 600, "daily quota")
        assert (await ai.chat(MSG, chain=chain, session=sess, prefer="gemini:b"))[1] == "groq:a"  # fallback on
        with pytest.raises(ai.AIUnavailable):  # fallback off: say so, do not silently use another model
            await ai.chat(MSG, chain=chain, session=sess, prefer="gemini:b", fallback=False)

    asyncio.run(run())


def test_pinned_model_that_is_not_in_env_uses_the_providers_keys(monkeypatch):
    monkeypatch.setenv("GROQ_API_KEY", "gk")
    chain = _chain(("groq", "a", ["gk"]))
    sess = Sess({("a", "gk"): Resp(200, OK), ("brand-new", "gk"): Resp(200, '{"choices":[{"message":{"content":"new"}}]}')})
    text, unit = asyncio.run(ai.chat(MSG, chain=chain, session=sess, prefer="groq:brand-new"))
    assert (text, unit) == ("new", "groq:brand-new")


def test_200_with_error_body_and_truncated_reasoning_are_handled():
    chain = _chain(("openrouter", "r", ["k"]), ("groq", "g", ["k"]))
    err = json.dumps({"error": {"code": 429, "message": "Rate limit exceeded: free-models-per-day"}})
    sess = Sess({("r", "k"): Resp(200, err), ("g", "k"): Resp(200, OK)})

    async def run():
        assert (await ai.chat(MSG, chain=chain, session=sess))[1] == "groq:g"
        assert "openrouter:r" in ai.PARKED and ai.PARKED["openrouter:r"][1] == "daily quota" or ai.key_tag("openrouter", "k") in ai.PARKED
        ai.PARKED.clear()
        trunc = '{"choices":[{"message":{"content":""},"finish_reason":"length"}]}'
        sess2 = Sess({("r", "k"): Resp(200, trunc), ("g", "k"): Resp(200, OK)})
        assert (await ai.chat(MSG, chain=chain, session=sess2))[1] == "groq:g"
        assert "openrouter:r" not in ai.PARKED  # a model that merely ran out of tokens while thinking is not broken

    asyncio.run(run())


def test_network_errors_back_off_and_never_park_longer_than_a_day():
    import aiohttp

    class Boom:
        def post(self, *a, **k):
            raise aiohttp.ClientConnectionError("down")

    chain = _chain(("groq", "a", ["k"]))
    with pytest.raises(ai.AIUnavailable):
        asyncio.run(ai.chat(MSG, chain=chain, session=Boom()))
    until = ai.PARKED["groq:a"][0]
    assert time.time() < until <= time.time() + 600
    ai.park("groq:a", time.time() + 10 * 86400, "huge")
    assert ai.PARKED["groq:a"][0] <= time.time() + ai.MAX_PARK + 1


def test_classify_gemini_groq_region_and_day_cap():
    now = 1_800_000_000.0
    gem = '{"error":{"code":429,"status":"RESOURCE_EXHAUSTED","message":"Quota exceeded for metric generate_content_free_tier_requests per minute","details":[{"retryDelay":"34s"}]}}'
    until, why, kind = ai.classify_ex(429, {}, gem, now)
    assert kind == "rate" and until == pytest.approx(now + 39)  # a per-minute limit is NOT treated as a daily one
    gem_day = "Quota exceeded for metric ... GenerateRequestsPerDayPerProjectPerModel-FreeTier, limit: 250"
    until, why, kind = ai.classify_ex(429, {}, gem_day, now)
    assert kind == "daily" and until == ai.next_utc_midnight(now)
    until2, _w, _k = ai.classify_ex(429, {}, gem_day, now, fails=1)
    assert now < until2 <= until  # a later probe: the provider's day may end at another hour than UTC midnight
    until, why, kind = ai.classify_ex(429, {"x-ratelimit-reset-tokens": "2h3m"}, "Rate limit reached for tokens per day (TPD)", now)
    assert kind == "daily" and now + 7000 < until <= now + ai.MAX_PARK
    assert ai.classify_ex(400, {}, "User location is not supported for the API use.", now)[2:] == ("auth",)
    assert ai.classify_ex(402, {}, "", now)[2] == "auth"
    assert ai.classify_ex(404, {}, "The model `x` does not exist", now)[2] == "model"
    assert ai.classify_ex(503, {}, "", now, fails=20)[0] <= now + 600
    assert ai.classify_ex(429, {"retry-after": "9999999"}, "", now)[0] <= now + ai.MAX_PARK


def test_discover_filters_and_strips_prefixes():
    ids = ai._model_ids("gemini", {"data": [{"id": "models/gemini-x-flash"}, {"id": "models/text-embedding-004"}, {"id": "models/gemini-live-x"}]})
    assert ids == ["gemini-x-flash"]
    orr = ai._model_ids("openrouter", {"data": [{"id": "a/b:free", "pricing": {"prompt": "0", "completion": "0"}},
                                                {"id": "paid/model", "pricing": {"prompt": "0.1", "completion": "0.2"}}]})
    assert orr == ["a/b:free"]
    grq = ai._model_ids("groq", {"data": [{"id": "openai/gpt-oss-120b"}, {"id": "whisper-large-v3"}, {"id": "meta-llama/llama-prompt-guard-2-22m"}]})
    assert grq == ["openai/gpt-oss-120b"]

    async def run():
        sess = Sess({("GET", "https://api.groq.com/openai/v1/models"): Resp(200, json.dumps({"data": [{"id": "x-new-model"}]}))})
        out = await ai.discover(["groq"], session=sess, env={"GROQ_API_KEY": "k"})
        assert out == {"groq": ["x-new-model"]}
        rows = ai.catalog({"GROQ_API_KEY": "k", "GROQ_MODELS": "a"})
        assert [(r["name"], r["configured"]) for r in rows] == [("groq:a", True), ("groq:x-new-model", False)]

    asyncio.run(run())


def test_state_survives_restart_without_keys(tmp_path, monkeypatch):
    monkeypatch.setenv("AI_STATE_FILE", str(tmp_path / "s.json"))
    monkeypatch.setattr(ai, "_STATE", {"loaded": True, "persist": True, "saved": 0.0})
    ai.park("groq:a", time.time() + 600, "daily quota")
    ai._bump("groq:a")
    ai.save_state(force=True)
    raw = (tmp_path / "s.json").read_text()
    assert "daily quota" in raw and "k1" not in raw
    ai.PARKED.clear()
    ai.USED.clear()
    monkeypatch.setattr(ai, "_STATE", {"loaded": False, "persist": True, "saved": 0.0})
    ai._load_state()
    assert ai.PARKED["groq:a"][1] == "daily quota" and ai.used_today("groq:a") == 1


# ------------------------------------------------------------------ .models panel and commands
async def _db():
    from core.database import Database

    db = Database(tempfile.mktemp())
    await db.connect()
    return db


class PEvent:
    def __init__(self):
        self.edits, self.answers = [], []

    async def edit(self, text, **kw):
        self.edits.append((text, kw.get("buttons")))

    async def answer(self, text="", **kw):
        self.answers.append(text)


def _buttons(buttons):
    out = []
    for row in buttons:
        for b in row:
            data = getattr(getattr(b, "type", None), "data", None) or getattr(b, "data", None)
            if data:
                out.append(data.decode())
    return out


def test_models_panel_select_auto_fallback_and_strategy(monkeypatch):
    from modules import ai_models

    monkeypatch.setenv("GROQ_API_KEY", "g1")
    monkeypatch.setenv("GROQ_API_KEY_2", "g2")
    monkeypatch.setenv("GROQ_MODELS", "m1,m2")
    monkeypatch.setenv("GEMINI_API_KEY", "gm")
    monkeypatch.setenv("GEMINI_MODELS", "gx")
    for k in ("CEREBRAS", "NVIDIA", "SAMBANOVA", "MISTRAL", "OPENROUTER"):
        monkeypatch.delenv(f"{k}_API_KEY", raising=False)
    monkeypatch.delenv("AI_CHAIN", raising=False)

    async def run():
        db = await _db()
        rt = SimpleNamespace(db=db)
        text, btn = await ai_models.build(db)
        data = _buttons(btn)
        assert "🧠" in text and any(d.startswith("ui:p:mdl:auto") for d in data)
        assert all(len(d.encode()) <= 64 for d in data)  # Telegram callback data limit
        rows = ai.catalog()
        gx = next(r for r in rows if r["name"] == "gemini:gx")
        ev = PEvent()
        await ai_models.panel(ev, rt, f"ui:p:mdl:set:{gx['id']}:0")
        assert (await ai.load_prefs(db)).model == "gemini:gx" and "gemini:gx" in ev.edits[-1][0]
        await ai_models.panel(ev, rt, "ui:p:mdl:fb:0")
        assert (await ai.load_prefs(db)).fallback is False
        await ai_models.panel(ev, rt, "ui:p:mdl:st:0")
        assert (await ai.load_prefs(db)).strategy == "ordered"
        await ai_models.panel(ev, rt, "ui:p:mdl:auto:0")
        assert (await ai.load_prefs(db)).model == ""
        await ai_models.panel(ev, rt, "ui:p:mdl:set:deadbeef:0")
        assert "لیست عوض شده" in ev.answers[-1]  # a stale button does not crash
        await ai_models.panel(ev, rt, "ui:p:mdl:info:0")
        assert "…" in ev.edits[-1][0]  # keys are shown masked only (last 4 characters): the whole key never appears
        assert "g1" not in ev.edits[-1][0].replace("…g1", "") and "gm" not in ev.edits[-1][0].replace("…gm", "")

    asyncio.run(run())


def test_models_panel_without_keys_and_resolve(monkeypatch):
    from modules import ai_models

    for k in list(os.environ):
        if k.endswith(("_API_KEY", "_API_KEYS")) or "_API_KEY_" in k:
            monkeypatch.delenv(k, raising=False)

    async def run():
        db = await _db()
        text, _btn = await ai_models.build(db)
        assert "هیچ کلیدی" in text

    asyncio.run(run())
    rows = [{"name": "groq:openai/gpt-oss-120b", "provider": "groq", "model": "openai/gpt-oss-120b"},
            {"name": "cerebras:gpt-oss-120b", "provider": "cerebras", "model": "gpt-oss-120b"},
            {"name": "gemini:gemini-x-flash", "provider": "gemini", "model": "gemini-x-flash"}]
    assert ai_models.resolve("2", rows)[0] == "cerebras:gpt-oss-120b"
    assert ai_models.resolve("9", rows)[0] is None
    assert ai_models.resolve("gemini", rows)[0] == "gemini"
    assert ai_models.resolve("gpt-oss-120b", rows)[0] == "cerebras:gpt-oss-120b"
    assert ai_models.resolve("flash", rows)[0] == "gemini:gemini-x-flash"
    name, err = ai_models.resolve("gpt-oss", rows)
    assert name is None and "چند مدل" in err
    assert ai_models.resolve("nothing", rows)[0] is None


def test_model_text_commands_store_per_account_choice(monkeypatch):
    from modules import ai_models

    monkeypatch.setenv("GROQ_API_KEY", "g")
    monkeypatch.setenv("GROQ_MODELS", "m1,m2")
    for k in ("CEREBRAS", "GEMINI", "NVIDIA", "SAMBANOVA", "MISTRAL", "OPENROUTER"):
        monkeypatch.delenv(f"{k}_API_KEY", raising=False)
    monkeypatch.delenv("AI_CHAIN", raising=False)

    async def run():
        db = await _db()
        c = FakeClient(perms=None)
        await ai_models.setup(c, db)
        for text, name in ((".model 2", "model_cmd"), (".model fallback off", "model_cmd"), (".model strategy ordered", "model_cmd")):
            ev = FakeEvent(c, text)
            assert await _dispatch(c, name, ev)
        prefs = await ai.load_prefs(db)
        assert (prefs.model, prefs.fallback, prefs.strategy) == ("groq:m2", False, "ordered")
        ev = FakeEvent(c, ".model auto")
        await _dispatch(c, "model_cmd", ev)
        assert (await ai.load_prefs(db)).model == ""
        ev = FakeEvent(c, ".models list")
        assert await _dispatch(c, "models_cmd", ev)
        assert "groq:m1" in ev.replies[-1] and "groq:m2" in ev.replies[-1]
        ev = FakeEvent(c, ".model zzz")
        await _dispatch(c, "model_cmd", ev)
        assert ev.replies[-1].startswith("❌")

    asyncio.run(run())


def test_ask_uses_the_accounts_pinned_model_and_fallback_setting(monkeypatch):
    from modules import ai_tools
    from tests.test_v190 import Env

    seen = {}

    async def fake_chat(messages, **kw):
        seen.update(kw)
        return "جواب", "groq:m"

    monkeypatch.setattr(ai, "chat", fake_chat)

    async def run():
        db = await _db()
        c = Env(SimpleNamespace(is_creator=True, is_admin=True)).c
        c._hapoyi_kind = "main"
        ai_tools.setup(c, db)
        await db.set_kv("ai_model_pref", "gemini:gx")
        await db.set_kv("ai_model_fallback", False)
        text, err = await c._hapoyi_ask_ai(MSG)
        assert text == "جواب" and err is None
        assert seen["prefer"] == "gemini:gx" and seen["fallback"] is False

        async def unavailable(messages, **kw):
            raise ai.AIUnavailable(time.time() + 3600)

        monkeypatch.setattr(ai, "chat", unavailable)
        text, err = await c._hapoyi_ask_ai(MSG)
        assert text is None and "gemini:gx" in err and "models" in err  # tells the owner how to get out of it

    asyncio.run(run())


# ------------------------------------------------------------------ server-side temp files
def test_workdir_is_tracked_removed_and_never_swept_while_active(tmp_path):
    base = tmp_path / "dl"
    wd = tmpclean.new_workdir(base, "t_")
    f = Path(wd) / "video.mp4"
    f.write_bytes(b"x" * 1000)
    old = time.time() - 7200
    os.utime(f, (old, old))
    os.utime(wd, (old, old))
    stale = base / "crashed_run"
    stale.mkdir()
    (stale / "half.part").write_bytes(b"y" * 500)
    os.utime(stale / "half.part", (old, old))
    os.utime(stale, (old, old))
    fresh = base / "fresh"
    fresh.mkdir()
    (fresh / "a").write_bytes(b"z")
    removed, freed = tmpclean.sweep(base, 1800)
    assert (removed, freed) == (1, 500)  # only the stale leftover; the ACTIVE dir (even if idle) and the fresh one stay
    assert Path(wd).exists() and fresh.exists() and not stale.exists()
    assert tmpclean.release(wd) == 1000 and not Path(wd).exists()
    assert tmpclean.release(wd) == 0  # releasing twice is harmless
    removed, _ = tmpclean.sweep(base, 0)
    assert removed == 1 and not fresh.exists()


def test_purge_missing_paths_and_context_manager(tmp_path):
    assert tmpclean.purge(None, str(tmp_path / "nope"), "") == 0
    with tmpclean.workdir(tmp_path, "c_") as wd:
        (Path(wd) / "a").write_text("1")
        assert tmpclean.is_active(wd)
    assert not Path(wd).exists() and not tmpclean.is_active(wd)
    try:
        with tmpclean.workdir(tmp_path, "c_") as wd2:
            raise RuntimeError("boom")
    except RuntimeError:
        pass
    assert not Path(wd2).exists()  # removed even when the work failed


class DlClient(FakeClient):
    """Writes real files on download_media and records what is on disk at the moment of every upload."""

    def __init__(self):
        super().__init__(perms=None)
        self.uploads, self.fail_upload = [], False

    async def send_file(self, target, path, **kw):
        paths = path if isinstance(path, list) else [path]
        self.uploads.append((target, [(p, os.path.exists(p) if isinstance(p, (str, os.PathLike)) else True) for p in paths]))
        if self.fail_upload:
            raise RuntimeError("upload failed")
        return SimpleNamespace(id=1)

    async def download_media(self, item, file=None, **kw):
        out = Path(str(file)) / f"{item.id}.bin"
        out.write_bytes(b"data" * 1000)
        return str(out)


def _media_msg(i):
    async def get_sender():
        return SimpleNamespace(first_name="S", last_name=None, username=None)

    async def download_media(file=None, **kw):
        out = Path(str(file)) / f"{i}.bin"
        out.write_bytes(b"data" * 1000)
        return str(out)

    return SimpleNamespace(id=i, photo=object(), document=None, media=object(), grouped_id=None, message="cap", chat_id=-1,
                           get_sender=get_sender, download_media=download_media)


def _download_event(c, msg):
    ev = FakeEvent(c, ".download", reply_user=SimpleNamespace(id=7))
    ev.edits = []

    async def get_reply_message():
        return msg

    async def edit(text, **kw):
        ev.edits.append(text)

    async def get_chat():
        return SimpleNamespace(title="Chat")

    ev.get_reply_message, ev.edit, ev.get_chat = get_reply_message, edit, get_chat
    return ev


def test_download_command_deletes_server_copy_after_upload_and_after_failure(tmp_path, monkeypatch):
    from modules import media

    monkeypatch.setattr(media, "MEDIA_DIR", tmp_path)
    monkeypatch.setattr(tmpclean, "MEDIA_DIR", tmp_path)
    monkeypatch.setattr(asyncio, "sleep", lambda *_a, **_k: _noop())

    async def _noop():
        return None

    async def run():
        c = DlClient()
        media.setup(c, None)
        ev = _download_event(c, _media_msg(11))
        assert await _dispatch(c, "download", ev)
        assert c.uploads and c.uploads[0][0] == "me" and c.uploads[0][1][0][1] is True  # it existed when uploaded
        assert list(tmp_path.iterdir()) == []  # ... and is gone afterwards: the server keeps nothing
        assert any("Saved Messages" in t for t in ev.edits)
        c.fail_upload = True
        ev2 = _download_event(c, _media_msg(12))
        try:
            await _dispatch(c, "download", ev2)
        except RuntimeError:
            pass
        assert list(tmp_path.iterdir()) == []  # a failed upload does not leave the file behind either

    asyncio.run(run())


def test_rename_resize_sticker_leave_nothing_and_rename_cannot_escape(tmp_path, monkeypatch):
    from modules import media

    monkeypatch.setattr(media, "MEDIA_DIR", tmp_path / "media")
    monkeypatch.setattr(tmpclean, "MEDIA_DIR", tmp_path / "media")

    async def run():
        c = DlClient()
        media.setup(c, None)
        ev = _download_event(c, _media_msg(21))
        ev.pattern_match = None
        ev.message.message = ".rename ../../evil.txt"
        ev.raw_text = ".rename ../../evil.txt"
        assert await _dispatch(c, "rename", ev)
        sent = c.uploads[-1][1][0][0]
        assert Path(sent).name == "evil.txt" and Path(sent).parent.parent == tmp_path / "media"  # a name, never a path
        assert not (tmp_path / "evil.txt").exists()
        leftovers = [p for p in (tmp_path / "media").rglob("*")]
        assert leftovers == []  # work dir removed after sending

    asyncio.run(run())


def test_dl_send_result_purges_each_part_right_after_upload(tmp_path, monkeypatch):
    """The downloader frees the disk per uploaded album part (not only at the very end), and when the upload fails."""
    src = Path(__file__).resolve().parents[1] / "modules" / "downloader.py"
    text = src.read_text("utf-8")
    assert "tmpclean.purge(*chunk)" in text and "tmpclean.purge(str(path), thumb)" in text
    assert text.count("tmpclean.release(workdir)") >= 2  # right after the upload, and again in `finally`
    assert "shutil.rmtree(workdir" not in text and "tempfile.mkdtemp" not in text


def test_no_module_leaves_unmanaged_temp_dirs():
    root = Path(__file__).resolve().parents[1] / "modules"
    offenders = []
    for py in root.glob("*.py"):
        body = py.read_text("utf-8")
        if "mkdtemp(" in body:
            offenders.append(py.name)
    assert offenders == [], f"use utils.tmpclean.new_workdir/workdir instead of mkdtemp: {offenders}"


def test_storage_command_reports_and_cleans(tmp_path, monkeypatch):
    from modules import storage_janitor

    monkeypatch.setattr(tmpclean, "SWEEP_DIRS", (tmp_path / "a",))
    (tmp_path / "a").mkdir()
    (tmp_path / "a" / "left.bin").write_bytes(b"1" * 2048)

    async def run():
        c = FakeClient(perms=None)
        storage_janitor._STARTED["task"] = SimpleNamespace(done=lambda: False)  # do not start the background loop in a test
        await storage_janitor.setup(c, None)
        ev = FakeEvent(c, ".storage")
        assert await _dispatch(c, "storage", ev)
        assert "MB" in ev.replies[-1]
        ev = FakeEvent(c, ".storage clean")
        assert await _dispatch(c, "storage", ev)
        assert "1 مورد" in ev.replies[-1] and not (tmp_path / "a" / "left.bin").exists()

    asyncio.run(run())


# ================================================================== 1.16.0 part 2: owner fix, pictures, web, image generation, tips
def test_owner_detected_by_telegram_id_not_only_by_kind():
    from core.identity import is_owner, owner_flag

    async def run():
        main = SimpleNamespace(_hapoyi_kind="main")
        assert owner_flag(main) and await is_owner(main)
        # the owner's SECOND account (logged in through the control bot): kind "licensed", same Telegram id as HAPOYI_OWNER_ID
        second = SimpleNamespace(_hapoyi_kind="licensed", _hapoyi_me_id=777, _hapoyi_fleet=SimpleNamespace(owner_id=777))
        assert not owner_flag(second) and await is_owner(second) and owner_flag(second)
        stranger = SimpleNamespace(_hapoyi_kind="licensed", _hapoyi_me_id=5, _hapoyi_fleet=SimpleNamespace(owner_id=777))
        assert not await is_owner(stranger)
        nofleet = SimpleNamespace(_hapoyi_kind="licensed", _hapoyi_me_id=5)
        assert not await is_owner(nofleet)

    asyncio.run(run())


def test_aiknow_works_for_owner_account_and_is_refused_for_others():
    from modules import ai_guide

    async def run(kind, me, owner):
        db = await _db()
        c = FakeClient(perms=None)
        c._hapoyi_kind, c._hapoyi_me_id, c._hapoyi_fleet = kind, me, SimpleNamespace(owner_id=owner)
        await ai_guide.setup(c, db)
        ev = FakeEvent(c, ".aiknow")
        assert await _dispatch(c, "aiknow", ev)
        return ev.replies[-1]

    assert "دانش هوش مصنوعی" in asyncio.run(run("licensed", 777, 777))  # the bug: this used to say «فقط اکانت اصلی (مالک)»
    assert "دانش هوش مصنوعی" in asyncio.run(run("main", 1, 1))
    assert "فقط اکانت اصلی" in asyncio.run(run("licensed", 5, 777))


def test_fleet_marks_owner_runtime_flag():
    src = (Path(__file__).resolve().parents[1] / "core" / "fleet.py").read_text("utf-8")
    assert "client._hapoyi_is_owner" in src


def test_vision_only_vision_models_are_used_and_refusals_are_remembered_for_pictures_only():
    chain = _chain(("groq", "openai/gpt-oss-120b", ["k"]), ("gemini", "gemini-3.8-flash", ["k"]), ("mistral", "mistral-small-latest", ["k"]))
    img = [{"role": "user", "content": [{"type": "text", "text": "?"}, {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,AA=="}}]}]
    sess = Sess({("openai/gpt-oss-120b", "k"): Resp(200, OK), ("gemini-3.8-flash", "k"): Resp(400, "model does not support image input"),
                 ("mistral-small-latest", "k"): Resp(200, OK)})

    async def run():
        text, unit = await ai.chat(img, chain=chain, session=sess, vision=True)
        assert unit == "mistral:mistral-small-latest"  # gpt-oss never got the picture; gemini refused it and was skipped
        assert [m for m, _k in sess.calls] == ["gemini-3.8-flash", "mistral-small-latest"]
        assert "gemini:gemini-3.8-flash" in ai.VISION_BAD and "gemini:gemini-3.8-flash" not in ai.PARKED  # still fine for TEXT
        sess.script[("gemini-3.8-flash", "k")] = Resp(200, OK)
        assert (await ai.chat(MSG, chain=chain, session=sess, prefer="gemini:gemini-3.8-flash"))[1] == "gemini:gemini-3.8-flash"
        # nothing in the chain can see -> a clear "not configured" error, not an endless retry
        with pytest.raises(ai.AINotConfigured):
            await ai.chat(img, chain=_chain(("groq", "openai/gpt-oss-120b", ["k"])), session=sess, vision=True)

    ai.VISION_BAD.clear()
    asyncio.run(run())
    ai.VISION_BAD.clear()


def test_ask_with_photo_builds_an_image_message(monkeypatch):
    import io

    from PIL import Image

    from modules import ai_tools
    from tests.test_v190 import Env

    buf = io.BytesIO()
    Image.new("RGB", (2400, 1200), (200, 30, 30)).save(buf, "PNG")
    seen = {}

    async def fake_chat(messages, **kw):
        seen["messages"], seen["kw"] = messages, kw
        return "یک مربع قرمز", "gemini:g"

    monkeypatch.setattr(ai, "chat", fake_chat)

    async def run():
        db = await _db()
        c = Env(SimpleNamespace(is_creator=True, is_admin=True)).c
        ai_tools.setup(c, db)

        async def download_media(m, file=None, **kw):
            return buf.getvalue()

        c.download_media = download_media
        ev = FakeEvent(c, ".ask این چیه؟")
        ev.message.photo = object()
        ev.edits = []

        async def edit(t, **k):
            ev.edits.append(t)

        ev.edit = edit

        async def get_reply_message():
            return None

        ev.get_reply_message = get_reply_message
        assert await _dispatch(c, "ask", ev)
        assert "مربع قرمز" in ev.edits[-1]
        parts = seen["messages"][-1]["content"]
        assert parts[0]["text"] == "این چیه؟" and parts[1]["type"] == "image_url"
        url = parts[1]["image_url"]["url"]
        assert url.startswith("data:image/jpeg;base64,") and len(url) < 60_000  # shrunk, not the raw 2400px picture
        assert seen["kw"].get("vision") is True

    asyncio.run(run())


def test_websearch_parsing_and_ssrf_guard():
    from services import websearch as W

    page = ('<div class="result"><a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.org%2Fa%3Fx%3D1&rut=z">Title <b>A</b></a>'
            '<a class="result__snippet" href="x">Snippet &amp; more</a></div>'
            '<div class="result"><a class="result__a" href="https://example.com/b">Second</a><a class="result__snippet">S2</a></div>'
            '<a class="result__a" href="https://duckduckgo.com/y.js?ad=1">Ad</a>')
    hits = W.parse_ddg(page, 5)
    assert [(h.title, h.url) for h in hits] == [("Title A", "https://example.org/a?x=1"), ("Second", "https://example.com/b")]
    assert hits[0].snippet == "Snippet & more"
    for bad in ("http://127.0.0.1/x", "http://localhost:8080", "http://10.0.0.5/", "http://169.254.169.254/latest", "file:///etc/passwd", "ftp://a.b/c", "http://[::1]/"):
        assert not W.public_url(bad), bad
    assert W._strip_tags("<script>x()</script><p>Hello&nbsp;<b>w</b></p><style>a{}</style>").strip() == "Hello w"
    msgs = W.build_messages("سؤال", [W.Hit("T", "https://e.org", "snip", "body text")])
    assert "DATA" in msgs[0]["content"] and "[1] T" in msgs[1]["content"] and "body text" in msgs[1]["content"]
    assert W.sources_text([W.Hit("T", "https://e.org")]) == "[1] https://e.org"


def test_web_command_searches_then_answers_with_sources(monkeypatch):
    from modules import ai_web
    from services import websearch as W

    async def fake_gather(q, **kw):
        return [W.Hit("T1", "https://a.org", "s1", "text one"), W.Hit("T2", "https://b.org", "s2")]

    monkeypatch.setattr(W, "gather", fake_gather)

    async def run():
        db = await _db()
        c = FakeClient(perms=None)
        got = {}

        async def ask(messages, **kw):
            got["messages"] = messages
            return "جواب [1]", None

        c._hapoyi_ask_ai = ask
        await ai_web.setup(c, db)
        ev = FakeEvent(c, ".web چیزی")
        ev.edits = []

        async def edit(t, **k):
            ev.edits.append(t)

        ev.edit = edit
        assert await _dispatch(c, "web", ev)
        assert "جواب [1]" in ev.edits[-1] and "[1] https://a.org" in ev.edits[-1] and "[2] https://b.org" in ev.edits[-1]
        assert "text one" in got["messages"][1]["content"]

        async def broken(q, **kw):
            raise W.SearchError("blocked")

        monkeypatch.setattr(W, "gather", broken)
        ev2 = FakeEvent(c, ".web چیزی")
        ev2.edits = []
        ev2.edit = lambda t, **k: _rec2(ev2, t)
        assert await _dispatch(c, "web", ev2)
        assert "جستجو جواب نداد" in ev2.edits[-1]

    async def _rec2(ev, t):
        ev.edits.append(t)

    asyncio.run(run())


def _real_png(w=96, h=96):
    import io

    from PIL import Image

    im = Image.new("RGB", (w, h))
    im.putdata([((x * 3) % 256, (y * 3) % 256, (x + y) % 256) for y in range(h) for x in range(w)])
    out = io.BytesIO()
    im.save(out, "PNG")
    return out.getvalue()


def test_imagegen_backends_and_fallback():
    import base64

    from services import imagegen

    png = _real_png()

    class IResp:
        def __init__(self, status, body=b"", headers=None):
            self.status, self._b, self.headers = status, body, headers or {}
            self.content = SimpleNamespace(read=self._read)

        async def _read(self, n=-1):
            return self._b

        async def read(self):
            return self._b

        async def text(self):
            return self._b.decode() if isinstance(self._b, bytes) else self._b

        async def __aenter__(self):
            return self

        async def __aexit__(self, *a):
            return False

    class ISess:
        def __init__(self, post, get):
            self._post, self._get, self.posts = post, get, []

        def post(self, url, json=None, headers=None, **kw):
            self.posts.append(url)
            return self._post

        def get(self, url, **kw):
            return self._get

    b64 = json.dumps({"data": [{"b64_json": base64.b64encode(png).decode()}]}).encode()

    async def run():
        os.environ["GEMINI_API_KEY"] = "gk"
        os.environ["AI_IMAGE_POLLINATIONS"] = "on"
        ai.PARKED.clear()
        try:
            # Gemini answers
            data, who = await imagegen.generate("a cat", ISess(IResp(200, b64), IResp(500)))
            assert (data, who) == (png, "gemini")
            # Gemini has no image quota on this account -> parked, falls through to the free backend
            data, who = await imagegen.generate("a cat", ISess(IResp(429, b"quota"), IResp(200, png)))
            assert who == "pollinations" and data == png
            # everything fails -> one readable error
            with pytest.raises(imagegen.ImageError):
                await imagegen.generate("a cat", ISess(IResp(429, b"quota"), IResp(500)))
            os.environ["AI_IMAGE_POLLINATIONS"] = "off"
            ai.PARKED.clear()
            with pytest.raises(imagegen.ImageError):
                await imagegen.generate("a cat", ISess(IResp(500, b"x"), IResp(200, png)))
        finally:
            os.environ.pop("GEMINI_API_KEY", None)
            os.environ.pop("AI_IMAGE_POLLINATIONS", None)
            ai.PARKED.clear()

    asyncio.run(run())


def test_imagine_command_translates_sends_in_memory_and_respects_daily_cap(monkeypatch):
    from modules import ai_web
    from services import imagegen

    png = _real_png()
    seen = {}

    async def fake_generate(prompt, session=None):
        seen["prompt"] = prompt
        return png, "pollinations"

    monkeypatch.setattr(imagegen, "generate", fake_generate)
    monkeypatch.setenv("AI_IMAGE_DAILY", "1")

    async def run():
        db = await _db()
        c = DlClient()
        c._hapoyi_kind = "licensed"

        async def ask(messages, **kw):
            return "an astronaut cat on the moon", None

        c._hapoyi_ask_ai = ask
        await ai_web.setup(c, db)
        ev = FakeEvent(c, ".imagine گربه فضانورد")
        ev.edits = []

        async def edit(t, **k):
            ev.edits.append(t)

        ev.edit = edit
        assert await _dispatch(c, "imagine", ev)
        assert seen["prompt"] == "an astronaut cat on the moon"  # Persian -> English first
        assert c.uploads and ev.deleted
        ev2 = FakeEvent(c, ".img cat")
        ev2.edits = []

        async def edit2(t, **k):
            ev2.edits.append(t)

        ev2.edit = edit2
        assert await _dispatch(c, "imagine", ev2)
        assert "سهمیهٔ ساخت عکس" in ev2.edits[-1]  # cap of 1 per day for a non-owner account

    asyncio.run(run())


def test_tips_are_local_free_and_precise():
    from services import knowledge as K

    cases = {
        "ببین این ویدیو https://youtu.be/abc123": "dl",
        "https://www.instagram.com/reel/xyz/": "dl",
        "فردا ساعت ۸ یادم بنداز بهش زنگ بزنم": "remind",
        "قیمت دلار الان چنده": "price",
        "یه عکس بساز از گربه": "image",
        "اینو سرچ کن": "web",
        "این متن رو ترجمه کن": "translate",
        "خلاصه کن لطفا": "summary",
        "دارم میرم بخوابم": "afk",
        "12*5+3": "calc",
    }
    for text, key in cases.items():
        got = K.tip_kind(text)
        assert got is not None and got[0] == key, (text, got)
    for quiet in ("سلام چطوری", "امروز هوا خوبه", "https://example.com/page", ".dl https://youtu.be/abc", "🤖 یه نکته", "❌ فرمت: x", "2024", "1+1"[:2]):
        assert K.tip_kind(quiet) is None, quiet
    # a link to another site / a long text are left to the AI to judge (silence is its default)
    assert K.signal_kind("ببین https://example.com/page")[0] == "assist"
    assert K.signal_kind("متن بلند " * 60)[0] == "assist"
    assert K.signal_kind("سلام چطوری")[0] is None


def test_helper_gives_tips_without_calling_the_ai_and_never_nags():
    from modules import ai_guide

    async def run():
        db = await _db()
        await db.set_kv("aiguide_on", True)
        c = FakeClient(perms=None)
        c._hapoyi_kind = "main"
        asked = []

        async def ask(messages, **kw):
            asked.append(1)
            return None, "err"

        c._hapoyi_ask_ai = ask
        await ai_guide.setup(c, db)
        out = []

        def make(text):
            ev = FakeEvent(c, text)
            ev.is_channel = False

            async def reply(t, **k):
                out.append(t)
                return SimpleNamespace(delete=lambda: None)

            ev.reply = reply
            return ev

        helper = next(fn for b, fn in c.handlers if fn.__name__ == "helper")
        await helper(make("این رو ببین https://youtu.be/abc123"))
        assert len(out) == 1 and "dl" in out[0] and out[0].startswith("🤖") and not asked  # zero tokens
        await helper(make("اون یکی https://youtu.be/zzz999"))
        assert len(out) == 1  # same tip in the same chat within 10 minutes: silent
        await helper(make("قیمت دلار چنده"))
        assert len(out) == 2 and "price" in out[1]
        ev = FakeEvent(c, ".aiguide tips off")
        assert await _dispatch(c, "aiguide_cmd", ev)
        await helper(make("یادم بنداز فردا"))
        assert len(out) == 2  # tips switched off

    asyncio.run(run())


def test_imagegen_rejects_half_blank_and_tiny_pictures_and_retries():
    from services import imagegen

    full = _real_png(128, 128)
    half = full[: len(full) // 2]  # what content.read(n) used to return: the first chunk only
    import io

    from PIL import Image

    blank = io.BytesIO()
    Image.new("RGB", (128, 128), (200, 200, 200)).save(blank, "PNG")
    tiny = io.BytesIO()
    Image.new("RGB", (8, 8), (1, 2, 3)).save(tiny, "PNG")
    for bad, why in ((half, "incomplete"), (blank.getvalue(), "blank"), (tiny.getvalue(), "small")):
        with pytest.raises(imagegen.ImageError) as ei:
            imagegen.finalize(bad)
        assert why in str(ei.value)
    assert imagegen.finalize(full) == full  # a complete PNG passes untouched
    # webp -> a normal photo
    wb = io.BytesIO()
    Image.open(io.BytesIO(full)).save(wb, "WEBP")
    out = imagegen.finalize(wb.getvalue())
    assert out[:3] == b"\xff\xd8\xff" or out[:4] == b"\x89PNG"

    class Resp:
        def __init__(self, body, status=200):
            self.status, self._b, self.headers = status, body, {"Content-Length": str(len(body))}

        async def read(self):
            return self._b

        async def __aenter__(self):
            return self

        async def __aexit__(self, *a):
            return False

    class Sess:
        def __init__(self, *bodies):
            self.bodies, self.urls = list(bodies), []

        def get(self, url, **kw):
            self.urls.append(url)
            return Resp(self.bodies.pop(0))

    async def run():
        sess = Sess(half, blank.getvalue(), full)  # two broken answers, the third one is complete
        assert await imagegen._pollinations(sess, "cat") == full
        assert len(sess.urls) == 3 and len({u.split("seed=")[1] for u in sess.urls}) == 3  # new seed every try
        with pytest.raises(imagegen.ImageError):
            await imagegen._pollinations(Sess(half, half, half), "cat")

    asyncio.run(run())
