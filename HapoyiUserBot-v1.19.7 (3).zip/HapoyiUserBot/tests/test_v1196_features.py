"""1.19.6 features: rules, typo-fix, undo, digest, raid, pm guard, pro tools, jalali, docs retrieval."""
from __future__ import annotations

import asyncio
import pathlib
import sys
import time
from collections import deque
from datetime import date
from types import SimpleNamespace

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from telethon import events  # noqa: E402

from tests.test_v1170 import make_db  # noqa: E402
from utils import jalali as J  # noqa: E402


class FakeClient:
    """Collects the handlers of a module and lets a test «type» a command or deliver an incoming message."""

    def __init__(self):
        self.handlers = []
        self.sent = []
        self._hapoyi_me_id = 1

    def on(self, builder=None):
        def reg(fn):
            self.handlers.append((builder, fn))
            return fn
        return reg

    def list_event_handlers(self):
        return [(fn, b) for b, fn in self.handlers]

    def is_connected(self):
        return True

    async def send_message(self, chat, text, **kw):
        self.sent.append((chat, text, kw))
        return SimpleNamespace(id=len(self.sent), chat_id=chat if isinstance(chat, int) else 1, message=SimpleNamespace(id=1))

    async def delete_messages(self, *a, **kw):
        return None


class Ev:
    def __init__(self, text="", chat_id=-100, out=True, reply_to=None, sender_id=5):
        self.raw_text, self.chat_id, self.out, self.sender_id = text, chat_id, out, sender_id
        self.reply_to_msg_id = reply_to
        self.is_reply = bool(reply_to)
        self.is_private = chat_id > 0
        self.is_group = chat_id < 0
        self.message = SimpleNamespace(id=7, media=None, via_bot_id=None)
        self.edits, self.replies, self.deleted = [], [], False
        self.pattern_match = None

    async def edit(self, text, **kw):
        self.edits.append(text)

    async def reply(self, text, **kw):
        self.replies.append(text)

    async def delete(self):
        self.deleted = True

    async def get_sender(self):
        return SimpleNamespace(first_name="Ali", last_name=None, bot=False, contact=False, mutual_contact=False, is_self=False)

    async def get_reply_message(self):
        return None


async def type_command(client, text, **kw):
    ev = Ev(text, **kw)
    for builder, fn in client.handlers:
        pat = getattr(builder, "pattern", None)
        if pat is None or not getattr(builder, "outgoing", False):
            continue
        m = pat(text)
        if m:
            ev.pattern_match = m
            await fn(ev)
    return ev


async def deliver(client, ev, *, incoming=True):
    for builder, fn in client.handlers:
        if isinstance(builder, events.NewMessage) and builder.pattern is None and getattr(builder, "incoming", False) == incoming:
            await fn(ev)


def run(coro):
    return asyncio.run(coro)


# ------------------------------------------------------------------ jalali + small tools
def test_jalali_known_dates_and_roundtrip():
    assert J.to_jalali(2024, 3, 20) == (1403, 1, 1) and J.to_jalali(2026, 3, 21) == (1405, 1, 1)
    assert J.fmt_jalali(date(2026, 10, 29)) == "پنجشنبه 7 آبان 1405"
    assert J.parse_any("۱۴۰۵/۰۱/۰۱") == date(2026, 3, 21) and J.parse_any("2026-03-21") == date(2026, 3, 21) and J.parse_any("x") is None
    for n in range(date(1995, 1, 1).toordinal(), date(2045, 1, 1).toordinal(), 37):
        d = date.fromordinal(n)
        assert J.to_gregorian(*J.to_jalali(d.year, d.month, d.day)) == (d.year, d.month, d.day)


def test_roll_morse_mock():
    from modules import pro_tools as T
    rolls, total, label = T.parse_roll("2d6+1")
    assert label == "2d6+1" and len(rolls) == 2 and total == sum(rolls) + 1
    assert T.parse_roll("100")[2] == "1d100" and T.parse_roll("0d6") is None and T.parse_roll("abc") is None
    assert T.morse_encode("sos 1") == "... --- ... / .----" and T.morse_decode("... --- ...") == "sos"
    assert T.mock_case("hello world") == "hElLo WoRlD"


def test_pro_commands_through_handlers():
    from modules import pro_tools as T

    async def go():
        c, db = FakeClient(), await make_db()
        await T.setup(c, db)
        assert "1405" in (await type_command(c, ".jdate 2026-03-21")).edits[0]
        ev = await type_command(c, ".cd add عید 2030-01-01")
        assert "عید" in ev.edits[0]
        assert "#1 عید" in (await type_command(c, ".cd list")).edits[0]
        assert (await type_command(c, ".pick a | b | c")).edits[0].startswith("🎯")
        assert "```json" in (await type_command(c, '.json {"a":1}')).edits[0]
        assert "نامعتبر" in (await type_command(c, ".json {a")).edits[0]
        assert (await type_command(c, ".morse enc ab")).edits[0] == ".- -..."
        assert (await type_command(c, ".rev abc")).edits[0] == "cba"
    run(go())


def test_undo_takes_back_the_last_moderation_command(monkeypatch):
    from modules import pro_tools as T
    calls = []

    async def fake_run(client, chat, text, **kw):
        calls.append((chat, text))
        return 1
    monkeypatch.setattr(T, "run_as_me", fake_run)

    async def go():
        c, db = FakeClient(), await make_db()
        await T.setup(c, db)
        await type_command(c, ".mute @bob 1h")
        await type_command(c, ".ban @eve")
        await type_command(c, ".unban @zed")                      # an inverse is never recorded
        ev = await type_command(c, ".undo")
        assert calls == [(-100, ".unban @eve")] and ev.deleted
        await type_command(c, ".undo")
        assert calls[-1] == (-100, ".unmute @bob 1h")
        assert "نیست" in (await type_command(c, ".undo")).edits[0]
    run(go())


# ------------------------------------------------------------------ typo
def test_typo_suggestions_and_confirmation(monkeypatch):
    from modules import typofix as TF

    known = {"mute", "ban", "unban", "lock", "pin", "weather"}
    assert TF.suggest("mutee", known) == "mute" and TF.suggest("bann", known) == "ban" and TF.suggest("mute", known) is None
    assert TF.suggest("hello", known) is None and TF.suggest("zzz", known) is None
    assert {"banned", "ban", "banlist"} <= TF.pattern_words(r"^\.(?:banned(?:\s+users)?|ban\s+users|banlist)$")
    ran = []

    async def fake_run(client, chat, text, **kw):
        ran.append(text)
    monkeypatch.setattr(TF, "run_as_me", fake_run)

    async def go():
        c, db = FakeClient(), await make_db()
        TF.setup(c, db)
        c.handlers.append((events.NewMessage(outgoing=True, pattern=r"^\.mute(?:\s+(.*))?$"), lambda e: None))    # a real command exists -> «mute» is known
        ev = Ev(".mutee @x 10m")
        for b, fn in c.handlers:
            if b.pattern and b.pattern(ev.raw_text) and b.pattern.__self__.pattern.startswith("(?s)^\\.[A-Za-z]"):
                await fn(ev)
        assert ev.replies and "`.mute @x 10m`" in ev.replies[0]
        await type_command(c, ".y")
        assert ran == [".mute @x 10m"]
        assert "نیست" in (await type_command(c, ".y")).edits[0]          # used once
    run(go())


# ------------------------------------------------------------------ rules
def test_rule_parser():
    from modules import rules as R
    r = R.parse_rule("msg قیمت in here cd 30 => say سلام [name]", -100)
    assert r["kind"] == "msg" and r["arg"] == "قیمت" and r["chat_id"] == -100 and r["cooldown"] == 30 and r["action"] == "say"
    assert R.parse_rule("at 23:00 in here => run .lock all", -5)["arg"] == "23:00"
    assert R.parse_rule("at ۲۳:۰۰ in here => run .lock all", -5)["arg"] == "23:00"
    for bad in ("msg x say y", "msg => say y", "at 25:00 => say x", "join => say x", "msg x => explode", "msg x => run lock", "msg x => run .rule del all",
                "msg x => run .ban [name]", "msg x => say .ban someone", "msg /(/ => say x", "at 10:00 => del"):
        assert isinstance(R.parse_rule(bad, -1), str), bad
    assert R.matches("/^hi\\b/", "Hi there") and R.matches("قیمت", "قیمت دلار؟") and not R.matches("x", "abc")
    assert R.render("hi [name] {text}", name="Ali", text="yo") == "hi Ali yo"


def test_rule_engine_fires_on_incoming_messages_only_once_per_cooldown(monkeypatch):
    from modules import rules as R

    async def go():
        c, db = FakeClient(), await make_db()
        await R.setup(c, db)
        ev = await type_command(c, ".rule add msg قیمت in here => say قیمت‌ها توی کانال است, [name]", chat_id=-100)
        assert "قانون ساخته شد" in ev.edits[0]
        incoming = Ev("قیمت دلار چنده؟", chat_id=-100, out=False, sender_id=9)
        await deliver(c, incoming)
        assert incoming.replies == ["قیمت‌ها توی کانال است, Ali"]
        again = Ev("قیمت چنده", chat_id=-100, out=False, sender_id=9)
        await deliver(c, again)
        assert again.replies == []                                         # cooldown
        other = Ev("قیمت", chat_id=-200, out=False)
        await deliver(c, other)
        assert other.replies == []                                         # another chat
        mine = Ev("قیمت", chat_id=-100, out=True)
        await deliver(c, mine, incoming=False)
        assert mine.replies == []                                          # never for my own messages
        assert "(1×)" in (await type_command(c, ".rule list")).edits[0]
        await type_command(c, ".rule off 1")
        assert (await db.fetchone("SELECT enabled FROM rules WHERE id=1"))["enabled"] == 0
        assert "حذف" in (await type_command(c, ".rule del 1")).edits[0]
        for t in list(asyncio.all_tasks()):
            if t is not asyncio.current_task():
                t.cancel()
    run(go())


def test_rule_run_action_goes_through_run_as_me(monkeypatch):
    from modules import rules as R
    seen = []

    async def fake_run(client, chat, text, **kw):
        seen.append((chat, text, kw))
        return 1
    monkeypatch.setattr(R, "run_as_me", fake_run)

    async def go():
        c, db = FakeClient(), await make_db()
        await R.setup(c, db)
        await type_command(c, ".rule add msg raid => run .lock all", chat_id=-100)
        await type_command(c, ".rule add at 23:00 in here => run .lock all", chat_id=-100)
        ev = Ev("RAID!!", chat_id=-100, out=False)
        await deliver(c, ev)
        assert seen[0][:2] == (-100, ".lock all")
        assert "اجرا شد" in (await type_command(c, ".rule test 2", chat_id=-100)).edits[0]
        for t in list(asyncio.all_tasks()):
            if t is not asyncio.current_task():
                t.cancel()
    run(go())


# ------------------------------------------------------------------ raid / digest / pm
def test_raid_surge_detection():
    from modules import raid as RD
    t = deque()
    now = 1000.0
    for i in range(7):
        t.append(now + i)
    assert not RD.surge(t, now + 7, 8, 60)
    t.append(now + 8)
    assert RD.surge(t, now + 8, 8, 60)
    assert not RD.surge(t, now + 500, 8, 60) and len(t) == 0           # old joins fall out of the window


def test_digest_builds_one_message_from_unread_chats():
    from modules import digest as D
    assert D.parse_time("8:05") == "08:05" and D.parse_time("۲۳:۰۰") == "23:00" and D.parse_time("25:00") is None

    class Msg:
        def __init__(self, text, out=False):
            self.raw_text, self.out, self.media = text, out, None
            self.sender = SimpleNamespace(first_name="Sara")

    class Dlg:
        def __init__(self, name, unread, muted=False):
            self.name, self.unread_count, self.id, self.entity = name, unread, hash(name) % 1000, name
            self.archived = False
            self.dialog = SimpleNamespace(pinned=False, notify_settings=SimpleNamespace(mute_until=1 if muted else None))

    class C(FakeClient):
        async def iter_dialogs(self, limit=80):
            for d in (Dlg("Work", 3), Dlg("Spam", 50, muted=True), Dlg("Friend", 1), Dlg("Read", 0)):
                yield d

        async def get_messages(self, ent, limit=10):
            return [Msg(f"{ent} message {i}") for i in range(limit)][::-1]

    async def go():
        c = C()
        assert (await D.build(c)).endswith("🎉")                                          # empty list first? no: there are unread chats
    # with unread chats but no AI: plain list, muted + read chats left out
    async def go2():
        c = C()
        text = await D.build(c)
        assert "Work: 3" in text and "Friend: 1" in text and "Spam" not in text and "Read" not in text
        seen = []

        async def ask(messages, **kw):
            seen.append(messages[1]["content"])
            return "📌 مهم: —\n↩️ منتظر جواب تو: Sara - سؤال\n💬 بقیه: —", None
        c._hapoyi_ask_ai = ask
        text = await D.build(c)
        assert "منتظر جواب" in text and "### Work (3 unread)" in seen[0] and "Spam" not in seen[0]
    run(go2())


def test_pm_guard_warns_then_blocks_strangers_and_spares_known_people(monkeypatch):
    from modules import pmguard as PG
    assert PG.decide(2, 3) == "warn" and PG.decide(4, 3) == "block"
    blocked = []

    async def fake_call(self, req):
        blocked.append(req)
    FakeClient.__call__ = fake_call

    async def go():
        c, db = FakeClient(), await make_db()
        await PG.setup(c, db)
        await type_command(c, ".pm on 2", chat_id=1)
        ev1 = Ev("hi", chat_id=42, out=False, sender_id=42)
        ev1.get_input_sender = lambda: asyncio.sleep(0, result="in")
        await deliver(c, ev1)
        assert ev1.replies and "1/2" in ev1.replies[0]
        ev2 = Ev("hi again", chat_id=42, out=False, sender_id=42)
        await deliver(c, ev2)
        assert not ev2.replies                                                  # warning text is not repeated within 5 minutes
        ev3 = Ev("hello??", chat_id=42, out=False, sender_id=42)
        ev3.get_input_sender = lambda: asyncio.sleep(0, result="in")
        await deliver(c, ev3)
        assert len(blocked) == 1 and any("بلاک شد" in s[1] for s in c.sent)
        # somebody I wrote to is approved
        await deliver(c, Ev("hey", chat_id=77, out=True), incoming=False)
        ev4 = Ev("hi", chat_id=77, out=False, sender_id=77)
        await deliver(c, ev4)
        assert not ev4.replies
    run(go())


# ------------------------------------------------------------------ docs: small, found by meaning, never everything at once
def test_new_docs_sections_are_compact_and_retrievable():
    from services import aiagent as A
    from services import knowledge as K
    for key, probe in (("rules", "هر شب ساعت ۱۱ گروه رو قفل کن"), ("digest", "هر صبح خلاصه پیام‌ها رو بفرست"), ("raid", "هجوم عضو جدید رو مدیریت کن"),
                       ("pro", "تاریخ شمسی امروز چنده"), ("pmguard", "پیوی غریبه‌ها رو بلاک کن")):
        assert key in K.sections() and len(K.section_text(key, limit=100000)) < 1000
        assert key in [k for k, _ in K.score_sections(probe)], (key, probe)
        assert K.PREFIX + K.section_commands(key)[0] in A.manual_for(probe)      # the section is in the prompt of the request that needs it
    base = len(A.manual_for("سلام"))
    assert "rule add" not in A.manual_for("یه فونت قشنگ بزن")                  # not dragged into unrelated requests
    assert len(A.manual_for("هر شب ساعت ۱۱ گروه رو قفل کن")) <= A.MANUAL_BUDGET + 1500 and base <= A.MANUAL_BUDGET + 1500
