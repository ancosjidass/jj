"""1.19.7: panels belong to their opener, `.sb` for every account (+ isolation), verified domains + SSL, temporary mail (`.mail`)."""
from __future__ import annotations

import asyncio
import importlib
import os
import pathlib
import re
import smtplib
import socket
import sys
import tempfile
import time

import pytest
from aiohttp.test_utils import TestServer
from telethon import Button

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "sandbox_server"))

from utils import panel_owner as PO  # noqa: E402


def datas(buttons):
    out = []
    for row in buttons:
        for b in row:
            out.append(b.type.data if hasattr(b, "type") else b.data)
    return out


# ------------------------------------------------------------------ 1. panels belong to the account that opened them
def test_tag_roundtrip_and_limits():
    assert PO.split_data("ui:dash") == ("ui:dash", None)
    t = PO.tag_bytes(b"ui:dash", 123456789)
    clean, owner = PO.split_data(t.decode())
    assert clean == "ui:dash" and owner == 123456789
    assert PO.tag_bytes(t, 5) == t                                           # never tagged twice
    long = b"ui:" + b"x" * 58
    assert PO.tag_bytes(long, 123456789) == long                             # would pass 64 bytes: left alone
    assert all(len(d) <= 64 for d in datas(PO.tag_buttons([[Button.inline("a", b"ui:" + b"y" * 40)]], 7_000_000_000)))
    rows = PO.tag_buttons([[Button.inline("a", b"ui:a"), Button.inline("b", b"xo:1")]], 42)
    assert datas(rows) == [b"ui:a~16", b"xo:1"]                              # only the ui: buttons


class FakeEvent:
    def __init__(self, sender, data):
        self.sender_id = sender
        self.chat_id = None
        self.answers = []
        self.edits = []
        self.query = type("Q", (), {"data": data})()
        self.data = data

    async def answer(self, text=None, alert=False, **kw):
        self.answers.append((text, alert))

    async def edit(self, text=None, **kw):
        self.edits.append((text, kw))

    async def get_sender(self):
        return None


def test_ui_click_of_another_account_is_refused(monkeypatch):
    from modules import ui

    class RT:
        def __init__(self, uid):
            self.user_id = uid
            self.label = f"acc{uid}"
            self.client = None
            self.db = None

    class Fleet:
        def runtime_for_user(self, uid):
            return RT(uid) if uid in (1, 2) else None

    monkeypatch.setattr(ui, "_fleet", Fleet())
    seen = []

    async def fake_live(event, rt, data):
        seen.append((rt.user_id, data))
        await event.edit("x", buttons=[[Button.inline("n", b"ui:home")]])
        return True

    monkeypatch.setattr(ui, "_live", fake_live)

    async def go():
        panel_of_1 = PO.tag_bytes(b"ui:dash", 1)
        stranger = FakeEvent(2, panel_of_1)                                   # account 2 (also runs the self) presses a button of the panel of account 1
        await ui._callback(stranger)
        assert stranger.answers and stranger.answers[0][1] is True and not seen and not stranger.edits
        owner = FakeEvent(1, panel_of_1)
        await ui._callback(owner)
        assert seen == [(1, "ui:dash")]                                       # the handler sees the clean data
        assert datas(owner.edits[0][1]["buttons"]) == [b"ui:home~1"]          # and the next page stays the opener's
        plain = FakeEvent(2, b"ui:dash")                                      # an old, untagged panel keeps working
        await ui._callback(plain)
        assert seen[-1] == (2, "ui:dash")

    asyncio.run(go())


def test_menu_inline_results_are_tagged(monkeypatch):
    from modules import ui
    assert all(d.startswith(b"ui:") for d in datas(ui._home_buttons()))
    tagged = PO.tag_buttons(ui._home_buttons(), 777)
    assert all(d.endswith(b"~" + PO.to_tag(777).encode()) for d in datas(tagged))


# ------------------------------------------------------------------ 2. verified domains + SSL
def test_domain_rules(tmp_path):
    from sandbox_server import domains as D
    assert D.normalize("https://Sub.Example.com/x") == "sub.example.com" and D.valid("example.com")
    assert not D.valid("1.2.3.4") and not D.valid("evil.local") and not D.valid("nodot")
    reg = D.Registry(tmp_path / "d.json")
    reg.put("arivax.com", ssl=True, mail=True, wild_mx=True)
    reg.put("other.org", ssl=False)
    assert reg.covering("s.arivax.com") == "arivax.com" and reg.covering("arivax.com") is None   # a sub-domain of a domain with SSL needs nothing
    assert reg.covering("s.other.org") is None                                                    # the parent has no SSL yet
    assert reg.allowed("a.b.arivax.com") and reg.allowed("other.org") and not reg.allowed("evil.com") and not reg.allowed("arivax.com.evil.com")
    assert reg.mail_domains() == [{"name": "arivax.com", "wild_mx": True}]
    assert reg.public_base() == "https://arivax.com"


def test_add_domain_flow(tmp_path, monkeypatch):
    from sandbox_server import domains as D
    reg = D.Registry(tmp_path / "d.json")
    calls = []

    async def ip():
        return "1.2.3.4"

    async def dns(name, ipaddr):
        return {"ip": ipaddr, "a": ["1.2.3.4"], "a_ok": True, "mx": [name], "mx_ok": True, "wild_a": True, "wild_mx": True}

    async def warm(name, timeout=75.0):
        calls.append(name)
        return True, ""

    monkeypatch.setattr(D, "server_ip", ip)
    monkeypatch.setattr(D, "dns_report", dns)
    monkeypatch.setattr(D, "warm_tls", warm)

    async def go():
        r = await D.add_or_check(reg, "Example.com")
        assert r["status"] == "ready" and r["ssl"] and r["mail"] and calls == ["example.com"]     # the certificate is ordered at once
        r = await D.add_or_check(reg, "mail.example.com")
        assert r["status"] == "covered" and calls == ["example.com"]                              # a sub-domain of a domain with SSL: nothing to do
        assert reg.get("example.com")["ssl"] is True and reg.mail_domains()[0]["name"] == "example.com"

        async def dns_bad(name, ipaddr):
            return {"ip": ipaddr, "a": ["9.9.9.9"], "a_ok": False, "mx": [], "mx_ok": False, "wild_a": False, "wild_mx": False}

        monkeypatch.setattr(D, "dns_report", dns_bad)
        r = await D.add_or_check(reg, "wrongdns.org")
        assert r["status"] == "pending" and not r["ssl"] and "A   wrongdns.org" in r["hint"] and calls == ["example.com"]   # no certificate order for a name that does not point here
        assert (await D.add_or_check(reg, "not a domain"))["ok"] is False

    asyncio.run(go())


# ------------------------------------------------------------------ 3. temporary mail
def test_addresses_look_right_and_sub_domains_only_with_wildcard_mx(tmp_path):
    from sandbox_server import tempmail as T
    st = T.Store(tmp_path / "m.db")
    plain = {st.new_address("u1", [{"name": "a.com", "wild_mx": False}])["addr"] for _ in range(25)}
    for addr in plain:
        local, host = addr.split("@")
        assert 4 <= len(local) <= 7 and re.fullmatch(r"[a-z][a-z0-9]+", local) and host == "a.com"
    wild = [st.new_address("u2", [{"name": "w.com", "wild_mx": True}])["addr"] for _ in range(30)]
    subs = [a for a in wild if a.split("@")[1] != "w.com"]
    assert subs and len(subs) < 30                                                # some with a random 4-7 character sub-domain label, some without
    for a in subs:
        label = a.split("@")[1].split(".")[0]
        assert 4 <= len(label) <= 7 and a.endswith(".w.com")
    with pytest.raises(ValueError):
        st.new_address("u1", [])
    for _ in range(T.MAX_ADDRESSES + 5):
        st.new_address("u3", [{"name": "a.com"}])
    assert len(st.list_addresses("u3")) == T.MAX_ADDRESSES                         # the oldest are dropped


def test_mail_arrives_only_for_existing_addresses_and_only_the_owner_reads(tmp_path):
    from sandbox_server import tempmail as T
    st = T.Store(tmp_path / "m.db")
    a = st.new_address("u1", [{"name": "a.com"}])
    html_mail = b"From: Bank <no-reply@bank.com>\nSubject: Code\nContent-Type: text/html; charset=utf-8\n\n<html><style>p{}</style><p>Your code is <b>482913</b></p></html>\n"
    assert st.add_message(a["addr"], T.parse_message(html_mail)) is True
    assert st.add_message("nobody@a.com", T.parse_message(html_mail)) is False
    inbox = st.messages("u1", a["id"])
    assert inbox["total"] == 1 and "Bank" in inbox["items"][0]["sender"]
    assert "482913" in st.message("u1", a["id"], inbox["items"][0]["id"])["body"] and "style" not in st.message("u1", a["id"], inbox["items"][0]["id"])["body"]
    assert st.messages("u2", a["id"])["ok"] is False and st.message("u2", a["id"], 1) is None     # another account sees nothing
    for i in range(T.MAX_PER_ADDRESS + 5):
        st.add_message(a["addr"], {"sender": "x", "subject": str(i), "body": ""})
    assert st.messages("u1", a["id"])["total"] == T.MAX_PER_ADDRESS
    assert st.delete_address("u2", a["id"]) is False and st.delete_address("u1", a["id"]) is True and not st.exists(a["addr"])


def test_smtp_receiver_end_to_end(tmp_path, monkeypatch):
    pytest.importorskip("aiosmtpd")
    from sandbox_server import tempmail as T
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    monkeypatch.setenv("SANDBOX_SMTP_PORT", str(port))
    monkeypatch.setenv("SANDBOX_SMTP_HOST", "127.0.0.1")
    st = T.Store(tmp_path / "m.db")
    a = st.new_address("u1", [{"name": "a.com"}])
    ctrl = T.start_smtp(st)
    try:
        with smtplib.SMTP("127.0.0.1", port, timeout=10) as sm:
            sm.sendmail("x@y.com", [a["addr"]], f"From: x@y.com\nTo: {a['addr']}\nSubject: hello\n\nbody text 777\n")
            with pytest.raises(smtplib.SMTPRecipientsRefused):
                sm.sendmail("x@y.com", ["ghost@a.com"], "Subject: z\n\nz\n")
    finally:
        ctrl.stop()
    got = st.messages("u1", a["id"])
    assert got["total"] == 1 and got["items"][0]["subject"] == "hello"


# ------------------------------------------------------------------ 4. the server: domains, tls/ask, mail API, isolation
def load_server(root, monkeypatch, isolate="0"):
    monkeypatch.setenv("SANDBOX_TOKEN", "t" * 24)
    monkeypatch.setenv("SANDBOX_ROOT", str(root))
    monkeypatch.setenv("SANDBOX_ISOLATE", isolate)
    monkeypatch.setenv("SANDBOX_SMTP_PORT", "0")
    import server
    return importlib.reload(server)


def test_server_domains_tls_ask_and_mail_api(tmp_path, monkeypatch):
    server = load_server(tmp_path / "ws", monkeypatch)
    from modules import sandbox as S
    from sandbox_server import domains as D
    import aiohttp

    async def ip():
        return "1.2.3.4"

    async def dns(name, ipaddr):
        return {"ip": ipaddr, "a": ["1.2.3.4"], "a_ok": True, "mx": [name], "mx_ok": True, "wild_a": True, "wild_mx": False}

    async def warm(name, timeout=75.0):
        return True, ""

    monkeypatch.setattr(server.dom, "server_ip", ip)
    monkeypatch.setattr(server.dom, "dns_report", dns)
    monkeypatch.setattr(server.dom, "warm_tls", warm)

    async def go():
        srv = TestServer(server.make_app())
        await srv.start_server()
        base = str(srv.make_url("")).rstrip("/")
        monkeypatch.setenv("SANDBOX_URL", base)
        monkeypatch.setenv("SANDBOX_TOKEN", "t" * 24)
        owner, other = S.Box("u1"), S.Box("u2")
        try:
            with pytest.raises(RuntimeError, match="409"):
                await owner.mail_new()                                         # no domain yet
            res = await owner.domain_add("arivax.com")
            assert res["status"] == "ready" and res["mail"]
            assert (await owner.domains())["domains"][0]["name"] == "arivax.com"
            async with aiohttp.ClientSession() as s:
                async def ask(domain, token="t" * 24):
                    async with s.get(base + "/tls/ask", params={"domain": domain, "token": token}) as r:
                        return r.status
                assert await ask("arivax.com") == 200 and await ask("x7k.arivax.com") == 200      # a registered domain and ANY sub-domain of it
                assert await ask("evil.com") == 403 and await ask("arivax.com", "wrong") == 401   # nothing foreign, and only Caddy (with the token) may ask
            a = await owner.mail_new()
            assert a["addr"].endswith("@arivax.com")
            assert (await owner.mail_list())["items"][0]["addr"] == a["addr"]
            assert (await other.mail_list())["items"] == []                    # every account has its own inboxes
            with pytest.raises(RuntimeError, match="404"):
                await other.mail_inbox(a["id"])
            server.MAIL.add_message(a["addr"], {"sender": "s@x.com", "subject": "hi", "body": "code 55"})
            inbox = await owner.mail_inbox(a["id"])
            assert inbox["total"] == 1 and (await owner.mail_message(a["id"], inbox["items"][0]["id"]))["body"] == "code 55"
            # a preview gets its https link on the verified domain
            await owner.write("site/index.html", "hi")
            dep = await owner.deploy("cd site && python3 -m http.server $PORT --bind 127.0.0.1", "site")
            assert dep["public"].startswith("https://arivax.com/p/") and S.Box.public_link(dep["path"], dep["public"]) == dep["public"]
            await owner.stop_app("site")
            assert (await owner.domain_remove("arivax.com"))["ok"]
        finally:
            await owner.reset()
            await srv.close()

    asyncio.run(go())


@pytest.mark.skipif(not hasattr(os, "geteuid") or os.geteuid() != 0, reason="the isolation needs root (as in the container)")
def test_accounts_are_isolated_from_each_other(monkeypatch):
    root = pathlib.Path(tempfile.mkdtemp(prefix="sbiso", dir="/tmp"))
    root.chmod(0o755)
    server = load_server(root / "ws", monkeypatch, isolate="1")
    from modules import sandbox as S

    async def go():
        srv = TestServer(server.make_app())
        await srv.start_server()
        monkeypatch.setenv("SANDBOX_URL", str(srv.make_url("")).rstrip("/"))
        monkeypatch.setenv("SANDBOX_TOKEN", "t" * 24)
        a, b = S.Box("u1"), S.Box("u2")
        try:
            await a.write("secret.txt", "A-secret")
            who_a = (await a.sh("id -u"))["out"].strip()
            who_b = (await b.sh("id -u"))["out"].strip()
            assert who_a != who_b and int(who_a) >= 20000 and int(who_b) >= 20000        # two accounts, two unix users, never root
            probe = await b.sh(f"cat {root}/ws/u1/secret.txt; ls {root}/ws; rm -rf {root}/ws/u1; cat /proc/{os.getpid()}/environ; cat {root}/ws/.state/uids.json")
            assert "A-secret" not in probe["out"] and probe["out"].strip() == "" and probe["err"].count("Permission denied") >= 4
            assert (await a.read("secret.txt"))["text"] == "A-secret"                     # still there
            await b.sh(f"ln -s {root}/ws/u1/secret.txt link; ln -s {root}/ws/.state/uids.json .deploy-app.log")
            with pytest.raises(RuntimeError, match="leaves the workspace"):
                await b.read("link")
            dep = await b.deploy("echo hi; sleep 3", "app")
            assert "hi" in dep["log"] and "uids" not in dep["log"]                          # a planted symlink as the log file reads / writes nothing foreign
            assert "A-secret" not in str(await b.app_logs("app"))
            await a.write("big/x.txt", "x")
            assert (await a.ls("."))["items"]
        finally:
            await a.reset()
            await b.reset()
            await srv.close()

    asyncio.run(go())


# ------------------------------------------------------------------ 5. `.sb` for every account
def test_sb_is_open_to_every_account_but_domains_and_the_free_shell_are_the_owners(tmp_path, monkeypatch):
    server = load_server(tmp_path / "ws", monkeypatch)
    from modules import sandbox as S
    from tests.test_v1170 import make_db

    class Ev:
        chat_id = 5
        id = 9
        message = type("M", (), {"media": None})()
        is_reply = False

        def __init__(self, text):
            self.pattern_match = type("M", (), {"group": lambda s, i: text})()
            self.out = []

        async def reply(self, text, **kw):
            self.out.append(text)

        async def edit(self, text, **kw):
            self.out.append(text)

    class Client:
        _hapoyi_me_id = 11

        def __init__(self, owner):
            self._hapoyi_is_owner = owner

        def on(self, builder=None):
            def reg(fn):
                self.handler = fn
                return fn
            return reg

    async def go():
        srv = TestServer(server.make_app())
        await srv.start_server()
        monkeypatch.setenv("SANDBOX_URL", str(srv.make_url("")).rstrip("/"))
        monkeypatch.setenv("SANDBOX_TOKEN", "t" * 24)
        db = await make_db()
        guest, boss = Client(False), Client(True)
        S.setup(guest, db)
        S.setup(boss, db)
        try:
            e = Ev("sh echo hello")
            await guest.handler(e)
            assert "hello" in e.out[0]                                              # a normal account can use the sandbox
            e = Ev("sh rm -rf /")
            await guest.handler(e)
            assert "مجاز نیست" in e.out[0]                                          # ... but the safety rules apply to it
            e = Ev("domain add example.com")
            await guest.handler(e)
            assert "فقط اکانت اصلی" in e.out[0]
            e = Ev("domain list")
            await boss.handler(e)
            assert "دامنه" in e.out[0]
            e = Ev("help")
            await guest.handler(e)
            assert ".sb domain" in e.out[0]
        finally:
            await S.Box("u11").reset()
            await srv.close()

    asyncio.run(go())


# ------------------------------------------------------------------ 6. the `.mail` panel
class FakeBox:
    def __init__(self, items=None, mails=None):
        self.items = items or []
        self.mails = mails or {}
        self.created = 0

    async def mail_list(self):
        return {"items": self.items, "domains": 1}

    async def mail_new(self):
        self.created += 1
        it = {"id": 100 + self.created, "addr": f"new{self.created}@a.com", "created": time.time(), "expires": time.time() + 3600, "count": 0, "last": 0}
        self.items.insert(0, it)
        return it

    async def mail_inbox(self, aid, limit=6, offset=0):
        rows = self.mails.get(aid, [])
        a = next((i for i in self.items if i["id"] == aid), None)
        if a is None:
            raise RuntimeError("sandbox 404: no such inbox")
        return {"ok": True, "address": a, "total": len(rows), "items": rows[offset:offset + limit]}

    async def mail_message(self, aid, mid):
        return {"id": mid, "sender": "bank <b@x.com>", "subject": "code", "body": "1234 " * 2000, "attachments": [], "ts": time.time()}

    async def mail_delete(self, aid):
        self.items = [i for i in self.items if i["id"] != aid]
        return {"ok": True}


def make_items(n):
    return [{"id": i + 1, "addr": f"user{i:03d}@arivax.com", "created": time.time(), "expires": time.time() + 86400, "count": i % 3, "last": 0} for i in range(n)][::-1]


def test_mail_home_buttons_and_get_mail_always_makes_a_new_address():
    from modules import mailpanel as M

    async def go():
        box = FakeBox()
        text, rows = await M.home_view(box, 5)
        assert "Get mail" in str(datas(rows)) or len(rows) == 2
        labels = [b.text for r in rows for b in r]
        assert any("Get mail" in x for x in labels) and any("Update" in x for x in labels) and any("See all inboxes" in x for x in labels)
        first = await box.mail_new()
        text, rows = await M.home_view(box, 5)
        assert first["addr"] in text
        second = await box.mail_new()                                           # «Get mail» with an address already there -> a NEW one
        text, _ = await M.home_view(box, 5)
        assert second["addr"] in text and first["addr"] not in text

    asyncio.run(go())


def test_mail_all_inboxes_paginates_and_every_page_fits_a_telegram_message():
    from modules import mailpanel as M

    async def go():
        box = FakeBox(make_items(30))
        seen = set()
        page = 0
        while True:
            text, rows = await M.inboxes_view(box, 5, page)
            assert len(text) < 4096
            flat = datas(rows)
            assert any(d.endswith(b":h") or b":h" in d for d in flat)             # «back to the main page» is on every page
            seen.update(re.findall(r"user\d{3}@arivax\.com", text))
            nxt = [d for d in flat if d.startswith(b"ml:") and re.search(rb":i:%d$" % (page + 1), d)]
            if not nxt:
                break
            page += 1
        assert len(seen) == 30 and page >= 3                                     # every inbox is reachable, in several pages
        first = await M.inboxes_view(box, 5, 0)
        assert "◀️" not in [b.text for r in first[1] for b in r] and "▶️" in [b.text for r in first[1] for b in r]   # no «left» arrow on the first page
        short = await M.inboxes_view(FakeBox(make_items(3)), 5, 0)
        labels = [b.text for r in short[1] for b in r]
        assert "▶️" not in labels and "◀️" not in labels and len(short[1]) == 4              # 3 inboxes + back: no arrows

    asyncio.run(go())
    pages = M.fit_pages(["x" * 1000] * 5)
    assert len(pages) == 2 and sum(len(p) for p in pages) == 5                    # long lines split by size, not only by count


def test_mail_panel_views_for_mails_and_back_buttons():
    from modules import mailpanel as M

    async def go():
        items = make_items(2)
        mails = {items[0]["id"]: [{"id": i, "sender": f"s{i} <s@x.com>", "subject": f"subject {i}", "preview": "p", "ts": time.time()} for i in range(1, 15)]}
        box = FakeBox(items, mails)
        text, rows = await M.address_view(box, 5, items[0]["id"], 0)
        assert "14 پیام" in text and any(b":a:%d:1" % items[0]["id"] in d for d in datas(rows))
        text, rows = await M.message_view(box, 5, items[0]["id"], 3, "h")
        assert len(text) < 4096 and any(d.endswith(b":h") for d in datas(rows))      # back from a mail opened on the main page -> the main page
        _, rows = await M.message_view(box, 5, items[0]["id"], 3, "2")
        assert any(b":a:%d:2" % items[0]["id"] in d for d in datas(rows))            # ... from an inbox page -> that inbox page
        text, rows = await M.address_view(box, 5, 999, 0)
        assert "پیدا نشد" in text

    asyncio.run(go())


def test_mail_panel_belongs_to_its_opener(monkeypatch):
    from modules import mailpanel as M

    class Fleet:
        def runtime_for_user(self, uid):
            return object() if uid in (1, 2) else None

    monkeypatch.setattr(M, "_fleet", Fleet())
    box = FakeBox(make_items(2))
    monkeypatch.setattr(M, "Box", lambda session: box)

    async def go():
        stranger = FakeEvent(2, M.data(1, "h"))                                  # account 2 presses a button of the panel of account 1
        await M.on_click(stranger)
        assert stranger.answers[0][1] is True and not stranger.edits
        owner = FakeEvent(1, M.data(1, "i", 0))
        await M.on_click(owner)
        assert owner.edits and "همهٔ inboxها" in owner.edits[0][0]
        created = FakeEvent(1, M.data(1, "g"))
        await M.on_click(created)
        assert box.created == 1 and "آدرس جدید" in created.edits[0][0]
        for d in datas(created.edits[0][1]["buttons"]):
            assert len(d) <= 64

    asyncio.run(go())


def test_old_volume_owned_by_old_user_does_not_stop_the_server(tmp_path):
    """The /workspace volume of 1.19.6 belongs to uid 10001; the new server is root WITHOUT DAC_OVERRIDE and used to die with
    `PermissionError: /workspace/.state`. It now takes the folder over (CAP_CHOWN) before it touches `.state`."""
    import os
    import shutil
    import subprocess
    import sys

    if os.geteuid() != 0 or not shutil.which("setpriv"):
        pytest.skip("needs root + setpriv")
    ws = tmp_path / "ws"
    ws.mkdir()
    os.chown(ws, 10001, 10001)
    os.chmod(ws, 0o755)
    os.chmod(tmp_path, 0o755)
    code = "import sys; sys.path.insert(0, 'sandbox_server'); import server, os; st = os.stat(os.environ['SANDBOX_ROOT']); print(st.st_uid, oct(st.st_mode & 0o777))"
    res = subprocess.run(["setpriv", "--bounding-set=-dac_override,-dac_read_search,-fowner", "--inh-caps=-all", sys.executable, "-c", code],
                         cwd=str(pathlib.Path(__file__).resolve().parents[1]), capture_output=True, text=True, timeout=60,
                         env={**os.environ, "SANDBOX_TOKEN": "t" * 24, "SANDBOX_ROOT": str(ws)})
    assert res.returncode == 0, res.stderr[-400:]
    assert res.stdout.split() == ["0", "0o711"]
    assert (ws / ".state").is_dir()


def test_compose_gives_the_server_the_rights_it_needs():
    """root in the container (cap_drop ALL) can enter / chmod the 0700 folders of the accounts only with DAC_OVERRIDE + FOWNER."""
    text = (ROOT / "sandbox_server" / "docker-compose.yml").read_text("utf-8") if "ROOT" in globals() else (pathlib.Path(__file__).resolve().parents[1] / "sandbox_server" / "docker-compose.yml").read_text("utf-8")
    line = next(l for l in text.splitlines() if l.strip().startswith("cap_add:"))
    for cap in ("SETUID", "SETGID", "CHOWN", "KILL", "DAC_OVERRIDE", "FOWNER"):
        assert cap in line
    assert "cap_drop: [ALL]" in text
