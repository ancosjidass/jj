"""1.19.6: a `.aiknow add هویت | ...` note is the AI's identity in every `.ask` answer (even a plain question that has nothing to do with the bot)."""
from __future__ import annotations

import asyncio
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from services import knowledge as K  # noqa: E402


def test_identity_note_reaches_plain_and_bot_answers(tmp_path):
    store = K.KnowledgeStore(tmp_path / "k.json")
    store.add("اسم تو «موش تاریکس» است و علی ساختت.", "هویت")
    store.add("قیمت اشتراک ۱۰۰ تومان", "قیمت")
    assert "موش تاریکس" in store.identity() and "۱۰۰" not in store.identity()
    seen = []

    async def ask(messages, **kw):
        seen.append(messages[0]["content"])
        return "ok", None

    for q in ("اسمت چیه؟ تو GPT-4 هستی؟", "چطوری پیام رو زمان‌بندی کنم؟ (دستور ربات)"):
        asyncio.run(K.smart_answer(q, ask, store=store))
    assert seen and all("موش تاریکس" in s and "Never say you are GPT" in s for s in seen), seen
    empty = K.KnowledgeStore(tmp_path / "e.json")
    asyncio.run(K.smart_answer("سلام", ask, store=empty))
    assert "YOUR IDENTITY" not in seen[-1]
