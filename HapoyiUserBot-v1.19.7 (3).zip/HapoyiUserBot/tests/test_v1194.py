"""1.19.4: `.gai do` (owner of a second account talks to the group AI) - the pure part: prompt + which commands exist for it."""
from __future__ import annotations

import json
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from services import aiagent as A  # noqa: E402


def test_owner_group_prompt_has_every_group_feature_and_nothing_private():
    system = A.build_group_messages("کپچا رو روشن کن", prefix=".", reply_info=None, owner=True)[0]["content"]
    for cmd in (".captcha", ".delmes", ".linkguard", ".filter", ".flood", ".welcome", ".mute", ".sched", ".modai"):
        assert cmd in system, cmd
    for private in (".friend", ".autoreply", ".dl ", ".do ", ".echo", ".lic", ".backup"):
        assert private not in system, private
    admin = A.build_group_messages("x", prefix=".", reply_info=None, asker="Ali")[0]["content"]
    assert ".captcha" in admin and ".delmes" in admin             # 1.19.5: the admins' AI and `.gai do` are ONE brain (same commands)
    assert ".gbot" in system and ".gbot" not in admin              # only the owner decides who may control the group


def test_owner_plan_keeps_group_commands_and_rejects_the_rest():
    raw = json.dumps({"actions": [{"cmd": ".captcha on 5m"}, {"cmd": ".delmes 50"}, {"cmd": ".linkguard on delete"}, {"cmd": ".friend add"},
                                  {"cmd": ".do x"}, {"cmd": ".lic new 30d"}, {"cmd": ".gai off"}]})
    plan = A.parse_plan(raw, ".", set(A.OWNER_GROUP_COMMANDS))
    assert [a.name for a in plan.actions] == ["captcha", "delmes", "linkguard"]
    assert len(plan.rejected) == 4
    assert "gai" not in A.OWNER_GROUP_COMMANDS and "do" not in A.OWNER_GROUP_COMMANDS and "friend" not in A.OWNER_GROUP_COMMANDS
