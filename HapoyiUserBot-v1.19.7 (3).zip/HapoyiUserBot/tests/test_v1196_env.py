"""1.19.6: an empty path variable of .env (`AI_KNOWLEDGE_FILE=` as in .env.example) means "default", never Path("") == "." (IsADirectoryError on `.aiknow`)."""
from __future__ import annotations

import importlib
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))


def test_empty_env_paths_fall_back_to_the_defaults(monkeypatch):
    for var in ("AI_KNOWLEDGE_FILE", "HAPOYI_DB", "HAPOYI_SESSION"):
        monkeypatch.setenv(var, "   ")
    import config
    from services import knowledge
    importlib.reload(config)
    importlib.reload(knowledge)
    try:
        assert knowledge.KNOWLEDGE_FILE.name == "ai_knowledge.json" and str(knowledge.KNOWLEDGE_FILE) != "."
        assert config.DB_PATH.name == "hapoyi.db" and config.SESSION_PATH.name == "hapoyi"
    finally:
        monkeypatch.undo()
        importlib.reload(config)
        importlib.reload(knowledge)
