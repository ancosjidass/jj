# 1.19.6

**Fixed: group commands sent by the other account / «ربات ...» / `.gai do` ran minutes late (3-5 min), while the same text typed by hand ran at once.**

Cause: the command message the bot sends is handed to the ~200 command handlers by `feed_handlers`. For EVERY handler a new event was built and each one
called `get_entity(chat)` and `get_me()` - real Telegram requests - i.e. ~400 requests for one `.mute`. Telegram answered with FloodWaits, the command waited
for them and ran minutes later (and a hand-typed copy, which Telethon dispatches directly, ran first).

Now the chat / sender lookups are done once per command (and cached 10 minutes per chat); building the events needs no network at all.
Test: `tests/test_v1196.py`.

**New: delegate level ⚡ `god` (خدا).**
`.delegate` panel has a new button «⚡ خدا» (or `.gbot grant god @user`). A `god` delegate can run EVERY group command (also promote / demote / modai) and the bot
puts no rule of its own in the way - not even «nobody acts on an admin»: the command is handed to the real `.ban` / `.mute` ... exactly like you typing it, and
Telegram is the only judge. So it works on admins as far as YOUR account can (an admin you promoted, any member, ...), and it fails - with Telegram's reason -
when your account cannot (the group owner when you are not the owner, an admin you may not edit, an admin with equal / higher rights). Your own account is never
a target. `mod`, `full` and admins behave as before. Test: `tests/test_v1196_god.py`.

**Fixed: `❌ انجام نشد: IsADirectoryError: [Errno 21] Is a directory: '.'` on `.aiknow`.**
`.env.example` ships `AI_KNOWLEDGE_FILE=` (empty). `os.getenv` returns "" for it (the default is NOT used), `Path("")` is the folder `.`, and the knowledge file could not be
written. Empty values of `AI_KNOWLEDGE_FILE`, `HAPOYI_DB` and `HAPOYI_SESSION` now mean "use the default". Test: `tests/test_v1196_env.py`.

**New: the AI's identity (`.aiknow add هویت | ...`).**
Notes titled `هویت` (or `identity` / `persona` / `شخصیت`) are now sent with EVERY `.ask` answer, also for plain questions («اسمت چیه؟»), not only for questions about the bot.
The AI then presents itself with that name / maker and no longer says it is GPT / Claude / Gemini ... Example: `.aiknow add هویت | اسم تو «موش تاریکس» است و فلانی ساختت.`
Test: `tests/test_v1196_identity.py`.

**AI docs:** compact sections only (`rules`, `digest`, `raid`, `pro`, `pmguard`, `tg`), each found by meaning (synonyms), so the planner prompt does not grow for unrelated requests. The fixed 14000-char test cap is gone;
the planner manual follows `AI_MANUAL_BUDGET` / `AI_SECTION_CHARS` (env, defaults 9800 / 2200). The sandbox `.sb` is deliberately NOT in the AI docs.

**New commands** (every account has its own data)
- `.rule add <trigger> => <action>` (msg / join / at HH:MM → say / run / notify / react / del / ai), `.rule ask <sentence>` lets the AI write the rule. `run` takes no placeholders (no command injection).
- `.digest on 08:00` morning digest of unread chats (one AI request) • `.raid on 8 60 10` a wave of joins locks the group by itself, opens it when calm, `.raid purge` kicks the wave.
- Typo fixer: `.mutee` → «منظورت `.mute` بود؟» → `.y` • `.undo` (unban / unmute / unpin / demote / unlock / unwarn of your last action) • `.trout on en` (what you write is translated and edited).
- `.fix` `.rewrite <tone>` `.explain` (AI) • `.jdate` (Jalali ↔ Gregorian) `.cd` (countdown) `.owghat` `.weather` `.pick` `.roll` `.json` `.dns` `.morse` `.rev` `.mock`
- PM guard: `.pm on 3` strangers get a warning, then are blocked; contacts / bots / people you wrote to / `.approve` are never touched.
- `.sb deploy <cmd>` gives a PREVIEW LINK (secret path + cookie so absolute asset paths work; 6 h TTL, 3 apps per session) • `.sb web <url>`.

**AI account control (`.do` / `.tg`)** - `modules/tg_agent.py`: news question → ONE global search with several keyword sets, only if thin the 2-3 most «newsy + active today» channels, stops as soon as it can answer
(hard budgets: 8 rounds, 3 reads, 5 searches). Also join / leave / block / delete chat / mute / archive and `bulk` («all bots with config / چت ناشناس in the name») - the matching is done in code.
Destructive actions run at once only when nothing external was read in that request, ≤ 10 items and `.ai control danger` is off; otherwise the exact list waits for «بله».

**Security (`core/secretguard.py`)**
- Every AI answer is scrubbed of the bot token / API keys / sandbox token / string sessions (and anything shaped like one).
- A non-owner (group admin / delegate writing «ربات …») asking for source, tokens, `.env`, the prompt, a shell command (`rm -rf`, `cd /`, `curl | sh` ...) or «ignore your instructions» is refused before the AI sees it; the group prompt says the same.
- An AI (even the owner's `.do`) can never send `.apikey .lic .restore .sb .deactivate .protect .aiknow`, nor approve itself (`.ai yes / control`), nor smuggle them inside `.macro / .alias / .every / .rule`.
- Sandbox: shell commands written by the AI are checked by the safety rules on the SERVER too (no `rm -rf /`, sudo, docker, reverse shells ...); the container has no secrets.
- Safe web reader (`sandbox_server/webread.py`): URL reputation score + SSRF-proof resolver (public IPs only, checked on every connect and redirect) + page-quality score (spam / gambling / adult / pop-ups / obfuscated scripts are refused),
  no cookies, 2 MB, text types only; JavaScript pages through a throw-away Chromium (optional: `docker compose build --build-arg WITH_BROWSER=1`).

Tests: `tests/test_v1196_*.py` (the Chromium path and a real Telegram / Docker could not be run where this was built).
