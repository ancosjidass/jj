# 1.19.7 — Harbor

## Fixed: someone else could press the buttons of your panel
Two people who both run the self meet in a group. A sends `.menu`; B (who also has the self) pressed A's buttons and the bot treated B as «an owner»: the panel of A showed B's data / ran B's actions.
Now every button of `.menu`, `.models` and `.mail` carries the id of the account that opened the panel (`ui:dash~2xk9a`, base 36, still under Telegram's 64 bytes) and a click of anybody else is refused
with «این پنل را کس دیگری باز کرده؛ برای خودت بنویس .menu». The next pages the owner opens keep the tag. Panels that were already posted (no tag) keep working as before.
(`dl:` / `gbd:` / `cap:` panels already belonged to one account; the XO / rock-paper-scissors duels are meant for two people.) Code: `utils/panel_owner.py`, `modules/ui.py`. Test: `tests/test_v1197.py`.

## `.sb` for every account
The sandbox is no longer only for the main account: every account that runs the self (main, licensed second accounts) can use `.sb`, `.sb deploy`, `.sb web`, `.mail` ...
Because strangers' accounts now share one server, the server separates them **inside the container** (`sandbox_server/server.py`):
- every session (= Telegram account) gets its own unix user (uid 20000+, kept in `.state/uids.json`), its folder is mode 0700, its commands run as that user (`ulimit` 256 processes, file size 4 GB), its commands never run as root;
- the file API (write / edit / read / ls / upload / download / logs) runs as that user too (fsuid per thread), so a symlink planted in a workspace can never make the server read or overwrite a file of another account or of the server;
- the token, the domains and the mail live in `.state/` (root only) and in the environment of the server; a session can read neither (`/proc/<pid>/environ` of the server is closed to it);
- limits per session: 4 commands at once, 2 GB of files, 3 apps; the commands of an account that is NOT the owner pass the same safety rules as the AI's (`rm -rf /`, `sudo`, `docker`, reverse shells ... are refused),
  the owner's own `.sb sh` stays free; `.sb domain ...` is the owner's only.
- docker-compose: the server needs `cap_add: [SETUID, SETGID, CHOWN, KILL, DAC_OVERRIDE, FOWNER]` (nothing else; the last two let the root server enter and chmod the 0700 folders of the accounts - the accounts themselves never get them); an old volume is handed over to the new users automatically the first time a session is used.
Tested for real as root: account B can neither read, list nor delete the files of A, nor read the server's environment or `.state`. `SANDBOX_ISOLATE=0` switches the isolation off (not for a shared server).

## Verified domains + instant SSL — `.sb domain` (owner)
```
.sb domain add example.com      DNS check (A / MX / wildcard) + the SSL certificate is ordered RIGHT NOW (one TLS handshake through Caddy) -> report
.sb domain check example.com    the same again (after you fixed the DNS)         .sb domain list | del <domain> | mail <domain> on|off
```
- A sub-domain of a domain that already has SSL needs **nothing**: `.sb domain add s.example.com` answers «covered» and any `x.example.com` is served (its certificate comes on the first visit).
- Caddy (docker-compose of `sandbox_server/`, on-demand TLS) asks the sandbox `/tls/ask` before it orders a certificate: only registered domains and their sub-domains are approved, so nobody can make the server order certificates for foreign names.
- Previews (`.sb deploy`) now come as `https://<one of your domains>/p/<secret>/`. Only `/p/*` and the cookie of a preview are reachable on the public domains; the API stays on `127.0.0.1:8765`.
- DNS to set: `A example.com → server`, `A *.example.com → server`, `MX example.com 10 example.com`, `MX *.example.com 10 example.com` (the bot prints them when something is missing).

## `.mail` — temporary mail panel (every account)
`.mail` → an inline panel sent by your account **via the Assistant Bot** (it must have inline mode: @BotFather `/setinline`).
- **📧 Get mail** — a random address on one of the verified domains: `abcd@example.com`, 4-7 random characters; when the domain also answers for sub-domains (wildcard MX) half of the addresses get a random 4-7 character sub-domain label: `abcd@efgh.example.com`.
  No address yet → your first one; you already have one → a NEW one.
- **🔄 Update** — looks for new mails (makes the first address when you have none). The last 3 mails of the current address are on the main page; tap 📨 1/2/3 to read one.
- **📂 See all inboxes** — every address with its number of mails; when they do not fit one Telegram message: ◀️ ▶️ pages and «🏠 برگشت به صفحهٔ اصلی» (the page `.mail` opened with). A tap on an address lists its mails (◀️ ▶️ again), a tap on a mail shows it, 🗑 deletes an inbox.
- Mails are received by the SMTP receiver of the sandbox (`sandbox_server/tempmail.py`, port 25 → 2525): only for addresses that exist (everything else is refused), 24 h life (`SANDBOX_MAIL_TTL_HOURS`), 40 mails per address, 30 addresses per account, text only (attachments are not kept).
- The panel answers only the account that opened it.
Your server needs port 25 open (some providers block it - ask them) and the MX records above.

## Upgrade from an older sandbox volume (fixed in this zip)
The first 1.19.7 build died at start with `PermissionError: /workspace/.state` when the Docker volume came from 1.19.6 (it belongs to the old unix user, uid 10001, and the server is root without DAC_OVERRIDE).
The server now takes `/workspace` over first (CAP_CHOWN is enough) - no manual `chown` / `docker volume rm` is needed. Test: `tests/test_v1197.py::test_old_volume_owned_by_old_user_does_not_stop_the_server`.

## Fixed before release: the container has only a few rights
Everything above was first tested as full root; in the real container (`cap_drop: ALL`) the server could not create `.state` in an old volume, could not `chmod` a folder after giving it to an account, and could not enter the 0700 folder of an account (HTTP 500 on `.sb sh`, `.mail` ...).
Fixed: the server takes `/workspace` over first, `chmod` before `chown`, and the compose file adds `DAC_OVERRIDE` + `FOWNER`. Re-tested under exactly these rights (`setpriv --bounding-set`): old session folders keep working, account B cannot read A or `.state`, symlink escape refused, deploy + `.mail` answer.
**You must replace `sandbox_server/server.py` AND `docker-compose.yml`, then `docker compose up -d --build`.**

## Upgrade
1. `cd sandbox_server && docker compose up -d --build` (adds Caddy + the SMTP port; the `.env` there keeps `SANDBOX_TOKEN`, optional `SANDBOX_PUBLIC_IP`).
2. Restart the bot. 3. `.sb domain add yourdomain.com` (main account).
