"""AI support assistant for the self itself + the optional smart helper.

    .guide <سؤال>                 how do I use the self?  (any language / words: «چجوری پیام رو زمان‌بندی کنم؟» → .later)
                                  `.ask` answers the same way automatically when the question is about the bot.
    .aiguide on|off|status        smart helper: when YOU look confused / mistype a command / get an error / laugh, the AI decides
                                  by the situation whether to say something (silence is the default). Off = only .ask / .guide answer.
    .aiguide fun on|off           allow the light-hearted lines too            .aiguide where chat|saved   (default: chat)
    .aiguide ttl <sec>            help bubbles delete themselves (0 = keep)    .aiguide here on|off  (this chat)   .aiguide ctx on|off
    .aiknow ...                   (MAIN account only) teach the AI: prices, how to buy, rules, FAQ - every customer account uses it

Everything the AI says starts with 🤖. The helper never answers for you and never replies to other people's messages.
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import time
from datetime import datetime
from zoneinfo import ZoneInfo

from telethon import events

from core.identity import is_owner
from services import knowledge as K
from services.aithreads import publish

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
TZ_NAME = os.getenv("TIMEZONE", "Asia/Tehran") or "Asia/Tehran"
MARK = K.HELP_MARK
IMPORT_MAX_BYTES = 300 * 1024
GUIDE_USAGE = (f"فرمت: `{PREFIX}guide سؤالت دربارهٔ سلف` مثلاً `{PREFIX}guide چجوری یه پیام رو زمان‌بندی کنم؟`\n"
               f"(`{PREFIX}ask` هم وقتی سؤال دربارهٔ سلف باشه همین‌طور جواب می‌ده.)")


def _tz() -> ZoneInfo:
    try:
        return ZoneInfo(TZ_NAME)
    except Exception:  # noqa: BLE001
        return ZoneInfo("UTC")


def _num_env(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, "") or default)
    except ValueError:
        return default


def cut(text: str, limit: int = 3900) -> str:
    return text if len(text) <= limit else text[: limit - 1] + "…"


async def setup(client, db):
    store = K.KnowledgeStore()
    st = {"on": bool(await db.get_kv("aiguide_on", False)), "fun": bool(await db.get_kv("aiguide_fun", True)),
          "where": str(await db.get_kv("aiguide_where", "chat") or "chat"), "ttl": int(await db.get_kv("aiguide_ttl", 25) or 0),
          "ctx": bool(await db.get_kv("aiguide_ctx", True)), "tips": bool(await db.get_kv("aiguide_tips", True)), "tip_last": {}, "off_chats": {int(x) for x in (await db.get_kv("aiguide_off_chats", []) or [])},
          "last": {}, "aliases": (0.0, set())}

    async def is_main() -> bool:
        """The owner: the main account, or any account whose Telegram id is HAPOYI_OWNER_ID."""
        return await is_owner(client)

    def ask_fn():
        return getattr(client, "_hapoyi_ask_ai", None)

    async def reply_text(event) -> str:
        if not event.is_reply:
            return ""
        m = await event.get_reply_message()
        return (getattr(m, "message", "") or "").strip() if m else ""

    # ------------------------------------------------------------------ .guide
    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}guide(?:\s+(.*))?$"))
    async def guide(event):
        q = (event.pattern_match.group(1) or "").strip()
        ctx = await reply_text(event)
        if not q and not ctx:
            return await event.reply(GUIDE_USAGE)
        ask = ask_fn()
        if ask is None:
            return await event.reply("❌ ماژول هوش مصنوعی بارگذاری نشده (`.health`).")
        await event.edit("🤖 …")
        content = f"{q}\n\n---\n{ctx}" if (q and ctx) else (q or ctx)
        text, err = await K.smart_answer(content[:3000], ask, force=True, store=store)
        if not text:
            return await event.edit(err)
        await publish(client, db, event, f"🤖 {q or ctx[:80]}", text, kind="guide", question=(q or ctx)[:1500])

    # ------------------------------------------------------------------ .aiknow (main account only)
    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}aiknow(?:\s+(.*))?$"))
    async def aiknow(event):
        if not await is_main():
            return await event.reply("⛔ فقط اکانت اصلی (مالک) می‌تونه به هوش مصنوعی چیزی یاد بده؛ ولی همهٔ اکانت‌ها ازش استفاده می‌کنن.")
        raw = (event.pattern_match.group(1) or "").strip()
        parts = raw.split(None, 1)
        word = parts[0].lower() if parts else "status"
        rest = parts[1].strip() if len(parts) > 1 else ""
        if word in {"status", "help"}:
            return await event.reply(
                f"🧠 دانش هوش مصنوعی: {len(store.items())} مورد / {store.total_chars()} کاراکتر\n"
                f"`{PREFIX}aiknow add عنوان | متن` (یا Reply روی یک پیام)\n`{PREFIX}aiknow list` | `show <id>` | `del <id>` | `clear confirm`\n"
                f"`{PREFIX}aiknow import` (Reply روی فایل txt/md؛ `import replace` اول همه چیز را پاک می‌کند)\n"
                f"`{PREFIX}guide سؤال` برای امتحان کردن جواب.\n"
                "راهنمای دستورهای سلف خودش همیشه به‌روز خوانده می‌شود؛ اینجا فقط چیزهای اضافه (قیمت، روش خرید، قوانین، پشتیبانی، سؤال‌های رایج) را بنویس.")
        if word == "add":
            text = rest or await reply_text(event)
            title = ""
            if "|" in text[:80]:
                title, text = (x.strip() for x in text.split("|", 1))
            nid, why = store.add(text, title)
            return await event.reply(f"✅ به دانش اضافه شد (#{nid})." if nid else f"❌ {why}")
        if word == "list":
            items = store.items()
            if not items:
                return await event.reply("🧠 خالیه. با `aiknow add` شروع کن.")
            lines = [f"#{i['id']} {('[' + i['title'] + '] ') if i.get('title') else ''}{i['text'][:70].replace(chr(10), ' ')}" for i in items[-40:]]
            return await event.reply(cut("🧠 دانش:\n" + "\n".join(lines)))
        if word == "show" and rest.isdigit():
            hit = next((i for i in store.items() if int(i["id"]) == int(rest)), None)
            return await event.reply(cut(hit["text"]) if hit else "ℹ️ چنین موردی نیست.")
        if word in {"del", "rm", "delete"} and rest.isdigit():
            return await event.reply("🗑 حذف شد." if store.delete(int(rest)) else "ℹ️ چنین موردی نیست.")
        if word == "clear":
            if rest.lower() != "confirm":
                return await event.reply(f"⚠️ همه دانش پاک می‌شود. تأیید: `{PREFIX}aiknow clear confirm`")
            return await event.reply(f"🗑 {store.clear()} مورد پاک شد.")
        if word == "import":
            m = await event.get_reply_message() if event.is_reply else None
            doc = getattr(m, "document", None)
            if m is None or doc is None:
                return await event.reply("❌ روی یک فایل متنی (txt / md) Reply کن.")
            if int(getattr(doc, "size", 0) or 0) > IMPORT_MAX_BYTES:
                return await event.reply(f"❌ فایل بزرگ‌تر از {IMPORT_MAX_BYTES // 1024} کیلوبایت است.")
            data = await client.download_media(m, file=bytes)
            try:
                text = data.decode("utf-8-sig")
            except (UnicodeDecodeError, AttributeError):
                return await event.reply("❌ فایل باید متن UTF-8 باشد.")
            if rest.lower() == "replace":
                store.clear()
            added = skipped = 0
            for title, chunk in K.split_for_import(text):
                nid, _why = store.add(chunk, title)
                added += 1 if nid else 0
                skipped += 0 if nid else 1
            return await event.reply(f"✅ {added} بخش وارد شد" + (f" ({skipped} بخش جا نشد؛ سقف حجم)" if skipped else "") + ".")
        await event.reply(f"فرمت: `{PREFIX}aiknow` را بدون ورودی بزن تا راهنما را ببینی.")

    # ------------------------------------------------------------------ .aiguide (settings)
    async def save() -> None:
        await db.set_kv("aiguide_on", st["on"])
        await db.set_kv("aiguide_fun", st["fun"])
        await db.set_kv("aiguide_where", st["where"])
        await db.set_kv("aiguide_ttl", st["ttl"])
        await db.set_kv("aiguide_ctx", st["ctx"])
        await db.set_kv("aiguide_tips", st["tips"])
        await db.set_kv("aiguide_off_chats", sorted(st["off_chats"]))

    def status_text(chat_id: int | None = None) -> str:
        here = "" if chat_id is None else f"\nاین گپ: {'⛔ خاموش' if chat_id in st['off_chats'] else '✅ فعال'}"
        return (f"🤖 دستیار هوشمند: {'روشن ✅' if st['on'] else 'خاموش (فقط با ' + PREFIX + 'ask / ' + PREFIX + 'guide جواب می‌دهد)'}\n"
                f"شوخی/فان: {'روشن' if st['fun'] else 'خاموش'} | محل پاسخ: {'همان گپ' if st['where'] == 'chat' else 'Saved Messages'} | "
                f"حذف خودکار راهنما: {str(st['ttl']) + ' ثانیه' if st['ttl'] else 'ندارد'} | زمینهٔ گپ: {'روشن' if st['ctx'] else 'خاموش'} | "
                f"نکته‌های فوری: {'روشن' if st['tips'] else 'خاموش'}{here}\n\n"
                "• فقط پیام‌های خودت را می‌بیند. موقعیت‌های شناخته‌شده (لینک یوتیوب/اینستا/تیک‌تاک، «یادم بنداز»، «قیمت دلار»، «ترجمه کن»، «خلاصه کن»، «میرم»، «عکس بساز»، «سرچ کن»...) "
                "را با قانون محلی و بدون مصرف توکن می‌شناسد و یک نکتهٔ یک‌خطی می‌دهد (هر نکته در هر گپ حداکثر هر ۱۰ دقیقه).\n"
                "• فقط وقتی گیج/ارور/غلط‌تایپی/خنده یا لینک/متن بلند باشد از AI می‌پرسد و خودش تصمیم می‌گیرد؛ پیش‌فرض سکوت است.\n"
                "• برای تصمیم، چند پیام آخر همان گپ (بدون اسم‌ها) به سرویس AI فرستاده می‌شود؛ `ctx off` فقط پیام خودت را می‌فرستد.\n"
                f"`{PREFIX}aiguide on|off` | `tips on|off` | `fun on|off` | `where chat|saved` | `ttl 25` | `here on|off` | `ctx on|off`")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}aiguide(?:\s+(.*))?$"))
    async def aiguide_cmd(event):
        parts = (event.pattern_match.group(1) or "").lower().split()
        word = parts[0] if parts else "status"
        arg = parts[1] if len(parts) > 1 else ""
        if word in {"on", "off"}:
            st["on"] = word == "on"
            await save()
            return await event.reply("🤖 دستیار هوشمند روشن شد." if st["on"] else "🤖 دستیار هوشمند خاموش شد.")
        if word == "fun" and arg in {"on", "off"}:
            st["fun"] = arg == "on"
            await save()
            return await event.reply(f"🎭 شوخی/فان {'روشن' if st['fun'] else 'خاموش'} شد.")
        if word == "tips" and arg in {"on", "off"}:
            st["tips"] = arg == "on"
            await save()
            return await event.reply(f"💡 نکته‌های فوری {'روشن' if st['tips'] else 'خاموش'} شد (بدون مصرف توکن؛ مثلاً لینک یوتیوب ← .dl).")
        if word == "ctx" and arg in {"on", "off"}:
            st["ctx"] = arg == "on"
            await save()
            return await event.reply(f"✅ زمینهٔ گپ {'روشن' if st['ctx'] else 'خاموش'} شد.")
        if word == "where" and arg in {"chat", "saved"}:
            st["where"] = arg
            await save()
            return await event.reply("✅ پاسخ‌ها " + ("در همان گپ می‌آید." if arg == "chat" else "به Saved Messages می‌رود (شوخی‌ها هم)."))
        if word == "ttl" and arg.isdigit():
            st["ttl"] = max(0, min(int(arg), 3600))
            await save()
            return await event.reply("✅ راهنما بعد از " + (f"{st['ttl']} ثانیه پاک می‌شود." if st["ttl"] else "ماندگار است."))
        if word == "here" and arg in {"on", "off"}:
            (st["off_chats"].discard if arg == "on" else st["off_chats"].add)(int(event.chat_id))
            await save()
            return await event.reply("✅ در این گپ " + ("فعال شد." if arg == "on" else "خاموش شد."))
        await event.reply(status_text(int(event.chat_id)))

    # ------------------------------------------------------------------ the helper itself
    async def alias_words() -> set[str]:
        ts, words = st["aliases"]
        if time.monotonic() - ts > 60:
            try:
                words = {r["word"] for r in await db.fetchall("SELECT word FROM user_aliases")}
            except Exception:  # noqa: BLE001
                words = set()
            st["aliases"] = (time.monotonic(), words)
        return words

    async def used_today() -> int:
        return int(await db.get_kv("aiguide_used:" + datetime.now(_tz()).strftime("%Y-%m-%d"), 0) or 0)

    async def count_use() -> None:
        key = "aiguide_used:" + datetime.now(_tz()).strftime("%Y-%m-%d")
        await db.set_kv(key, int(await db.get_kv(key, 0) or 0) + 1)

    async def chat_lines(event) -> list[str]:
        """Last few messages of the chat with anonymous labels (owner / A / B): names never leave the server."""
        labels: dict[int, str] = {}
        out: list[str] = []
        try:
            async for m in client.iter_messages(event.chat_id, limit=6):
                if m.id == event.id:
                    continue
                body = (getattr(m, "message", "") or "").strip()
                if not body or body.startswith(MARK):
                    continue
                if getattr(m, "out", False):
                    who = "owner"
                else:
                    sid = int(getattr(m, "sender_id", 0) or 0)
                    who = labels.setdefault(sid, "ABCDEFGH"[len(labels) % 8])
                out.append(f"{who}: {body[:200]}")
        except Exception:  # noqa: BLE001
            return []
        out.reverse()
        return out

    async def failed_command(event) -> str:
        """The command the owner typed just before a bot error («❌ ...» is sent as a reply to it)."""
        try:
            if event.is_reply:
                m = await event.get_reply_message()
                if m is not None and (getattr(m, "message", "") or "").startswith(PREFIX):
                    return (m.message or "")[:200]
        except Exception:  # noqa: BLE001
            pass
        return ""

    async def deliver(event, kind: str, msg: str) -> None:
        text = f"{MARK} {cut(msg, 600)}"
        if st["where"] == "saved":
            await client.send_message("me", text)
            return
        sent = await event.reply(text)
        if kind == "help" and st["ttl"] and sent is not None:
            async def later():
                await asyncio.sleep(st["ttl"])
                try:
                    await sent.delete()
                except Exception:  # noqa: BLE001
                    pass
            asyncio.create_task(later())

    async def tip_allowed(chat_id: int, key: str) -> bool:
        """Each tip at most once per TIP_COOLDOWN per chat, and TIPS_DAILY tips a day: it never nags."""
        now = time.monotonic()
        if now - st["tip_last"].get((chat_id, key), -1e9) < _num_env("AIGUIDE_TIP_COOLDOWN", 600):
            return False
        day = "aiguide_tips_used:" + datetime.now(_tz()).strftime("%Y-%m-%d")
        used = int(await db.get_kv(day, 0) or 0)
        if used >= int(_num_env("AIGUIDE_TIPS_DAILY", 15)):
            return False
        st["tip_last"][(chat_id, key)] = now
        if len(st["tip_last"]) > 800:
            st["tip_last"].clear()
        await db.set_kv(day, used + 1)
        return True

    @client.on(events.NewMessage(outgoing=True))
    async def helper(event):
        if not st["on"]:
            return
        text = (event.raw_text or "").strip()
        if not text or getattr(event, "via_bot", None) or getattr(event, "fwd_from", None):
            return
        if (getattr(event, "is_channel", False) and not getattr(event, "is_group", False)) or int(event.chat_id) in st["off_chats"]:
            return
        if st["tips"]:  # free local tips first: no AI, no tokens
            tip = K.tip_kind(text)
            if tip is not None and await tip_allowed(int(event.chat_id), tip[0]):
                try:
                    await deliver(event, "help", tip[1])
                except Exception as exc:  # noqa: BLE001
                    log.debug("aiguide tip failed: %s", exc.__class__.__name__)
                return
        kind, detail = K.signal_kind(text, aliases=await alias_words())
        if kind is None or (kind == "fun" and not st["fun"]):
            return
        ask = ask_fn()
        if ask is None:
            return
        now = time.monotonic()
        gap = _num_env("AIGUIDE_COOLDOWN", 90) * (3 if kind == "fun" else 1)
        if now - st["last"].get(int(event.chat_id), -1e9) < gap:
            return
        if await used_today() >= int(_num_env("AIGUIDE_DAILY", 20)):
            return
        st["last"][int(event.chat_id)] = now
        if len(st["last"]) > 500:
            st["last"].clear()
        failed = await failed_command(event) if kind == "error" else ""
        seed = f"{detail} {failed} {text}"
        keys = [k for k, _s in K.score_sections(seed)][:2]
        docs = "\n\n".join(K.section_text(k, 1800) for k in keys)
        lines = await chat_lines(event) if st["ctx"] else []
        if failed:
            lines.append(f"owner (command that failed): {failed}")
        await count_use()
        out, _err = await ask(K.decision_messages(kind, detail, lines, text, "the owner", docs, st["fun"]), max_tokens=220, temperature=0.4)
        if not out:
            return
        decision = K.parse_decision(out, st["fun"])
        if decision is None:
            return
        try:
            await deliver(event, decision[0], decision[1])
        except Exception as exc:  # noqa: BLE001
            log.debug("aiguide deliver failed: %s", exc.__class__.__name__)
