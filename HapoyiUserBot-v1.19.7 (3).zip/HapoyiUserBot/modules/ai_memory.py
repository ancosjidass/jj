"""AI message ids, `.reply` and the AI memory switch (1.17.0).

Every AI answer starts with an id (`#13345 🤖 ...`).

    .reply <id> <text>      talk to that exact AI message: the AI knows what you asked and what it answered, and the bot
                            replies (a real Telegram reply) under the original AI message
    .reply <text>           with Reply on an AI message: the same, no id needed
    .storage on|off|status  memory switch (plain `.storage` / `.storage clean` stay the server-disk tool of modules/storage_janitor.py).   OFF (default): the last 60 answers of 3 days are kept (so `.reply <id>` and Reply work).
                            ON: up to 5000 answers are kept for good, and every `.ask` continues the recent conversation of its chat.
    .storage list           the latest ids                          .storage clear [all]   forget this chat (or everything)
    .ask -n <text>          one question without the stored conversation

A plain `.ask` written as a Reply on an AI message continues that conversation automatically (see modules/ai_tools.py);
`.ask` written as a Reply on somebody else's message reads THAT message first (and the one it answered).
"""
from __future__ import annotations

import logging
import os
import re

from telethon import events

from services import knowledge as K
from services.aithreads import HISTORY_PAIRS, LONG_KEEP_ROWS, SHORT_KEEP_DAYS, SHORT_KEEP_ROWS, get_threads, history_messages, publish, tag, trim_history

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)

REPLY_USAGE = (f"فرمت: `{PREFIX}reply 13345 متن تو` — به همان پیام هوش مصنوعی (با شناسهٔ #13345) جواب می‌دی و AI می‌دونه قبلاً چی پرسیدی و چی گفته.\n"
               f"یا روی یک پیام AI Reply کن و بنویس `{PREFIX}reply متن تو` (یا ساده `{PREFIX}ask متن تو`).")


def setup(client, db):
    threads = get_threads(client, db)

    def ask_fn():
        return getattr(client, "_hapoyi_ask_ai", None)

    # ------------------------------------------------------------------ .reply
    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}reply(?:\s+#?(\d{{4,9}})(?!\d))?(?:\s+(.*))?$"))
    async def reply_cmd(event):
        aid_s, text = event.pattern_match.group(1), (event.pattern_match.group(2) or "").strip()
        replied = await event.get_reply_message() if event.is_reply else None
        rec = None
        if aid_s:
            rec = await threads.by_aid(int(aid_s))
            if rec is None:
                return await event.reply(f"❌ پیام #{aid_s} پیدا نشد. بدون `{PREFIX}storage on` فقط {SHORT_KEEP_ROWS} پیام آخر / {SHORT_KEEP_DAYS} روز نگه داشته می‌شود؛ "
                                         f"با `{PREFIX}storage on` تا {LONG_KEEP_ROWS} پیام برای همیشه.")
        elif replied is not None:
            rec = await threads.find(event.chat_id, replied)
            if rec is None and K.is_ai_bubble(getattr(replied, "message", "") or ""):
                history, rec = await threads.history_for(event.chat_id, replied)  # an old bubble that is not in the database: use its text
        if rec is None:
            return await event.reply(REPLY_USAGE)
        if not text and replied is not None and not K.is_ai_bubble(getattr(replied, "message", "") or ""):
            text = (getattr(replied, "message", "") or "").strip()
        if not text:
            return await event.reply(REPLY_USAGE)
        ask = ask_fn()
        if ask is None:
            return await event.reply("❌ ماژول هوش مصنوعی بارگذاری نشده (`.health`).")

        parent = rec.get("aid")
        pairs = [(r["question"], r["answer"]) for r in await threads.chain(int(parent))] if parent else []
        if not pairs:  # an old bubble that is not in the database any more: its own text is the conversation
            pairs = [(rec.get("question", ""), rec.get("answer", ""))]
        history = history_messages(trim_history(pairs))
        await event.edit("🤖 …")
        answer, err = await K.smart_answer(text[:6000], ask, history=history)
        if not answer:
            return await event.edit(err)
        header = f"↩️ {tag(parent) if parent else ''} 🤖 {text[:80]}".replace("  ", " ")

        # A real Telegram reply under the original AI message (same chat). If that is not possible, the command message itself is edited.
        orig_msg = int(rec.get("msg_id") or 0)
        if orig_msg and int(rec.get("chat_id", 0)) == int(event.chat_id):
            try:
                new_id = await threads.new_id()
                body = f"{tag(new_id)} {header}\n\n{answer}"
                if len(body) > 3900:
                    body = body[:3899] + "…"
                sent = await client.send_message(event.chat_id, body, reply_to=orig_msg, link_preview=False)
                await threads.record(new_id, event.chat_id, int(getattr(sent, "id", 0) or 0), kind="reply", question=text[:3000], answer=answer, parent=parent)
                try:
                    await event.delete()
                except Exception:  # noqa: BLE001
                    pass
                return
            except Exception as exc:  # noqa: BLE001  (original message deleted, no rights ...)
                log.info("reply under #%s failed, editing instead: %s", parent, exc)
        await publish(client, db, event, header, answer, kind="reply", question=text[:3000], parent=parent)

    # ------------------------------------------------------------------ .storage
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}storage\s+(on|off|status|ai|list|clear)(?:\s+(all|chat))?$"))
    async def storage_cmd(event):
        word, scope = event.pattern_match.group(1), (event.pattern_match.group(2) or "")
        if word == "ai":
            word = "status"
        if word == "on":
            await threads.set_storage(True)
            return await event.reply(
                f"🧠 حافظهٔ AI روشن شد.\n• تا {LONG_KEEP_ROWS} پاسخ AI (هر پاسخ با شناسهٔ #id) برای همیشه نگه داشته می‌شود؛ `{PREFIX}reply <id>` همیشه کار می‌کند.\n"
                f"• هر `{PREFIX}ask` در یک گپ، {HISTORY_PAIRS} گفتگوی آخر همان گپ را هم می‌داند (ادامهٔ خودکار).\n"
                f"• `{PREFIX}ask -n متن` = بدون حافظه | `{PREFIX}storage clear` = فراموش‌کردن این گپ | `{PREFIX}storage off` = خاموش")
        if word == "off":
            await threads.set_storage(False)
            return await event.reply(f"🧠 حافظهٔ AI خاموش شد. فقط {SHORT_KEEP_ROWS} پیام آخر / {SHORT_KEEP_DAYS} روز نگه داشته می‌شود (برای `{PREFIX}reply <id>` و Reply روی پیام AI)؛ "
                                     "ادامهٔ خودکار گفتگو انجام نمی‌شود.")
        if word == "clear":
            n = await threads.clear(None if scope == "all" else event.chat_id)
            return await event.reply(f"🗑 {n} پیام AI فراموش شد" + (" (همهٔ گپ‌ها)." if scope == "all" else " (همین گپ)."))
        if word == "list":
            await threads.ensure()
            rows = await db.fetchall("SELECT aid,chat_id,kind,question FROM ai_msgs " + ("" if scope == "all" else "WHERE chat_id=? ") + "ORDER BY aid DESC LIMIT 15",
                                     () if scope == "all" else (event.chat_id,))
            if not rows:
                return await event.reply("🧠 هنوز پیامی ذخیره نشده." if scope == "all" else f"🧠 در این گپ پیامی ذخیره نیست (`{PREFIX}storage list all` همهٔ گپ‌ها).")
            lines = [f"{tag(r['aid'])} [{r['kind']}]" + (f" chat={r['chat_id']}" if scope == "all" else "") + " " + r["question"][:60].replace("\n", " ") for r in rows]
            return await event.reply("🧠 آخرین پیام‌های AI:\n" + "\n".join(lines))
        on = await threads.storage_on()
        return await event.reply(
            f"🧠 حافظهٔ AI: {'روشن' if on else 'خاموش'} | ذخیره‌شده: {await threads.count()} پیام\n"
            f"`{PREFIX}storage on|off|status` | `list [all]` | `clear [all]`   (خود `{PREFIX}storage` بدون کلمه = فضای دیسک سرور)\n"
            f"`{PREFIX}reply <id> متن` — جواب دادن به یک پیام AI با شناسه (یا Reply روی آن)")
