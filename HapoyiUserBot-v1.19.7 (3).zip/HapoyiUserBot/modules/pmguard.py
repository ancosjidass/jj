"""PM guard (1.19.6): strangers who write to your private chat are warned, and blocked when they keep going.

    .pm on [N]|off|status          N = how many unanswered messages a stranger may send before he is blocked (default 3)
    .pm msg <text>                 the warning text (default is a polite Persian one)      .pm list   people you approved
    .approve [@user|id] (or in his PM)   he may write freely       .disapprove [@user|id]   back to «stranger»

Never touched: people in your contacts, bots, people you have written to (that approves them), and the ones you `.approve`. Default: OFF.
"""
from __future__ import annotations

import logging
import os
import re
import time

from telethon import events
from telethon.tl.functions.contacts import BlockRequest

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
DEFAULT_TEXT = "سلام 👋 این پیوی فیلتر شده است. لطفاً پیام‌های پشت‌سرهم نفرست؛ منتظر بمان تا خودم جواب بدهم. (پیام خودکار)"
TABLES = """
CREATE TABLE IF NOT EXISTS pm_approved (user_id INTEGER PRIMARY KEY, ts REAL NOT NULL);
CREATE TABLE IF NOT EXISTS pm_strikes (user_id INTEGER PRIMARY KEY, n INTEGER NOT NULL, last_warn REAL NOT NULL DEFAULT 0)
"""
WARN_EVERY = 300.0       # the warning text is repeated at most every 5 minutes (the strikes keep counting)


def decide(strikes: int, limit: int) -> str:
    """What happens to a stranger who just wrote his `strikes`-th message: 'warn' | 'block'."""
    return "block" if strikes > limit else "warn"


async def setup(client, db):
    for stmt in filter(None, (s.strip() for s in TABLES.split(";"))):
        await db.execute(stmt)

    async def enabled() -> tuple[bool, int]:
        return bool(await db.get_kv("pm:on")), int(await db.get_kv("pm:limit") or 3)

    async def approved(uid: int) -> bool:
        return bool(await db.fetchone("SELECT 1 FROM pm_approved WHERE user_id=?", (uid,)))

    async def approve(uid: int) -> None:
        await db.execute("INSERT OR REPLACE INTO pm_approved(user_id,ts) VALUES(?,?)", (uid, time.time()))
        await db.execute("DELETE FROM pm_strikes WHERE user_id=?", (uid,))

    @client.on(events.NewMessage(outgoing=True))
    async def auto_approve(event):
        """Whoever I write to in a private chat is no stranger any more."""
        if event.is_private and event.chat_id and not (event.raw_text or "").startswith(PREFIX + "pm"):
            if not await approved(int(event.chat_id)):
                await approve(int(event.chat_id))

    @client.on(events.NewMessage(incoming=True))
    async def watcher(event):
        if not event.is_private or event.out or not event.sender_id:
            return
        on, limit = await enabled()
        if not on:
            return
        uid = int(event.sender_id)
        if await approved(uid):
            return
        try:
            sender = await event.get_sender()
        except Exception:  # noqa: BLE001
            return
        if getattr(sender, "bot", False) or getattr(sender, "contact", False) or getattr(sender, "mutual_contact", False) or getattr(sender, "is_self", False) or uid == 777000:
            return
        row = await db.fetchone("SELECT n,last_warn FROM pm_strikes WHERE user_id=?", (uid,))
        n = (row["n"] if row else 0) + 1
        last = row["last_warn"] if row else 0.0
        if decide(n, limit) == "block":
            try:
                await client(BlockRequest(id=await event.get_input_sender()))
                await client.send_message("me", f"🚫 PM guard: {getattr(sender, 'first_name', '') or uid} ({uid}) بعد از {n - 1} پیام بلاک شد.")
            except Exception:  # noqa: BLE001
                log.warning("pm guard: block failed", exc_info=True)
            await db.execute("DELETE FROM pm_strikes WHERE user_id=?", (uid,))
            return
        warn_now = time.time() - last > WARN_EVERY
        await db.execute("INSERT INTO pm_strikes(user_id,n,last_warn) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET n=excluded.n, last_warn=excluded.last_warn",
                         (uid, n, time.time() if warn_now else last))
        if warn_now:
            text = await db.get_kv("pm:text") or DEFAULT_TEXT
            await event.reply(f"{text}\n\n⚠️ {n}/{limit}")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}pm(?:\s+(on|off|status|msg|list))?(?:\s+(.*))?$"))
    async def pm(event):
        word, rest = event.pattern_match.group(1) or "status", (event.pattern_match.group(2) or "").strip()
        if word == "on":
            await db.set_kv("pm:on", 1)
            if rest.isdigit() and 1 <= int(rest) <= 20:
                await db.set_kv("pm:limit", int(rest))
        elif word == "off":
            await db.set_kv("pm:on", 0)
        elif word == "msg":
            if not rest:
                return await event.edit(f"فرمت: `{PREFIX}pm msg متن هشدار`")
            await db.set_kv("pm:text", rest[:500])
            return await event.edit("✅ متن هشدار ذخیره شد.")
        elif word == "list":
            rows = await db.fetchall("SELECT user_id FROM pm_approved ORDER BY ts DESC LIMIT 60")
            return await event.edit("✅ تأییدشده‌ها: " + (", ".join(str(r["user_id"]) for r in rows) or "—"))
        on, limit = await enabled()
        await event.edit(f"🛡 PM guard: {'روشن' if on else 'خاموش'} • سقف پیام غریبه: {limit}\n`{PREFIX}pm on [N]|off|msg|list` • `{PREFIX}approve` • `{PREFIX}disapprove`")

    async def target_id(event, arg: str) -> int | None:
        if arg.strip():
            try:
                ent = await client.get_entity(int(arg) if arg.strip().lstrip("-").isdigit() else arg.strip())
                return int(ent.id)
            except Exception:  # noqa: BLE001
                return None
        if event.is_reply:
            rep = await event.get_reply_message()
            return int(rep.sender_id) if rep is not None and rep.sender_id else None
        return int(event.chat_id) if event.is_private else None

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}(approve|disapprove)(?:\s+(\S+))?$"))
    async def approve_cmd(event):
        word = event.pattern_match.group(1)
        uid = await target_id(event, event.pattern_match.group(2) or "")
        if uid is None:
            return await event.edit("❌ در پیوی خودش بزن، یا Reply کن، یا @username/ID بده.")
        if word == "approve":
            await approve(uid)
            return await event.edit(f"✅ {uid} تأیید شد؛ آزادانه می‌تواند پیام بدهد.")
        await db.execute("DELETE FROM pm_approved WHERE user_id=?", (uid,))
        await event.edit(f"🚫 {uid} دوباره «غریبه» حساب می‌شود.")
