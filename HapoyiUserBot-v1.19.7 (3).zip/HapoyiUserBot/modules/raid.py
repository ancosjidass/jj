"""Raid mode (1.19.6): a wave of new members (bots / spammers) locks the group by itself and opens it again when it is calm.

    .raid on [joins] [seconds] [calm-minutes]     in this group (you must be admin with «Ban users»).  Default: 8 joins in 60 s, calm 10 min
    .raid off | status | now (lock right now) | unlock | purge (kick the people who joined during the raid)

When `joins` people join within `seconds`, the group is locked (nobody can write), you get a message in Saved Messages with the number and the names, and the people who
joined during the wave are remembered. After `calm-minutes` without a new join it is unlocked again (only if the lock was made by raid mode).
Nothing is banned automatically: `.raid purge` kicks the remembered joiners only when YOU say so.
"""
from __future__ import annotations

import asyncio
import inspect
import json
import logging
import os
import re
import time
from collections import deque

from telethon import events, types
from telethon.errors import RPCError
from telethon.tl.functions.messages import EditChatDefaultBannedRightsRequest

from core.permissions import explain_error, require_group_right

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
TABLE = ("CREATE TABLE IF NOT EXISTS raid_chats (chat_id INTEGER PRIMARY KEY, joins INTEGER NOT NULL, secs INTEGER NOT NULL, calm INTEGER NOT NULL, "
         "active INTEGER NOT NULL DEFAULT 0, locked_at REAL NOT NULL DEFAULT 0, last_join REAL NOT NULL DEFAULT 0, prev_send INTEGER NOT NULL DEFAULT 0, joiners TEXT NOT NULL DEFAULT '[]')")
MAX_JOINERS = 300
_RIGHT_FIELDS = [n for n in inspect.signature(types.ChatBannedRights.__init__).parameters if n not in {"self", "until_date"}]


def surge(times: deque, now: float, joins: int, secs: int) -> bool:
    """True when `joins` or more joins happened in the last `secs` seconds (the deque is trimmed)."""
    while times and now - times[0] > secs:
        times.popleft()
    return len(times) >= joins


async def setup(client, db):
    await db.execute(TABLE)
    recent: dict[int, deque] = {}

    async def set_send_lock(chat_id: int, lock: bool, prev_send: bool | None = None) -> bool:
        """Change only the «send messages» default right. Returns the value it had before."""
        chat = await client.get_entity(chat_id)
        cur = getattr(chat, "default_banned_rights", None)
        flags = {name: bool(getattr(cur, name, False)) for name in _RIGHT_FIELDS}
        before = bool(flags.get("send_messages", False))
        flags["send_messages"] = True if lock else (bool(prev_send) if prev_send is not None else False)
        await client(EditChatDefaultBannedRightsRequest(peer=await client.get_input_entity(chat_id), banned_rights=types.ChatBannedRights(until_date=None, **flags)))
        return before

    async def lock_now(row, why: str, names: list[str]) -> None:
        chat_id = row["chat_id"]
        perm = await require_group_right(client, chat_id, "ban_users")
        if not perm.allowed:
            await client.send_message("me", f"⚠️ Raid mode در گروه {chat_id}: {why} ولی قفل نشد — {perm.reason}")
            return
        prev = await set_send_lock(chat_id, True)
        await db.execute("UPDATE raid_chats SET active=1, locked_at=?, last_join=?, prev_send=? WHERE chat_id=?", (time.time(), time.time(), 1 if prev else 0, chat_id))
        await client.send_message("me", f"🛡 Raid mode: گروه {chat_id} قفل شد — {why}\n" + ("، ".join(names[:12]) or "—") + f"\n`{PREFIX}raid purge` = اخراج این افراد • `{PREFIX}raid unlock` = بازکردن")

    @client.on(events.ChatAction)
    async def on_join(event):
        if not (event.user_joined or event.user_added) or not event.chat_id:
            return
        row = await db.fetchone("SELECT * FROM raid_chats WHERE chat_id=?", (event.chat_id,))
        if row is None:
            return
        try:
            users = await event.get_users()
        except Exception:  # noqa: BLE001
            users = []
        now = time.time()
        times = recent.setdefault(event.chat_id, deque())
        for _u in users or [None]:
            times.append(now)
        ids = [int(u.id) for u in users or [] if getattr(u, "id", None)]
        names = [getattr(u, "first_name", "") or str(u.id) for u in users or []]
        if row["active"]:
            joiners = (json.loads(row["joiners"]) + ids)[-MAX_JOINERS:]
            await db.execute("UPDATE raid_chats SET last_join=?, joiners=? WHERE chat_id=?", (now, json.dumps(joiners), event.chat_id))
            return
        # joiners of the last wave are kept even before the trigger, so `purge` can reach the first ones too
        wave = json.loads(row["joiners"]) if row["joiners"] else []
        wave = (wave + ids)[-MAX_JOINERS:] if (times and len(times) > 1) else ids
        await db.execute("UPDATE raid_chats SET joiners=? WHERE chat_id=?", (json.dumps(wave), event.chat_id))
        if surge(times, now, row["joins"], row["secs"]):
            try:
                await lock_now(row, f"{len(times)} عضو جدید در {row['secs']} ثانیه", names)
            except RPCError as exc:
                await client.send_message("me", f"⚠️ Raid mode: قفل نشد ({explain_error(exc)})")
            times.clear()

    async def calm_loop():
        while True:
            try:
                if client.is_connected():
                    for row in await db.fetchall("SELECT * FROM raid_chats WHERE active=1"):
                        if time.time() - max(row["last_join"], row["locked_at"]) >= row["calm"] * 60:
                            try:
                                await set_send_lock(row["chat_id"], False, bool(row["prev_send"]))
                            except Exception as exc:  # noqa: BLE001
                                log.warning("raid unlock failed: %s", exc)
                                continue
                            await db.execute("UPDATE raid_chats SET active=0 WHERE chat_id=?", (row["chat_id"],))
                            await client.send_message("me", f"🔓 Raid mode: گروه {row['chat_id']} آرام شد و باز شد. افراد این موج: {len(json.loads(row['joiners']))} (`{PREFIX}raid purge` در همان گروه)")
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                log.warning("raid calm loop: %s: %s", exc.__class__.__name__, exc)
            await asyncio.sleep(30)

    asyncio.get_running_loop().create_task(calm_loop())

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}raid(?:\s+(on|off|status|now|unlock|purge))?(?:\s+(\d+))?(?:\s+(\d+))?(?:\s+(\d+))?$"))
    async def raid(event):
        if not event.is_group:
            return await event.edit("❌ فقط در گروه.")
        word = event.pattern_match.group(1) or "status"
        a, b, c = (event.pattern_match.group(i) for i in (2, 3, 4))
        chat = event.chat_id
        row = await db.fetchone("SELECT * FROM raid_chats WHERE chat_id=?", (chat,))
        if word == "on":
            perm = await require_group_right(client, chat, "ban_users")
            if not perm.allowed:
                return await event.edit("❌ " + perm.reason)
            joins, secs, calm = int(a or 8), int(b or 60), int(c or 10)
            if not (2 <= joins <= 200 and 5 <= secs <= 3600 and 1 <= calm <= 1440):
                return await event.edit(f"❌ مقدارها: joins 2–200، seconds 5–3600، calm 1–1440. مثال: `{PREFIX}raid on 8 60 10`")
            await db.execute("INSERT INTO raid_chats(chat_id,joins,secs,calm) VALUES(?,?,?,?) ON CONFLICT(chat_id) DO UPDATE SET joins=excluded.joins, secs=excluded.secs, calm=excluded.calm",
                             (chat, joins, secs, calm))
            return await event.edit(f"🛡 Raid mode روشن: {joins} ورود در {secs} ثانیه ⟶ قفل؛ بعد از {calm} دقیقه آرامش باز می‌شود.")
        if row is None:
            return await event.edit(f"🛡 Raid mode در این گروه خاموش است. `{PREFIX}raid on [joins] [seconds] [calm]`")
        if word == "off":
            if row["active"]:
                await set_send_lock(chat, False, bool(row["prev_send"]))
            await db.execute("DELETE FROM raid_chats WHERE chat_id=?", (chat,))
            return await event.edit("🛡 Raid mode خاموش شد.")
        if word in {"now", "unlock"}:
            try:
                if word == "now":
                    await lock_now(row, "دستی", [])
                    return await event.edit("🔒 قفل شد (تا آرامش).")
                await set_send_lock(chat, False, bool(row["prev_send"]))
                await db.execute("UPDATE raid_chats SET active=0 WHERE chat_id=?", (chat,))
                return await event.edit("🔓 باز شد.")
            except RPCError as exc:
                return await event.edit(f"❌ انجام نشد: {explain_error(exc)}")
        if word == "purge":
            ids = json.loads(row["joiners"])
            if not ids:
                return await event.edit("— کسی در لیست نیست.")
            done = 0
            for uid in ids:
                try:
                    await client.kick_participant(chat, uid)
                    done += 1
                    await asyncio.sleep(0.6)
                except Exception:  # noqa: BLE001
                    continue
            await db.execute("UPDATE raid_chats SET joiners='[]' WHERE chat_id=?", (chat,))
            return await event.edit(f"👢 {done} از {len(ids)} نفر اخراج شدند.")
        await event.edit(f"🛡 Raid mode: روشن • {row['joins']} ورود/{row['secs']}s • آرامش {row['calm']}min • {'🔒 قفل است' if row['active'] else 'آماده'} • موج: {len(json.loads(row['joiners']))} نفر")
