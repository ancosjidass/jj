"""`.models` - choose the AI model from a glass (inline-button) panel, or from text.

    .models                     glass panel (posted by the Assistant Bot): 🧠 smart mode or one pinned model, fail-over on/off,
                                balanced/ordered key rotation, live model lists of every provider, a one-tap test, details
    .models list                numbered list as text            .models refresh   ask every provider for its live model list
    .models status              every key of every provider (ready / parked until ...)
    .model                      what is active now
    .model auto                 🧠 smart mode: all models and keys, best first, automatic fail-over (default)
    .model <number|name>        pin a model (number from `.models list`; `groq:openai/gpt-oss-120b`, `gemini`, `gpt-oss-120b`, a unique piece)
    .model fallback on|off      when the pinned model is out of quota: use the others (on, default) or stop and say so
    .model strategy balanced|ordered   keys of one model: least-used first (default) or key 1 until it is gone

The choice belongs to the account that made it (stored in that account's own database). The pinned model may also be a model
that is not in .env but that the provider offers (pick it from the live list): it is used with that provider's keys.
"""
from __future__ import annotations

import html
import logging
import math
import os
import re
import time
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from telethon import Button, events
from telethon.errors import MessageNotModifiedError

from services import ai

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
TZ_NAME = os.getenv("TIMEZONE", "Asia/Tehran") or "Asia/Tehran"
PAGE = 6
AUTO_LABEL = "🧠 هوشمند (خودکار)"


def _e(text) -> str:
    return html.escape(str(text))


def _offset() -> float:
    try:
        return datetime.now(ZoneInfo(TZ_NAME)).utcoffset().total_seconds() / 3600
    except Exception:  # noqa: BLE001
        return 0.0


def _hhmm(epoch: float) -> str:
    dt = datetime.fromtimestamp(epoch, timezone(timedelta(hours=_offset())))
    return dt.strftime("%H:%M")


def _short(model: str, limit: int = 30) -> str:
    s = model.rsplit("/", 1)[-1]
    return s if len(s) <= limit else s[: limit - 1] + "…"


def _row_state(r: dict) -> str:
    if r["until"]:
        return f"⏸ تا {_hhmm(r['until'])}"
    return f"✅ {r['used']}"


def resolve(text: str, rows: list[dict]) -> tuple[str | None, str]:
    """(entry name, error) for what the owner typed: number, `provider:model`, provider, model id or a unique piece of the name."""
    q = (text or "").strip()
    if not q:
        return None, "empty"
    if q.isdigit():
        i = int(q)
        return (rows[i - 1]["name"], "") if 1 <= i <= len(rows) else (None, f"شمارهٔ {i} در لیست نیست (۱ تا {len(rows)})")
    low = q.lower()
    exact = [r for r in rows if r["name"].lower() == low]
    if exact:
        return exact[0]["name"], ""
    if low in {p for p in ai.PROVIDERS} | {ai.CUSTOM} and any(r["provider"] == low for r in rows):
        return low, ""  # a whole provider: every model of it
    by_model = [r for r in rows if r["model"].lower() == low]
    if by_model:  # the same id at several providers: the first (chain order) wins; fail-over still covers the rest
        return by_model[0]["name"], ""
    part = [r for r in rows if low in r["name"].lower()]
    if len(part) == 1:
        return part[0]["name"], ""
    if not part:
        return None, "چنین مدلی پیدا نشد؛ `.models list` را ببین یا `.models refresh` بزن."
    return None, "چند مدل با این اسم هست: " + "، ".join(r["name"] for r in part[:5]) + (" …" if len(part) > 5 else "")


async def build(db, page: int = 0, view: str = "main", note: str = "") -> tuple[str, list]:
    """(html text, buttons) of the panel for one account."""
    prefs = await ai.load_prefs(db)
    rows = ai.catalog()
    strategy = (prefs.strategy or os.getenv("AI_STRATEGY") or "balanced").lower()
    if strategy not in {"balanced", "ordered"}:
        strategy = "balanced"
    back = [Button.inline("⬅️ هوش مصنوعی", b"ui:sec:ai"), Button.inline("🏠 خانه", b"ui:home")]
    if not rows:
        text = ("<b>🤖 مدل‌های هوش مصنوعی</b>\n\n❌ هنوز هیچ کلیدی در <code>.env</code> نیست.\n"
                "یکی از این‌ها را (رایگان) بگیر و بگذار: GROQ_API_KEY ، GEMINI_API_KEY ، CEREBRAS_API_KEY ، NVIDIA_API_KEY ، "
                "MISTRAL_API_KEY ، SAMBANOVA_API_KEY ، OPENROUTER_API_KEY — و سلف را ری‌استارت کن.")
        return text, [back]
    if view == "info":
        lines = ["<b>📊 وضعیت دقیق کلیدها</b>", ""] + [_e(x) for x in ai.detail_lines(tz_offset_hours=_offset())]
        return "\n".join(lines)[:3900], [[Button.inline("🔄 تازه‌سازی", f"ui:p:mdl:info:{page}".encode()), Button.inline("⬅️ پنل مدل‌ها", f"ui:p:mdl:pg:{page}".encode())], back]
    pages = max(1, math.ceil(len(rows) / PAGE))
    page = max(0, min(page, pages - 1))
    chunk = rows[page * PAGE:(page + 1) * PAGE]
    pinned = prefs.model
    provs = {}
    for r in rows:
        if r["configured"]:
            provs[r["provider"]] = r["keys"]
    keys_line = " · ".join(f"{ai.PROVIDERS[p].label if p in ai.PROVIDERS else 'Custom'}×{n}" for p, n in provs.items())
    lines = ["<b>🤖 مدل‌های هوش مصنوعی</b>"]
    if note:
        lines += ["", note]
    lines += ["", f"حالت: <b>{_e(pinned) if pinned else AUTO_LABEL}</b>"]
    if pinned:
        lines.append(f"جایگزینی خودکار وقتی سهمیهٔ این مدل تموم شد: <b>{'روشن' if prefs.fallback else 'خاموش'}</b>")
    lines += [f"چرخش کلیدها: <b>{'کم‌مصرف‌ترین اول' if strategy == 'balanced' else 'ترتیبی'}</b>", f"کلیدها: {_e(keys_line)}", "",
              f"<b>مدل‌ها</b> ({page + 1}/{pages}) — ✅ آمادهٔ امروز • ⏸ تا ساعت • 🆕 از لیست زنده"]
    btn: list = [[Button.inline(("📌 " if not pinned else "") + AUTO_LABEL, f"ui:p:mdl:auto:{page}".encode())]]
    for r in chunk:
        sel = bool(pinned) and (pinned.lower() == r["name"].lower() or pinned.lower() == r["provider"])
        keys = f" 🔑{r['keys']}" if r["keys"] > 1 else ""
        mark = "📌" if sel else ("🆕" if not r["configured"] else "")
        label = f"{mark} {r['provider']} · {_short(r['model'])}{keys} {_row_state(r)}".strip()
        btn.append([Button.inline(label[:62], f"ui:p:mdl:set:{r['id']}:{page}".encode())])
    nav = []
    if page > 0:
        nav.append(Button.inline("◀️", f"ui:p:mdl:pg:{page - 1}".encode()))
    nav.append(Button.inline(f"{page + 1}/{pages}", f"ui:p:mdl:pg:{page}".encode()))
    if page < pages - 1:
        nav.append(Button.inline("▶️", f"ui:p:mdl:pg:{page + 1}".encode()))
    btn.append(nav)
    btn.append([Button.inline("🔄 مدل‌های زنده", f"ui:p:mdl:live:{page}".encode()), Button.inline("🧪 تست", f"ui:p:mdl:test:{page}".encode())])
    btn.append([Button.inline(f"🔁 جایگزینی: {'روشن' if prefs.fallback else 'خاموش'}", f"ui:p:mdl:fb:{page}".encode()),
                Button.inline(f"⚖️ {'balanced' if strategy == 'balanced' else 'ordered'}", f"ui:p:mdl:st:{page}".encode())])
    btn.append([Button.inline("📊 وضعیت کلیدها", f"ui:p:mdl:info:{page}".encode())])
    btn.append(back)
    return "\n".join(lines)[:3900], btn


async def _show(event, text: str, buttons: list) -> None:
    try:
        await event.edit(text, parse_mode="html", buttons=buttons)
    except MessageNotModifiedError:
        pass


async def _test(prefs) -> str:
    t0 = time.monotonic()
    try:
        text, unit = await ai.chat([{"role": "user", "content": "Reply with exactly one word: OK"}], max_tokens=200, temperature=0,
                                   prefer=prefs.model or None, fallback=prefs.fallback, strategy=prefs.strategy or None)
        return f"🧪 تست موفق: <b>{_e(unit)}</b> جواب داد «{_e(text[:40])}» ({time.monotonic() - t0:.1f}s)"
    except ai.AINotConfigured:
        return "🧪 هیچ کلیدی تنظیم نشده."
    except ai.AIUnavailable as exc:
        return f"🧪 الان هیچ مدلی (با این تنظیمات) سهمیه ندارد؛ حدود {_hhmm(exc.reset_at)} برمی‌گردد."
    except Exception as exc:  # noqa: BLE001
        return f"🧪 تست ناموفق: {_e(exc.__class__.__name__)}"


async def panel(event, rt, data: str) -> None:
    """Callback buttons: ui:p:mdl[:action[:arg[:page]]]"""
    db = rt.db
    parts = data.split(":")  # ui p mdl action arg page
    action = parts[3] if len(parts) > 3 else "pg"
    note = ""

    def num(i: int) -> int:
        try:
            return int(parts[i])
        except (IndexError, ValueError):
            return 0

    page = num(4) if action in {"pg", "info"} else num(5 if action == "set" else 4)
    if action == "auto":
        await db.set_kv("ai_model_pref", "")
        note = "✅ حالت هوشمند فعال شد."
    elif action == "set":
        wanted = parts[4] if len(parts) > 4 else ""
        row = next((r for r in ai.catalog() if r["id"] == wanted), None)
        if row is None:
            return await event.answer("لیست عوض شده؛ دوباره باز کن.", alert=True)
        await db.set_kv("ai_model_pref", row["name"])
        note = f"📌 مدل انتخاب شد: <b>{_e(row['name'])}</b>"
    elif action == "fb":
        prefs = await ai.load_prefs(db)
        await db.set_kv("ai_model_fallback", not prefs.fallback)
        note = "🔁 جایگزینی خودکار " + ("خاموش شد: اگه مدل انتخابی سهمیه نداشته باشه، AI می‌گه." if prefs.fallback else "روشن شد.")
    elif action == "st":
        prefs = await ai.load_prefs(db)
        cur = (prefs.strategy or os.getenv("AI_STRATEGY") or "balanced").lower()
        nxt = "ordered" if cur == "balanced" else "balanced"
        await db.set_kv("ai_strategy", nxt)
        note = "⚖️ چرخش کلیدها: " + ("ترتیبی (کلید ۱ تا آخر، بعد کلید ۲ ...)" if nxt == "ordered" else "کم‌مصرف‌ترین اول (سهمیه‌ها یکنواخت خرج می‌شن)")
    elif action == "live":
        await event.answer("در حال گرفتن لیست مدل‌ها…")
        result = await ai.discover()
        ok = {p: v for p, v in result.items() if isinstance(v, list)}
        bad = {p: v for p, v in result.items() if not isinstance(v, list)}
        note = "🔄 لیست زنده: " + (" · ".join(f"{p} {len(v)} مدل" for p, v in ok.items()) or "چیزی نیامد")
        if bad:
            note += "\n⚠️ " + " · ".join(f"{p}: {_e(v)}" for p, v in bad.items())
    elif action == "test":
        await event.answer("در حال تست…")
        note = await _test(await ai.load_prefs(db))
    elif action == "info":
        text, buttons = await build(db, page, "info")
        return await _show(event, text, buttons)
    text, buttons = await build(db, page, "main", note)
    await _show(event, text, buttons)


async def text_list(db, limit: int = 60) -> str:
    prefs = await ai.load_prefs(db)
    rows = ai.catalog()
    if not rows:
        return "❌ هیچ کلیدی در .env نیست (GROQ_API_KEY / GEMINI_API_KEY / CEREBRAS_API_KEY / NVIDIA_API_KEY ...)."
    out = [f"🤖 مدل‌ها — فعال: {prefs.model or AUTO_LABEL}", ""]
    for i, r in enumerate(rows[:limit], 1):
        keys = f" 🔑{r['keys']}" if r["keys"] > 1 else ""
        mark = "📌" if prefs.model and prefs.model.lower() in {r["name"].lower(), r["provider"]} else ("🆕" if not r["configured"] else "  ")
        state = f"⏸ تا {_hhmm(r['until'])}" if r["until"] else f"✅ {r['used']} امروز"
        out.append(f"{i}. {mark} {r['name']}{keys} — {state}")
    if len(rows) > limit:
        out.append(f"… و {len(rows) - limit} مدل دیگر")
    out += ["", f"`{PREFIX}model <شماره|اسم>` انتخاب | `{PREFIX}model auto` هوشمند | `{PREFIX}models refresh` لیست زندهٔ سرویس‌ها"]
    return "\n".join(out)


async def setup(client, db):
    async def post_panel(event) -> bool:
        from modules import ui  # the Assistant Bot lives there

        bot = getattr(ui, "_bot", None)
        if bot is None:
            return False
        posted = False
        try:
            from utils.inline_launch import post_inline

            await post_inline(client, bot, "models", event.chat_id, getattr(event, "reply_to_msg_id", None))
            posted = True
        except Exception as exc:  # noqa: BLE001
            log.info("inline models panel failed (%s: %s); falling back to bot.send_message", exc.__class__.__name__, exc)
        if not posted:
            try:
                text, buttons = await build(db)
                await bot.send_message(event.chat_id, text, parse_mode="html", buttons=buttons)
                posted = True
            except Exception as exc:  # noqa: BLE001
                log.info("bot models panel failed (%s: %s)", exc.__class__.__name__, exc)
        if posted:
            try:
                await event.delete()
            except Exception:  # noqa: BLE001
                pass
        return posted

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?is)^{P}models(?:\s+(.*))?$"))
    async def models_cmd(event):
        arg = (event.pattern_match.group(1) or "").strip().lower()
        if arg in {"list", "ls", "لیست"}:
            return await event.reply(await text_list(db))
        if arg in {"refresh", "live", "update"}:
            await event.edit("🔄 در حال گرفتن لیست زندهٔ مدل‌ها…")
            result = await ai.discover()
            head = " · ".join(f"{p}: {len(v)}" if isinstance(v, list) else f"{p}: ⚠️ {v}" for p, v in result.items()) or "کلیدی نیست"
            return await event.edit(f"🔄 {head}\n\n" + await text_list(db))
        if arg in {"status", "info", "وضعیت"}:
            return await event.reply("📊 وضعیت کلیدها\n" + "\n".join(ai.detail_lines(tz_offset_hours=_offset())) if ai.load_chain()
                                     else "❌ هیچ کلیدی در .env نیست.")
        if arg:
            return await event.reply(f"فرمت: `{PREFIX}models` (پنل) | `{PREFIX}models list` | `{PREFIX}models refresh` | `{PREFIX}models status`")
        if not await post_panel(event):
            await event.reply(await text_list(db) + "\n\n(پنل دکمه‌ای وقتی کار می‌کنه که BOT_TOKEN و inline در @BotFather فعال باشه.)")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?is)^{P}model(?:\s+(.*))?$"))
    async def model_cmd(event):
        arg = (event.pattern_match.group(1) or "").strip()
        low = arg.lower()
        prefs = await ai.load_prefs(db)
        if not arg:
            return await event.reply(f"🤖 مدل فعال: {prefs.model or AUTO_LABEL}\nجایگزینی خودکار: {'روشن' if prefs.fallback else 'خاموش'}\n"
                                     f"`{PREFIX}models` پنل | `{PREFIX}models list` | `{PREFIX}model auto` | `{PREFIX}model <شماره|اسم>`")
        if low in {"auto", "smart", "هوشمند", "خودکار"}:
            await db.set_kv("ai_model_pref", "")
            return await event.reply("🧠 حالت هوشمند فعال شد: همهٔ مدل‌ها و کلیدها، به‌ترتیب بهترین، و وقتی سهمیهٔ یکی تموم شد خودکار بعدی.")
        m = re.fullmatch(r"fallback\s+(on|off)", low)
        if m:
            await db.set_kv("ai_model_fallback", m.group(1) == "on")
            return await event.reply("🔁 جایگزینی خودکار " + ("روشن شد." if m.group(1) == "on" else "خاموش شد؛ وقتی مدل انتخابی سهمیه نداشته باشه می‌گم."))
        m = re.fullmatch(r"strategy\s+(balanced|ordered)", low)
        if m:
            await db.set_kv("ai_strategy", m.group(1))
            return await event.reply(f"⚖️ چرخش کلیدها: {m.group(1)}")
        name, err = resolve(arg, ai.catalog())
        if name is None:
            return await event.reply("❌ " + err)
        await db.set_kv("ai_model_pref", name)
        extra = "" if prefs.fallback else "\n(جایگزینی خودکار خاموشه.)"
        await event.reply(f"📌 مدل انتخاب شد: {name}{extra}")
