"""Shortcuts: first-run guide, macros, Persian aliases and per-chat command switches.

    .start                                   short guide for a new user
    .macro add <name> <cmd1> ;; <cmd2> ...   save a chain of commands        .macro run <name>  (or  .m <name>)
    .macro list | show <name> | del <name>   (a step can be `sleep 3` = wait 3 seconds; max 10 steps)
    .alias add <word> <command>              your own word for a command, used as  .word args  (e.g. .alias add حذف delmes)
    .alias del <word> | list                 built-in Persian words: .بن .میوت .پاکسازی .خلاصه .ترجمه ... (see `.alias list`)
    .disable <command> [all]                 switch a command OFF in this chat (all = everywhere)
    .enable <command> [all] | .disabled      switch it back / list switched-off commands
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
from datetime import datetime, timezone

from telethon import events

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
MAX_STEPS = 10
PROTECTED = {"enable", "disable", "disabled", "help", "menu", "start", "health"}
DEFAULT_ALIASES = {
    "بن": "ban", "آنبن": "unban", "کیک": "kick", "میوت": "mute", "آنمیوت": "unmute", "اخطار": "warn", "پین": "pin", "آنپین": "unpin",
    "حذف": "del", "پاکسازی": "delmes", "پاک": "delmes", "ادمین‌ها": "admins", "غیبت": "afk", "برگشتم": "back", "تایمر": "timer", "فیک": "fake",
    "بپرس": "ask", "آموزش": "guide", "دانلودر": "dl", "خلاصه": "sum", "ترجمه": "tr", "صدا": "tts", "متن": "stt", "ریپیت": "repeat", "گزارش": "report", "توقف": "stop",
    "راهنما": "help", "منو": "menu", "سلامت": "health", "بکاپ": "backup", "تگ": "tag", "فعالیت": "activity", "کپچا": "captcha",
    "بلک‌لیست": "blacklist", "قیمت": "price", "ماشین‌حساب": "calc",
}
START_TEXT = (
    "👋 به Hāpoyi خوش اومدی!\n\n"
    "۱) `.menu` — منوی دکمه‌ای همهٔ قابلیت‌ها   `.help` — راهنمای کامل\n"
    "۲) گروه: `.ban` `.mute 10m` `.delmes 50` `.captcha on` `.blacklist add` (روی پیام Reply کن)\n"
    "۳) هوش مصنوعی: `.ask سؤال` `.sum 100` (خلاصهٔ گپ) `.tr en` `.stt` `.tts fa سلام` — `.ai status`\n"
    "   سؤال دربارهٔ خود سلف؟ `.guide چجوری پیام رو زمان‌بندی کنم؟` — `.aiguide on` دستیار هوشمند موقعیت‌سنج\n"
    "   دانلود: `.dl لینک` (یوتیوب/اینستا/تیک‌تاک) — `.dl audio لینک` فقط صدا\n"
    "۴) ابزار: `.timer 5m 10s` `.fake typing` (`.stop fake all`) `.repeat on` `.ss` (اسکرین‌شات)\n"
    "۵) امنیت: `.report on` (ONLINE/OFFLINE در پروفایل) `.autobackup on` `.protect on` `.health`\n"
    "۶) میانبر: `.macro add ...` `.alias list` (دستور فارسی مثل `.بن`) `.disable <دستور>`\n\n"
    "هر دستور بدون ورودی، راهنمای خودش را نشان می‌دهد."
)
TABLES = (
    "CREATE TABLE IF NOT EXISTS macros (name TEXT PRIMARY KEY, steps TEXT NOT NULL, created_at TEXT NOT NULL)",
    "CREATE TABLE IF NOT EXISTS user_aliases (word TEXT PRIMARY KEY, command TEXT NOT NULL)",
    "CREATE TABLE IF NOT EXISTS cmd_disabled (chat_id INTEGER NOT NULL, command TEXT NOT NULL, PRIMARY KEY(chat_id, command))",
)


def parse_steps(raw: str) -> list[str]:
    steps = [s.strip() for s in re.split(r"\s*;;\s*|\n", raw) if s.strip()]
    out = []
    for s in steps:
        if re.fullmatch(r"(?i)sleep\s+\d+(?:\.\d+)?", s):
            out.append(s.lower())
        else:
            out.append(s if s.startswith(PREFIX) else PREFIX + s)
    return out


def command_name(text: str) -> str:
    t = (text or "").strip()
    if t.startswith(PREFIX):
        t = t[len(PREFIX):]
    return (t.split(None, 1)[0] if t.split() else "").lower()


async def setup(client, db):
    for stmt in TABLES:
        await db.execute(stmt)
    blocked: set[tuple[int, str]] = {(r["chat_id"], r["command"]) for r in await db.fetchall("SELECT chat_id,command FROM cmd_disabled")}

    def is_blocked(event) -> bool:
        name = command_name(getattr(event, "raw_text", "") or "")
        if not name or name in PROTECTED:
            return False
        chat = int(getattr(event, "chat_id", 0) or 0)
        return (chat, name) in blocked or (0, name) in blocked

    client._hapoyi_cmd_blocked = is_blocked

    def conflicts(word: str) -> bool:
        """Is `.word` already a real command of some module?"""
        try:
            handlers = client.list_event_handlers()
        except Exception:  # noqa: BLE001
            return False
        for _cb, ev in handlers:
            pat = getattr(ev, "pattern", None)  # Telethon keeps `re.compile(p).match` here
            if callable(pat):
                try:
                    if pat(f"{PREFIX}{word}") or pat(f"{PREFIX}{word} x"):
                        return True
                except Exception:  # noqa: BLE001
                    continue
        return False

    user_words: set[str] = {r["word"] for r in await db.fetchall("SELECT word FROM user_aliases")}

    async def alias_map() -> dict[str, str]:
        m = dict(DEFAULT_ALIASES)
        for r in await db.fetchall("SELECT word,command FROM user_aliases"):
            m[r["word"]] = r["command"]
        return m

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}start$"))
    async def start(event):
        await event.reply(START_TEXT)

    # ------------------------------------------------------------------ macros
    async def run_macro(event, name: str) -> None:
        row = await db.fetchone("SELECT steps FROM macros WHERE name=?", (name,))
        if not row:
            return await event.reply(f"❌ ماکروی «{name}» نیست (`{PREFIX}macro list`).")
        steps = json.loads(row["steps"])
        reply_to = event.reply_to_msg_id if event.is_reply else None
        chat = event.chat_id
        try:
            await event.delete()
        except Exception:  # noqa: BLE001
            pass
        for step in steps:
            if step.startswith("sleep"):
                await asyncio.sleep(min(float(step.split()[1]), 30))
                continue
            await client.send_message(chat, step, reply_to=reply_to)
            await asyncio.sleep(1.0)

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}(?:macro|m)(?:\s+(.*))?$"))
    async def macro(event):
        raw = (event.pattern_match.group(1) or "").strip()
        parts = raw.split(None, 2)
        word = parts[0].lower() if parts else "list"
        if word == "list" or not raw:
            rows = await db.fetchall("SELECT name,steps FROM macros ORDER BY name")
            return await event.reply("🧩 ماکروها:\n" + ("\n".join(f"• {r['name']} ({len(json.loads(r['steps']))} مرحله)" for r in rows) if rows else "— خالی —")
                                     + f"\n\n`{PREFIX}macro add نام دستور1 ;; دستور2` | `{PREFIX}macro run نام` | `{PREFIX}m نام`")
        if word == "add":
            if len(parts) < 3:
                return await event.reply(f"فرمت: `{PREFIX}macro add نام mute 10m ;; sleep 5 ;; unmute`")
            name, steps = parts[1].lower(), parse_steps(parts[2])
            if not steps or len(steps) > MAX_STEPS:
                return await event.reply(f"❌ بین ۱ تا {MAX_STEPS} مرحله بده.")
            if any(re.match(rf"^{P}(?:macro|m)\b", s, re.I) for s in steps):
                return await event.reply("❌ ماکرو نمی‌تواند ماکروی دیگری را صدا بزند.")
            await db.execute("INSERT INTO macros(name,steps,created_at) VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET steps=excluded.steps",
                             (name, json.dumps(steps, ensure_ascii=False), datetime.now(timezone.utc).isoformat()))
            return await event.reply(f"✅ ماکروی «{name}» ذخیره شد ({len(steps)} مرحله). اجرا: `{PREFIX}m {name}`")
        if word in {"del", "rm", "remove"} and len(parts) > 1:
            n = await db.execute("DELETE FROM macros WHERE name=?", (parts[1].lower(),))
            return await event.reply("🗑 حذف شد." if n else "ℹ️ چنین ماکرویی نبود.")
        if word == "show" and len(parts) > 1:
            row = await db.fetchone("SELECT steps FROM macros WHERE name=?", (parts[1].lower(),))
            return await event.reply("\n".join(f"{i}. {s}" for i, s in enumerate(json.loads(row["steps"]), 1)) if row else "ℹ️ چنین ماکرویی نبود.")
        await run_macro(event, (parts[1] if word == "run" and len(parts) > 1 else raw).lower())

    # ------------------------------------------------------------------ aliases
    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}alias(?:\s+(.*))?$"))
    async def alias_cmd(event):
        parts = (event.pattern_match.group(1) or "").split()
        word = parts[0].lower() if parts else "list"
        if word == "add" and len(parts) >= 3:
            w, cmd = parts[1].lower().lstrip(PREFIX), parts[2].lower().lstrip(PREFIX)
            if conflicts(w):
                return await event.reply(f"❌ `{PREFIX}{w}` خودش یک دستور واقعی است؛ اسم دیگری بگذار.")
            await db.execute("INSERT INTO user_aliases(word,command) VALUES(?,?) ON CONFLICT(word) DO UPDATE SET command=excluded.command", (w, cmd))
            user_words.add(w)
            return await event.reply(f"✅ `{PREFIX}{w} ...` ← `{PREFIX}{cmd} ...`")
        if word in {"del", "rm"} and len(parts) >= 2:
            n = await db.execute("DELETE FROM user_aliases WHERE word=?", (parts[1].lower(),))
            user_words.discard(parts[1].lower())
            return await event.reply("🗑 حذف شد." if n else "ℹ️ این میانبر شخصی نبود (میانبرهای پیش‌فرض ثابت‌اند).")
        m = await alias_map()
        mine = {r["word"] for r in await db.fetchall("SELECT word FROM user_aliases")}
        await event.reply("🔤 میانبرها (به‌صورت `.کلمه`):\n" + "  ".join(f"{w}→{c}{'*' if w in mine else ''}" for w, c in m.items())
                          + f"\n(* = شخصی)\n`{PREFIX}alias add کلمه دستور` | `{PREFIX}alias del کلمه`")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"(?s)^{P}([^\s\d{P}][^\s]*)(?:\s+(.*))?$"))
    async def alias_runner(event):
        word = event.pattern_match.group(1).lower()
        if word.isascii() and word not in user_words:
            return  # ASCII words are normal commands handled by their own modules
        cmd = (await alias_map()).get(word)
        if not cmd:
            return
        args = (event.pattern_match.group(2) or "").strip()
        reply_to = event.reply_to_msg_id if event.is_reply else None
        chat = event.chat_id
        try:
            await event.delete()
        except Exception:  # noqa: BLE001
            pass
        await client.send_message(chat, f"{PREFIX}{cmd} {args}".strip(), reply_to=reply_to)

    # ------------------------------------------------------------------ per-chat switches
    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}(disable|enable)(?:\s+(\S+))?(?:\s+(all))?$"))
    async def disable_cmd(event):
        action, raw, scope = event.pattern_match.group(1), event.pattern_match.group(2), event.pattern_match.group(3)
        if not raw:
            return await event.reply(f"فرمت: `{PREFIX}disable mute` (فقط همین گپ) | `{PREFIX}disable mute all` | `{PREFIX}enable mute` | `{PREFIX}disabled`")
        name = raw.lower().lstrip(PREFIX)
        if name in PROTECTED:
            return await event.reply("❌ این دستور قابل غیرفعال‌کردن نیست.")
        chat = 0 if scope else int(event.chat_id)
        if action == "disable":
            await db.execute("INSERT OR IGNORE INTO cmd_disabled(chat_id,command) VALUES(?,?)", (chat, name))
            blocked.add((chat, name))
            return await event.reply(f"⛔ `{PREFIX}{name}` {'همه‌جا' if scope else 'در این گپ'} غیرفعال شد.")
        await db.execute("DELETE FROM cmd_disabled WHERE chat_id=? AND command=?", (chat, name))
        blocked.discard((chat, name))
        await event.reply(f"✅ `{PREFIX}{name}` {'همه‌جا' if scope else 'در این گپ'} فعال شد.")

    @client.on(events.NewMessage(outgoing=True, pattern=rf"^{P}disabled$"))
    async def disabled_list(event):
        here = sorted(c for ch, c in blocked if ch == event.chat_id)
        everywhere = sorted(c for ch, c in blocked if ch == 0)
        await event.reply(f"⛔ غیرفعال در این گپ: {', '.join(here) or '—'}\n⛔ غیرفعال همه‌جا: {', '.join(everywhere) or '—'}")
