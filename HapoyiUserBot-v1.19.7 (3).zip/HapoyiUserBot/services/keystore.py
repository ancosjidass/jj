"""AI API keys added from Telegram (1.17.1): `.apikey add ...` instead of editing .env.

Keys live ONLY in data/ai_keys.enc, encrypted with the same Fernet key as the stored sessions (core/crypto_store.py), file mode 0600.
They are never written to the database (so `.backup` cannot leak them), never printed in full, and only the OWNER account may manage them.
`apply()` puts them into the process environment under names that services/ai.py already reads (<PROVIDER>_API_KEY_9001 ...), so every
AI feature uses them at once, with no restart and no changes to the rest of the code. Keys from .env keep working and are never touched.
"""
from __future__ import annotations

import json
import os
import re
import stat
import tempfile
from pathlib import Path
from typing import Any

from services import ai

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
BASE_N = 9000
MAX_KEYS_PER_PROVIDER = 30
INJECTED: set[str] = set()

# the key formats that identify the provider by themselves
PREFIXES: tuple[tuple[str, str], ...] = (("gsk_", "groq"), ("csk-", "cerebras"), ("AIza", "gemini"), ("nvapi-", "nvidia"), ("sk-or-", "openrouter"))


def path() -> Path:
    return Path(os.getenv("AI_KEYS_FILE") or DATA_DIR / "ai_keys.enc")


def providers() -> list[str]:
    return [*ai.PROVIDERS, ai.CUSTOM]


def detect(key: str) -> str | None:
    for pre, prov in PREFIXES:
        if key.startswith(pre):
            return prov
    return None


def looks_like_key(text: str) -> bool:
    return bool(re.fullmatch(r"[A-Za-z0-9_\-\.]{16,300}", text or ""))


def load() -> dict[str, Any]:
    from core import crypto_store

    try:
        raw = path().read_text(encoding="ascii").strip()
        data = json.loads(crypto_store.decrypt(raw)) if raw else {}
    except (OSError, ValueError, crypto_store.DecryptionError):
        data = {}
    keys = data.get("keys") if isinstance(data, dict) else None
    return {"keys": {p: list(v) for p, v in (keys or {}).items() if isinstance(v, list)}, "custom": dict((data or {}).get("custom") or {})}


def save(data: dict[str, Any]) -> None:
    from core import crypto_store

    from utils.atomic import write_text_atomic

    write_text_atomic(path(), crypto_store.encrypt(json.dumps(data, ensure_ascii=False)), encoding="ascii", private=True)


def apply(data: dict[str, Any] | None = None) -> None:
    """(Re)inject the stored keys into the environment that services/ai.py reads."""
    data = data if data is not None else load()
    for name in list(INJECTED):
        os.environ.pop(name, None)
        INJECTED.discard(name)
    for prov, keys in data["keys"].items():
        prefix = "AI_CUSTOM" if prov == ai.CUSTOM else (ai.PROVIDERS[prov].env if prov in ai.PROVIDERS else None)
        if not prefix:
            continue
        for i, key in enumerate(keys):
            name = f"{prefix}_KEY_{BASE_N + i + 1}" if prov == ai.CUSTOM else f"{prefix}_API_KEY_{BASE_N + i + 1}"
            os.environ[name] = key
            INJECTED.add(name)
    custom = data.get("custom") or {}
    for var, val in (("AI_CUSTOM_BASE", custom.get("base")), ("AI_CUSTOM_MODELS", custom.get("models"))):
        if val and not os.environ.get(var):
            os.environ[var] = val
            INJECTED.add(var)


def env_only_keys(provider: str) -> list[str]:
    """Keys that come from .env (the injected ones are left out)."""
    env = {k: v for k, v in os.environ.items() if k not in INJECTED}
    return ai.provider_keys(provider, env)


def add(provider: str, keys: list[str]) -> tuple[int, int]:
    """(added, already_known). Raises ValueError for an unknown provider / too many keys."""
    if provider not in providers():
        raise ValueError("provider")
    data = load()
    have = data["keys"].setdefault(provider, [])
    known = set(have) | set(env_only_keys(provider))
    added = dup = 0
    for k in keys:
        if k in known:
            dup += 1
            continue
        if len(have) >= MAX_KEYS_PER_PROVIDER:
            raise ValueError("limit")
        have.append(k)
        known.add(k)
        added += 1
    save(data)
    apply(data)
    return added, dup


def remove(provider: str, which: str) -> int:
    """`which` = "all", an index (1-based, as shown by list) or the last characters of a key."""
    data = load()
    have = data["keys"].get(provider, [])
    if which.lower() == "all":
        gone = list(have)
    elif which.isdigit() and 1 <= int(which) <= len(have):
        gone = [have[int(which) - 1]]
    else:
        gone = [k for k in have if len(which) >= 4 and k.endswith(which)]
    data["keys"][provider] = [k for k in have if k not in gone]
    if not data["keys"][provider]:
        data["keys"].pop(provider, None)
    save(data)
    apply(data)
    return len(gone)


def set_custom(base: str, key: str, models: str = "") -> None:
    data = load()
    data["custom"] = {"base": base.rstrip("/"), "models": models}
    have = data["keys"].setdefault(ai.CUSTOM, [])
    if key not in have:
        have.append(key)
    save(data)
    for var in ("AI_CUSTOM_BASE", "AI_CUSTOM_MODELS"):
        if var in INJECTED:
            os.environ.pop(var, None)
            INJECTED.discard(var)
    apply(data)


def listing() -> list[tuple[str, str, int, list[str]]]:
    """[(provider, label, env_count, [masked stored keys])] - nothing secret in it."""
    stored = load()["keys"]
    rows = []
    for prov in providers():
        env_n = len(env_only_keys(prov))
        mine = [ai.mask(k) for k in stored.get(prov, [])]
        if env_n or mine:
            label = ai.PROVIDERS[prov].label if prov in ai.PROVIDERS else "Custom"
            rows.append((prov, label, env_n, mine))
    return rows


async def check(provider: str, key: str, session: Any = None) -> tuple[str, str]:
    """("ok"|"invalid"|"unknown", detail): GET <base>/models with the key (nothing is generated, no quota is used)."""
    import aiohttp

    base = ai.provider_base(provider)
    if not base:
        return "unknown", "no base url"
    own = session is None
    sess = session or aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15))
    try:
        async with sess.get(f"{base}/models", headers={"Authorization": f"Bearer {key}"}) as r:
            if r.status == 200:
                return "ok", ""
            if r.status in (401, 403):
                return "invalid", str(r.status)
            return "unknown", str(r.status)
    except Exception as exc:  # noqa: BLE001
        return "unknown", exc.__class__.__name__
    finally:
        if own:
            await sess.close()
