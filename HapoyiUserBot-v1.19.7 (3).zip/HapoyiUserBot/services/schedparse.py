"""`.sched` - the pure part: when-expressions and option flags. No Telegram here.

    10m | 2h | 1d            after that long
    17:30 | ۱۷:۳۰ | ساعت 17   the next time the clock shows that
    tomorrow 09:00 | فردا 9:30 | 2026-11-02 18:00     a date
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

MIN_SECONDS = 15                 # Telegram needs the time to be in the future
MAX_DAYS = 365
_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
_DUR = re.compile(r"^(\d+(?:\.\d+)?)(s|m|h|d|w)$", re.I)
_CLOCK = re.compile(r"^(\d{1,2})[:٫.](\d{2})$")
_DATE = re.compile(r"^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$")
_UNIT = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}
TOMORROW = {"tomorrow", "فردا"}
TODAY = {"today", "امروز", "امشب"}
CLOCK_WORDS = {"ساعت", "at", "در", "تو"}


class WhenError(ValueError):
    pass


def _clock(tok: str) -> tuple[int, int] | None:
    t = tok.translate(_DIGITS)
    m = _CLOCK.match(t)
    if m:
        h, mi = int(m.group(1)), int(m.group(2))
        if h <= 23 and mi <= 59:
            return h, mi
        raise WhenError("ساعت نامعتبر است")
    return None


def parse_when(words: list[str], tz: str = "Asia/Tehran", now: datetime | None = None) -> tuple[datetime, list[str]]:
    """-> (aware UTC datetime, remaining words). Raises WhenError when the start of `words` is no time."""
    zone = ZoneInfo(tz)
    n = (now or datetime.now(timezone.utc)).astimezone(zone)
    w = list(words)
    if not w:
        raise WhenError("زمان را بنویس (مثل 10m یا 17:30)")
    first = w[0].translate(_DIGITS).lower()
    m = _DUR.match(first)
    if m:
        secs = int(float(m.group(1)) * _UNIT[m.group(2).lower()])
        if secs < MIN_SECONDS:
            raise WhenError(f"حداقل {MIN_SECONDS} ثانیه")
        if secs > MAX_DAYS * 86400:
            raise WhenError("حداکثر یک سال")
        return (n + timedelta(seconds=secs)).astimezone(timezone.utc), w[1:]
    day_shift: int | None = None
    date = None
    if first in TOMORROW:
        day_shift, w = 1, w[1:]
    elif first in TODAY:
        day_shift, w = 0, w[1:]
    else:
        dm = _DATE.match(first)
        if dm:
            try:
                date = datetime(int(dm.group(1)), int(dm.group(2)), int(dm.group(3)), tzinfo=zone)
            except ValueError as exc:
                raise WhenError("تاریخ نامعتبر است") from exc
            w = w[1:]
    if w and w[0].lower() in CLOCK_WORDS:
        w = w[1:]
    hm = None
    if w:
        hm = _clock(w[0])
        if hm is None and re.fullmatch(r"\d{1,2}", w[0].translate(_DIGITS)) and (day_shift is not None or date is not None or first in CLOCK_WORDS):
            h = int(w[0].translate(_DIGITS))
            hm = (h, 0) if h <= 23 else None
        if hm is not None:
            w = w[1:]
    if hm is None:
        if date is not None or day_shift is not None:
            hm = (9, 0)
        else:
            raise WhenError("زمان را بنویس (مثل 10m یا 17:30 یا فردا 09:00)")
    if date is not None:
        target = date.replace(hour=hm[0], minute=hm[1])
    else:
        target = n.replace(hour=hm[0], minute=hm[1], second=0, microsecond=0)
        if day_shift:
            target += timedelta(days=day_shift)
        elif day_shift is None and target <= n + timedelta(seconds=MIN_SECONDS):
            target += timedelta(days=1)   # "17:30" when it is already past 17:30 -> tomorrow
    delta = (target - n).total_seconds()
    if delta < MIN_SECONDS:
        raise WhenError("این زمان گذشته است")
    if delta > MAX_DAYS * 86400:
        raise WhenError("حداکثر یک سال")
    return target.astimezone(timezone.utc), w


def parse_options(words: list[str]) -> tuple[dict, str]:
    """After the time: flags `pin` `silent`, then either plain text or `poll [multi] [public] Q | a | b`. -> (opts, rest-as-text)."""
    opts = {"pin": False, "silent": False, "poll": False, "multi": False, "public": False}
    w = list(words)
    while w and w[0].lower() in {"pin", "silent", "پین", "بی‌صدا", "بیصدا"}:
        k = w.pop(0).lower()
        opts["pin" if k in {"pin", "پین"} else "silent"] = True
    if w and w[0].lower() in {"poll", "نظرسنجی"}:
        opts["poll"] = True
        w.pop(0)
        while w and w[0].lower() in {"multi", "public", "pin", "silent"}:
            opts[w.pop(0).lower()] = True
    return opts, " ".join(w)
