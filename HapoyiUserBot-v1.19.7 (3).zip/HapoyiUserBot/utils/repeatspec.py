"""Parsing of repeat specs:  `5m میو`, `میو 5m`, `30s hello x10`, `10m 5 hello`, `10m - hello`.

Count (how many times to send) can be given as
  * `x10` / `×10` at either end,
  * a bare number or an "unlimited" marker (`-`, `∞`, `inf`, `نامحدود`) right AFTER the interval.
A text that really starts with a number can be protected with `-`:  `.every 5m - 3 نفر آنلاینن`.
"""
from __future__ import annotations

import re

from utils.formatting import parse_duration

MIN_SECONDS = 1
MAX_SECONDS = 72 * 3600
MAX_TIMES = 1_000_000

_FA = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
_DUR = re.compile(r"^\d+(?:\.\d+)?[smhdwSMHDW]$")
_TIMES = re.compile(r"^[xX×](\d{1,7})$")
_COUNT = re.compile(r"^\d{1,7}$")
_UNLIMITED = {"-", "—", "–", "∞", "inf", "infinite", "unlimited", "نامحدود", "بی‌نهایت", "بینهایت"}


class RepeatSpecError(ValueError):
    """The interval was understood but is outside the allowed range."""


def _norm(token: str) -> str:
    return token.translate(_FA)


def fmt_seconds(seconds: float) -> str:
    seconds = max(0, int(seconds))
    d, r = divmod(seconds, 86400)
    h, r = divmod(r, 3600)
    m, s = divmod(r, 60)
    return " ".join(x for x in (f"{d}d" if d else "", f"{h}h" if h else "", f"{m}m" if m else "", f"{s}s" if (s or not (d or h or m)) else "") if x)


def parse_repeat(args: str | None) -> tuple[int, str, int | None] | None:
    """Return (interval_seconds, text, times|None) or None when `args` is not a repeat spec.

    Raises RepeatSpecError when the interval is valid but < 1s or > 72h.
    `times=None` means "unlimited".
    """
    s = (args or "").strip()
    if not s:
        return None
    interval = times = None
    count_seen = False
    for _ in range(3):
        parts_first = s.split(None, 1)
        parts_last = s.rsplit(None, 1)
        if len(parts_first) < 2:  # a single word can never be "spec + text"
            break
        first, last = _norm(parts_first[0]), _norm(parts_last[-1])
        if interval is None and _DUR.match(first):
            interval, s = first, parts_first[1].strip()
            # positional count right after the interval:  `10m 5 text`  /  `10m - text`
            rest = s.split(None, 1)
            if len(rest) == 2 and not count_seen:
                tok = _norm(rest[0]).lower()
                if tok in _UNLIMITED:
                    count_seen, times, s = True, None, rest[1].strip()
                elif _COUNT.match(tok):
                    count_seen, times, s = True, int(tok), rest[1].strip()
        elif interval is None and _DUR.match(last):
            interval, s = last, parts_last[0].strip()
        elif not count_seen and _TIMES.match(first):
            count_seen, times, s = True, int(_TIMES.match(first).group(1)), parts_first[1].strip()
        elif not count_seen and _TIMES.match(last):
            count_seen, times, s = True, int(_TIMES.match(last).group(1)), parts_last[0].strip()
        else:
            break
    if interval is None or not s:
        return None
    try:
        seconds = parse_duration(interval)
    except ValueError:
        m = re.fullmatch(r"(?i)(\d+(?:\.\d+)?)([smhdw])", interval)
        if m and float(m.group(1)) > 0:  # e.g. 0.5s: understood, but below the 1s floor
            raise RepeatSpecError("فاصله باید بین 1s و 72h باشد (حداقل ۱ ثانیه).")
        return None
    if seconds < MIN_SECONDS or seconds > MAX_SECONDS:
        raise RepeatSpecError(f"فاصله باید بین 1s و 72h باشد (الان: {fmt_seconds(seconds)}).")
    if times is not None:
        if times <= 0:
            times = None
        else:
            times = min(times, MAX_TIMES)
    return seconds, s, times
