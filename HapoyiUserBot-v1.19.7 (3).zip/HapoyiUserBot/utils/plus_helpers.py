"""Pure helpers for modules/plus.py (no Telegram imports, easy to unit-test)."""
from __future__ import annotations

import base64
import binascii
import hashlib
import re
from datetime import date, timedelta

_FA = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩٫٬،", "01234567890123456789" ".,,")


def norm_digits(text: str) -> str:
    return (text or "").translate(_FA)


def parse_amount(raw: str) -> float | None:
    s = norm_digits(raw).replace(",", "").replace("_", "").strip().lower()
    mult = 1.0
    for suffix, m in (("k", 1e3), ("هزار", 1e3), ("m", 1e6), ("میلیون", 1e6), ("b", 1e9), ("میلیارد", 1e9)):
        if s.endswith(suffix) and len(s) > len(suffix):
            s, mult = s[: -len(suffix)], m
            break
    try:
        v = float(s) * mult
    except ValueError:
        return None
    return v if v == v and abs(v) < 1e15 else None


def money(v: float) -> str:
    return f"{v:,.0f}" if abs(v - round(v)) < 1e-9 else f"{v:,.2f}"


# ---------------------------------------------------------------- fancy text
def _block(upper: int | None, lower: int | None, digit: int | None):
    def conv(ch: str) -> str:
        if "A" <= ch <= "Z" and upper is not None:
            return chr(upper + ord(ch) - 65)
        if "a" <= ch <= "z" and lower is not None:
            return chr(lower + ord(ch) - 97)
        if "0" <= ch <= "9" and digit is not None:
            return chr(digit + ord(ch) - 48)
        return ch
    return conv


_SMALLCAPS = dict(zip("abcdefghijklmnopqrstuvwxyz", "ᴀʙᴄᴅᴇғɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ"))
_FLIP = dict(zip("abcdefghijklmnopqrstuvwxyz0123456789?!.,'_&", "ɐqɔpǝɟƃɥᴉɾʞlɯuodbɹsʇnʌʍxʎz0ƖᄅƐㄣϛ9ㄥ86¿¡˙'˙,‾⅋"))


def _circled(ch: str) -> str:
    if "A" <= ch <= "Z":
        return chr(0x24B6 + ord(ch) - 65)
    if "a" <= ch <= "z":
        return chr(0x24D0 + ord(ch) - 97)
    if "1" <= ch <= "9":
        return chr(0x2460 + ord(ch) - 49)
    if ch == "0":
        return "\u24EA"
    return ch


STYLES: dict[str, object] = {
    "bold": _block(0x1D5D4, 0x1D5EE, 0x1D7EC),
    "serif": _block(0x1D400, 0x1D41A, 0x1D7CE),
    "italic": _block(0x1D608, 0x1D622, None),
    "script": _block(0x1D4D0, 0x1D4EA, None),
    "fraktur": _block(0x1D56C, 0x1D586, None),
    "mono": _block(0x1D670, 0x1D68A, 0x1D7F6),
    "circle": _circled,
    "wide": lambda ch: chr(ord(ch) + 0xFEE0) if "!" <= ch <= "~" else ("\u3000" if ch == " " else ch),
    "small": lambda ch: _SMALLCAPS.get(ch.lower(), ch),
    "strike": lambda ch: ch if ch.isspace() else ch + "\u0336",
    "under": lambda ch: ch if ch.isspace() else ch + "\u0332",
}


def fancy(style: str, text: str) -> str | None:
    style = style.lower()
    if style == "flip":
        return "".join(_FLIP.get(c.lower(), c) for c in reversed(text))
    if style == "reverse":
        return text[::-1]
    fn = STYLES.get(style)
    if fn is None:
        return None
    return "".join(fn(c) for c in text)  # type: ignore[operator]


# ---------------------------------------------------------------- hash / base64
ALGOS = ("md5", "sha1", "sha256", "sha512")


def hash_text(algo: str, text: str) -> str:
    return hashlib.new(algo, text.encode("utf-8")).hexdigest()


def b64(mode: str, text: str) -> str:
    if mode == "enc":
        return base64.b64encode(text.encode("utf-8")).decode()
    try:
        return base64.b64decode(text.strip().encode(), validate=True).decode("utf-8")
    except (binascii.Error, UnicodeDecodeError, ValueError) as exc:
        raise ValueError("ورودی Base64 معتبر نیست.") from exc


# ---------------------------------------------------------------- word count
def text_stats(text: str) -> dict[str, int | float]:
    words = len(re.findall(r"\w+", text, re.UNICODE))
    return {"chars": len(text), "chars_nospace": len(re.sub(r"\s", "", text)), "words": words,
            "lines": text.count("\n") + 1 if text else 0, "read_s": round(words / 200 * 60)}


# ---------------------------------------------------------------- units
_LEN = {"mm": 0.001, "cm": 0.01, "m": 1.0, "km": 1000.0, "in": 0.0254, "ft": 0.3048, "yd": 0.9144, "mi": 1609.344}
_MASS = {"mg": 1e-6, "g": 0.001, "kg": 1.0, "t": 1000.0, "oz": 0.028349523125, "lb": 0.45359237}
_VOL = {"ml": 0.001, "l": 1.0, "gal": 3.785411784, "cup": 0.2365882365, "floz": 0.0295735296}
_SPD = {"kmh": 1 / 3.6, "ms": 1.0, "mph": 0.44704, "kn": 0.514444}
_DATA = {"b": 1.0, "kb": 1024.0, "mb": 1024.0**2, "gb": 1024.0**3, "tb": 1024.0**4}
_TABLES = (_LEN, _MASS, _VOL, _SPD, _DATA)
_ALIAS = {"inch": "in", "inches": "in", "foot": "ft", "feet": "ft", "mile": "mi", "miles": "mi", "pound": "lb", "pounds": "lb",
          "lbs": "lb", "kph": "kmh", "km/h": "kmh", "m/s": "ms", "liter": "l", "litre": "l", "کیلومتر": "km", "متر": "m",
          "سانتی": "cm", "مایل": "mi", "کیلو": "kg", "گرم": "g", "لیتر": "l", "فوت": "ft", "اینچ": "in", "پوند": "lb"}


def convert_units(value: float, src: str, dst: str) -> float | None:
    src, dst = _ALIAS.get(src.lower(), src.lower()), _ALIAS.get(dst.lower(), dst.lower())
    if src in ("c", "f", "k") or dst in ("c", "f", "k"):
        def to_c(v: float, u: str) -> float:
            return v if u == "c" else (v - 32) * 5 / 9 if u == "f" else v - 273.15
        if src not in ("c", "f", "k") or dst not in ("c", "f", "k"):
            return None
        c = to_c(value, src)
        return c if dst == "c" else c * 9 / 5 + 32 if dst == "f" else c + 273.15
    for t in _TABLES:
        if src in t and dst in t:
            return value * t[src] / t[dst]
    return None


# ---------------------------------------------------------------- habits
def streak(days: set[str], today: date) -> int:
    """Consecutive days ending today (or yesterday when today is not done yet)."""
    cur = today if today.isoformat() in days else today - timedelta(days=1)
    n = 0
    while cur.isoformat() in days:
        n += 1
        cur -= timedelta(days=1)
    return n


# ---------------------------------------------------------------- misc time parsing
def parse_hhmm(raw: str) -> int | None:
    m = re.fullmatch(r"(\d{1,2}):(\d{2})", norm_digits(raw).strip())
    if not m:
        return None
    h, mi = int(m.group(1)), int(m.group(2))
    return h * 60 + mi if h < 24 and mi < 60 else None


def in_window(now_min: int, start: int, end: int) -> bool:
    return start <= now_min < end if start <= end else (now_min >= start or now_min < end)


def parse_birthday(raw: str) -> tuple[int, int, int | None] | None:
    s = norm_digits(raw).strip().replace("/", "-")
    m = re.fullmatch(r"(?:(\d{4})-)?(\d{1,2})-(\d{1,2})", s)
    if not m:
        return None
    y = int(m.group(1)) if m.group(1) else None
    mo, d = int(m.group(2)), int(m.group(3))
    return (mo, d, y) if 1 <= mo <= 12 and 1 <= d <= 31 else None
