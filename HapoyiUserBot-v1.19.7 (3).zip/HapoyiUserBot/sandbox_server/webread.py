"""Safe page reader of the sandbox: it reads a site for the AI WITHOUT trusting it.

Layers (a page must pass all of them, otherwise nothing of it is returned):
 1. URL gate        scheme / port / credentials / IP literal / local names / downloads / blocklist, then a reputation SCORE of the address (0-100, formula below)
 2. network gate    the name is resolved by OUR resolver and only PUBLIC addresses may be connected (no 127.x, 10.x, 192.168.x, 169.254.x metadata, ::1 ...) - checked at connect time,
                    every redirect hop goes through the gates again (max 5), no cookies, no proxies, 2 MB max, only text-like content types, 15 s
 3. content gate    spam / ad / gambling / adult / pop-up / obfuscated-script signals of the PAGE itself give a second score; a page below the limit is refused
 4. JS pages        (optional, needs playwright + chromium in the image) a throw-away browser context: no downloads, no pop-ups, no dialogs, no service workers, no permissions,
                    images / media / fonts / websockets are not loaded, EVERY sub-request goes through the network gate
 5. output          plain text + a few links; the page is DATA for the AI, never instructions (the AI client wraps it that way)

Reputation formula of an address (start 70):  https +10 / http -15 · risky TLD (.tk .xyz .top ...) -40 · punycode -30 · many digits / hyphens / sub-domains / very long name -10..-15 ·
URL shortener -40 · every spam word in the address -40 (max -80) · trusted suffix (.gov .edu .ac.xx) +10 · a known trusted site (SANDBOX_WEB_ALLOW + the built-in list) = 100.
Needed: SANDBOX_WEB_MIN_URL_SCORE (default 45).  Content: start 80, spam phrases -8 each (max -50), link density -15/-30, keyword stuffing -15, iframes -15, pop-ups -20,
refresh to another site -20, obfuscated script -20; needed: SANDBOX_WEB_MIN_CONTENT_SCORE (default 50).
"""
from __future__ import annotations

import asyncio
import ipaddress
import os
import re
import socket
from collections import Counter
from dataclasses import dataclass, field
from html import unescape
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

import aiohttp
from aiohttp.abc import AbstractResolver

UA = "Mozilla/5.0 (compatible; HapoyiReader/1.0; +read-only)"
MAX_BYTES = 2 * 1024 * 1024
MAX_REDIRECTS = 5
TIMEOUT = 15
OK_PORTS = {None, 80, 443, 8080, 8443}
TEXT_TYPES = ("text/html", "application/xhtml", "text/plain", "application/json", "application/xml", "text/xml", "application/rss", "application/atom", "text/markdown")

TRUSTED = {
    "wikipedia.org", "wikimedia.org", "bbc.com", "bbc.co.uk", "reuters.com", "apnews.com", "aljazeera.com", "dw.com", "euronews.com", "theguardian.com", "nytimes.com",
    "washingtonpost.com", "bloomberg.com", "cnn.com", "france24.com", "npr.org", "timesofisrael.com", "isna.ir", "irna.ir", "farsnews.ir", "tasnimnews.com", "mehrnews.com",
    "khabaronline.ir", "hamshahrionline.ir", "tabnak.ir", "eghtesadnews.com", "donya-e-eqtesad.com", "radiofarda.com", "iranintl.com", "bbc.com", "github.com",
    "docs.python.org", "developer.mozilla.org", "stackoverflow.com", "pypi.org", "npmjs.com", "wikipedia.com", "who.int", "un.org", "nasa.gov", "arxiv.org", "python.org",
}
RISKY_TLDS = {"tk", "ml", "ga", "cf", "gq", "xyz", "top", "click", "loan", "work", "men", "icu", "zip", "mov", "rest", "fit", "buzz", "monster", "cam", "cyou", "sbs", "bond",
              "party", "review", "country", "stream", "download", "racing", "win", "bid", "trade", "webcam", "date", "faith", "gdn", "kim"}
SHORTENERS = {"bit.ly", "t.co", "tinyurl.com", "goo.gl", "cutt.ly", "is.gd", "rebrand.ly", "shorturl.at", "ow.ly", "buff.ly", "rb.gy", "t.ly", "lnkd.in", "tiny.cc", "s.id"}
BAD_WORDS_URL = ("casino", "betting", "porn", "xxx", "sex", "viagra", "escort", "hentai", "warez", "keygen", "crack", "torrent", "freemoney", "giveaway", "payday", "onlyfans", "jackpot", "slot")
DOWNLOAD_EXT = re.compile(r"\.(?:exe|apk|msi|bat|scr|dmg|iso|jar|zip|rar|7z|tar|gz|deb|rpm|bin|dll|ps1|vbs|sh|pkg)(?:$|[?#])", re.I)
LOCAL_SUFFIX = (".local", ".localhost", ".internal", ".lan", ".localdomain", ".home", ".corp", ".intranet", ".private")
SPAM_PHRASES = (
    "click here to win", "you have won", "congratulations you", "free money", "100% free", "buy now", "limited time offer", "act now", "make money fast", "work from home and earn",
    "casino", "jackpot", "online betting", "sports betting", "bet365", "1xbet", "porn", "xxx", "viagra", "cialis", "adult dating", "hot singles", "crypto giveaway", "double your bitcoin",
    "کازینو", "شرط بندی", "شرط‌بندی", "سایت شرط", "بازی انفجار", "پیش بینی", "بدون فیلتر", "سکس", "فیلم سوپر", "برنده شدید", "جایزه می‌گیرید", "کسب درآمد سریع", "ثروتمند شو", "خرید فالوور",
)


# ------------------------------------------------------------------ settings (read on every call: tests / admins may change the env)
def _env_set(name: str) -> set[str]:
    return {x.strip().lower().lstrip(".") for x in os.getenv(name, "").split(",") if x.strip()}


def allow_private() -> bool:
    return os.getenv("SANDBOX_WEB_ALLOW_PRIVATE", "0") == "1"


def min_url_score() -> int:
    return int(os.getenv("SANDBOX_WEB_MIN_URL_SCORE", "45") or 45)


def min_content_score() -> int:
    return int(os.getenv("SANDBOX_WEB_MIN_CONTENT_SCORE", "50") or 50)


def web_enabled() -> bool:
    return os.getenv("SANDBOX_WEB", "1") != "0"


# ------------------------------------------------------------------ addresses
def is_public_ip(value: str) -> bool:
    try:
        ip = ipaddress.ip_address(value)
    except ValueError:
        return False
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    return bool(ip.is_global and not ip.is_multicast and not ip.is_reserved and not ip.is_loopback and not ip.is_link_local and not ip.is_private)


class SafeResolver(AbstractResolver):
    """Resolves with the system resolver but hands over PUBLIC addresses only (re-checked at every connect: DNS rebinding cannot help an attacker)."""

    async def resolve(self, host, port=0, family=socket.AF_INET):
        infos = await asyncio.get_running_loop().getaddrinfo(host, port, type=socket.SOCK_STREAM)
        out, seen = [], set()
        for fam, _t, proto, _c, addr in infos:
            ip = addr[0]
            if ip in seen or not (allow_private() or is_public_ip(ip)):
                continue
            seen.add(ip)
            out.append({"hostname": host, "host": ip, "port": port, "family": fam, "proto": proto, "flags": socket.AI_NUMERICHOST})
        if not out:
            raise OSError(f"{host} does not resolve to a public address")
        return out

    async def close(self):
        return None


async def resolves_public(host: str) -> bool:
    try:
        await SafeResolver().resolve(host, 443)
        return True
    except Exception:  # noqa: BLE001
        return False


@dataclass
class Verdict:
    ok: bool
    score: int = 0
    reasons: list[str] = field(default_factory=list)


def _host_parts(host: str) -> tuple[str, str]:
    parts = host.split(".")
    return (parts[-1] if parts else ""), ".".join(parts[-2:]) if len(parts) >= 2 else host


def trusted_host(host: str) -> bool:
    allow = TRUSTED | _env_set("SANDBOX_WEB_ALLOW")
    return any(host == d or host.endswith("." + d) for d in allow)


def url_gate(url: str, *, subresource: bool = False) -> Verdict:
    """Scheme / port / credentials / names / downloads / blocklist, then the reputation score. `subresource` = a script / frame of a page being rendered: the safety rules apply,
    but the reputation threshold does not (a CDN is not a news site)."""
    try:
        u = urlparse(url.strip())
        port = u.port
    except ValueError:
        return Verdict(False, 0, ["bad address"])
    if u.scheme not in {"http", "https"}:
        return Verdict(False, 0, ["only http / https"])
    if u.username or u.password:
        return Verdict(False, 0, ["credentials in the address"])
    host = (u.hostname or "").lower().rstrip(".")
    if not host:
        return Verdict(False, 0, ["no host"])
    if port not in OK_PORTS and not allow_private():
        return Verdict(False, 0, [f"port {port} is not allowed"])
    if not allow_private():
        try:
            ipaddress.ip_address(host)
            return Verdict(False, 0, ["an IP address instead of a name"])
        except ValueError:
            pass
        if "." not in host or host.endswith(LOCAL_SUFFIX) or host in {"localhost", "metadata.google.internal"}:
            return Verdict(False, 0, ["local / internal name"])
    if host in _env_set("SANDBOX_WEB_BLOCK") or any(host.endswith("." + b) for b in _env_set("SANDBOX_WEB_BLOCK")):
        return Verdict(False, 0, ["blocked by the owner (SANDBOX_WEB_BLOCK)"])
    if DOWNLOAD_EXT.search(u.path + ("?" + u.query if u.query else "")):
        return Verdict(False, 0, ["a file download, not a page"])
    if trusted_host(host):
        return Verdict(True, 100, ["trusted site"])
    tld, last2 = _host_parts(host)
    score, why = 70, []
    if u.scheme == "https":
        score += 10
    else:
        score -= 15
        why.append("plain http")
    if tld in RISKY_TLDS:
        score -= 40
        why.append(f"risky .{tld}")
    if "xn--" in host:
        score -= 30
        why.append("punycode (look-alike name)")
    label = host.rsplit(".", 1)[0]
    if sum(c.isdigit() for c in label) / max(1, len(label)) > 0.3:
        score -= 10
        why.append("many digits in the name")
    if host.count("-") >= 3:
        score -= 10
        why.append("many hyphens")
    if host.count(".") >= 4:
        score -= 15
        why.append("deep sub-domains")
    if len(host) > 40:
        score -= 10
        why.append("very long name")
    if host in SHORTENERS or last2 in SHORTENERS:
        score -= 40
        why.append("URL shortener (the target is unknown)")
    hits = [w for w in BAD_WORDS_URL if w in host or w in u.path.lower()]
    if hits:
        score -= min(80, 40 * len(hits))
        why.append("spam words in the address: " + ", ".join(hits[:3]))
    if len(u.query) > 400:
        score -= 10
        why.append("very long query")
    if tld in {"gov", "edu", "mil"} or re.search(r"\.(?:gov|edu|ac)\.[a-z]{2}$", host):
        score += 10
    score = max(0, min(100, score))
    if subresource:
        return Verdict(True, score, why)
    ok = score >= min_url_score()
    return Verdict(ok, score, why if ok else why + [f"reputation {score} < {min_url_score()}"])


# ------------------------------------------------------------------ content
class _Extract(HTMLParser):
    SKIP = {"script", "style", "noscript", "svg", "template", "iframe", "nav", "footer", "aside", "form", "button", "select", "canvas", "head"}
    BLOCK = {"p", "div", "section", "article", "li", "ul", "ol", "br", "tr", "h1", "h2", "h3", "h4", "h5", "h6", "blockquote", "pre", "table", "main", "dd", "dt", "figcaption"}

    def __init__(self, base: str):
        super().__init__(convert_charrefs=True)
        self.base, self.skip, self.parts, self.links, self.title, self._in_title, self._a = base, 0, [], [], "", False, None
        self.iframes = self.popups = 0

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "title":
            self._in_title = True
        if tag == "iframe":
            self.iframes += 1
        if tag in {"a", "div", "span", "body"} and re.search(r"window\.open\(|popunder|pop-under", a.get("onclick", "") or "", re.I):
            self.popups += 1
        if tag == "body":
            self.skip = 0                                   # a never-closed <head> / <form> must not hide the whole page
        if tag in self.SKIP:
            self.skip += 1
        if self.skip:
            return
        if tag in self.BLOCK:
            self.parts.append("\n")
        if tag == "a" and a.get("href"):
            self._a = [urljoin(self.base, a["href"]), []]

    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
        if tag in self.BLOCK and not self.skip:
            self.parts.append("\n")
        if tag == "a" and self._a:
            text = " ".join("".join(self._a[1]).split())[:90]
            if text and urlparse(self._a[0]).scheme in {"http", "https"}:
                self.links.append({"text": text, "href": self._a[0][:300]})
            self._a = None

    def handle_data(self, data):
        if self._in_title:
            self.title += data
        if self.skip:
            return
        self.parts.append(data)
        if self._a:
            self._a[1].append(data)


def extract(html: str, base: str) -> dict:
    p = _Extract(base)
    try:
        p.feed(html)
    except Exception:  # noqa: BLE001
        pass
    lines, seen = [], set()
    for raw in "".join(p.parts).splitlines():
        line = " ".join(raw.split())
        if len(line) < 3 or line in seen:
            continue
        seen.add(line)
        lines.append(line)
    return {"title": " ".join(p.title.split())[:200], "text": "\n".join(lines), "links": p.links[:40], "iframes": p.iframes, "popups": p.popups}


def content_gate(ex: dict, html: str = "", base_host: str = "") -> Verdict:
    text = ex["text"]
    words = re.findall(r"\w+", text.lower())
    score, why = 80, []
    low = text.lower()
    hits = [ph for ph in SPAM_PHRASES if ph in low]
    if hits:
        score -= min(50, 8 * len(hits))
        why.append("spam / gambling / adult phrases: " + ", ".join(hits[:4]))
    if words:
        density = len(ex["links"]) / len(words)
        if density > 0.7:
            score -= 30
            why.append("almost only links")
        elif density > 0.4:
            score -= 15
            why.append("link farm")
        if len(words) > 100:
            top = Counter(w for w in words if len(w) > 3).most_common(1)
            if top and top[0][1] / len(words) > 0.2:
                score -= 15
                why.append("keyword stuffing")
    if ex.get("iframes", 0) > 3:
        score -= 15
        why.append("many iframes")
    if ex.get("popups", 0) or re.search(r"window\.open\s*\(|popunder", html, re.I):
        score -= 20
        why.append("pop-up code")
    m = re.search(r'<meta[^>]+http-equiv=["\']?refresh["\']?[^>]+url=([^"\'>\s]+)', html, re.I)
    if m:
        target = (urlparse(m.group(1)).hostname or "").lower()
        if target and target != base_host:
            score -= 20
            why.append("auto-redirect to another site")
    if len(re.findall(r"\beval\s*\(|\batob\s*\(|\bunescape\s*\(|String\.fromCharCode", html)) >= 3:
        score -= 20
        why.append("obfuscated script")
    score = max(0, min(100, score))
    ok = score >= min_content_score()
    return Verdict(ok, score, why if ok else why + [f"page quality {score} < {min_content_score()}"])


# ------------------------------------------------------------------ fetching
def _decode(raw: bytes, ctype: str) -> str:
    m = re.search(r"charset=([\w-]+)", ctype or "", re.I)
    enc = m.group(1) if m else None
    if enc is None:
        mb = re.search(rb"<meta[^>]+charset=[\"']?([\w-]+)", raw[:4096], re.I)
        enc = mb.group(1).decode("ascii", "ignore") if mb else "utf-8"
    try:
        return raw.decode(enc, errors="replace")
    except LookupError:
        return raw.decode("utf-8", errors="replace")


async def fetch_static(url: str) -> dict:
    """{'ok': True, url, status, title, text, links, html_len, thin, score_url, score_content} or {'ok': False, 'refused': True, 'why': [...]}"""
    first = url_gate(url)
    if not first.ok:
        return {"ok": False, "refused": True, "why": first.reasons, "score_url": first.score}
    cur, hops = url, 0
    timeout = aiohttp.ClientTimeout(total=TIMEOUT, connect=8)
    conn = aiohttp.TCPConnector(resolver=SafeResolver(), use_dns_cache=False, ttl_dns_cache=0, limit=4)
    headers = {"User-Agent": UA, "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,text/plain;q=0.8,*/*;q=0.5", "Accept-Language": "fa,en;q=0.8", "Accept-Encoding": "gzip, deflate"}
    async with aiohttp.ClientSession(connector=conn, timeout=timeout, cookie_jar=aiohttp.DummyCookieJar(), trust_env=False, headers=headers) as s:
        while True:
            gate = url_gate(cur)
            if not gate.ok:
                return {"ok": False, "refused": True, "why": ["redirect hop refused: " + "; ".join(gate.reasons)], "score_url": gate.score}
            try:
                async with s.get(cur, allow_redirects=False) as r:
                    if r.status in {301, 302, 303, 307, 308} and r.headers.get("Location"):
                        hops += 1
                        if hops > MAX_REDIRECTS:
                            return {"ok": False, "refused": True, "why": ["too many redirects"]}
                        cur = urljoin(cur, r.headers["Location"])
                        continue
                    ctype = (r.headers.get("Content-Type") or "").lower()
                    if r.status >= 400:
                        return {"ok": False, "refused": False, "why": [f"HTTP {r.status}"], "status": r.status}
                    if ctype and not ctype.startswith(TEXT_TYPES):
                        return {"ok": False, "refused": True, "why": [f"content type {ctype.split(';')[0]} is not a page"]}
                    if int(r.headers.get("Content-Length") or 0) > MAX_BYTES:
                        return {"ok": False, "refused": True, "why": ["page is bigger than 2 MB"]}
                    raw = b""
                    async for chunk in r.content.iter_chunked(65536):
                        raw += chunk
                        if len(raw) > MAX_BYTES:
                            break
                    status = r.status
                    break
            except (aiohttp.ClientError, asyncio.TimeoutError, OSError) as exc:
                return {"ok": False, "refused": False, "why": [f"{exc.__class__.__name__}: {str(exc)[:120]}"]}
    html = _decode(raw, ctype)
    host = (urlparse(cur).hostname or "").lower()
    if ctype.startswith(("text/html", "application/xhtml")) or "<html" in html[:500].lower():
        ex = extract(html, cur)
    else:
        ex = {"title": "", "text": html.strip(), "links": [], "iframes": 0, "popups": 0}
    cg = content_gate(ex, html, host)
    if not cg.ok and not trusted_host(host):
        return {"ok": False, "refused": True, "why": cg.reasons, "score_url": gate.score, "score_content": cg.score}
    return {"ok": True, "url": cur, "status": status, "title": ex["title"], "text": ex["text"], "links": ex["links"], "html_len": len(html), "thin": len(ex["text"]) < 300,
            "score_url": gate.score, "score_content": cg.score, "notes": cg.reasons}


# ------------------------------------------------------------------ JS pages (optional)
class JSUnavailable(Exception):
    pass


_pw = {"play": None, "browser": None}
_sem = None


async def _browser():
    try:
        from playwright.async_api import async_playwright  # noqa: PLC0415
    except ImportError as exc:
        raise JSUnavailable("JS rendering is not installed (build the image with WITH_BROWSER=1)") from exc
    if _pw["browser"] is None or not _pw["browser"].is_connected():
        if _pw["play"] is None:
            _pw["play"] = await async_playwright().start()
        _pw["browser"] = await _pw["play"].chromium.launch(args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu", "--disable-extensions", "--disable-background-networking",
                                                                  "--disable-sync", "--no-first-run", "--mute-audio", "--disable-webrtc"])
    return _pw["browser"]


async def render_js(url: str) -> dict:
    """Open the page in a throw-away context and return its visible text. Every request of the page goes through the gates."""
    global _sem
    _sem = _sem or asyncio.Semaphore(2)
    async with _sem:
        browser = await _browser()
        ctx = await browser.new_context(java_script_enabled=True, accept_downloads=False, service_workers="block", user_agent=UA, viewport={"width": 1280, "height": 800}, permissions=[],
                                        ignore_https_errors=False, locale="en-US")
        try:
            page = await ctx.new_page()

            async def gate(route):
                req = route.request
                host = (urlparse(req.url).hostname or "").lower()
                if req.resource_type in {"image", "media", "font", "websocket", "eventsource", "manifest"}:
                    return await route.abort()
                v = url_gate(req.url, subresource=req.url != url)
                if not v.ok or not (allow_private() or await resolves_public(host)):
                    return await route.abort()
                await route.continue_()

            await page.route("**/*", gate)
            page.on("dialog", lambda d: asyncio.ensure_future(d.dismiss()))
            page.on("popup", lambda p: asyncio.ensure_future(p.close()))
            page.on("download", lambda d: asyncio.ensure_future(d.cancel()))
            await page.goto(url, wait_until="domcontentloaded", timeout=20000)
            try:
                await page.wait_for_load_state("networkidle", timeout=6000)
            except Exception:  # noqa: BLE001
                pass
            html = await page.content()
            title = await page.title()
            text = await page.evaluate("document.body ? document.body.innerText : ''")
            links = await page.evaluate("Array.from(document.querySelectorAll('a[href]')).slice(0,60).map(a=>({text:(a.innerText||'').trim().slice(0,90),href:a.href}))")
            final = page.url
        finally:
            await ctx.close()
    lines, seen = [], set()
    for raw in (text or "").splitlines():
        line = " ".join(raw.split())
        if len(line) >= 3 and line not in seen:
            seen.add(line)
            lines.append(line)
    links = [l for l in links if l.get("text") and urlparse(l.get("href", "")).scheme in {"http", "https"}][:40]
    return {"title": (title or "")[:200], "text": "\n".join(lines), "links": links, "url": final, "html": html[:300000]}


async def read(url: str, *, js: str | bool = "auto", max_chars: int = 6000) -> dict:
    """The one call of the server: gates -> static fetch -> (JS render when asked / the page is empty without JS) -> content gate -> trimmed text."""
    max_chars = max(500, min(int(max_chars or 6000), 20000))
    res = await fetch_static(url)
    notes: list[str] = []
    want_js = js is True or str(js).lower() in {"true", "1", "yes", "on"}
    auto_js = str(js).lower() == "auto"
    if res.get("ok") and (want_js or (auto_js and res.get("thin"))):
        try:
            page = await render_js(res["url"])
            ex = {"title": page["title"], "text": page["text"], "links": page["links"], "iframes": 0, "popups": 0}
            host = (urlparse(page["url"]).hostname or "").lower()
            cg = content_gate(ex, page["html"], host)
            if cg.ok or trusted_host(host):
                res.update({"title": page["title"] or res["title"], "text": page["text"], "links": page["links"], "url": page["url"], "score_content": cg.score, "js": True})
            else:
                return {"ok": False, "refused": True, "why": cg.reasons, "score_url": res.get("score_url"), "score_content": cg.score}
        except JSUnavailable as exc:
            notes.append(str(exc))
        except Exception as exc:  # noqa: BLE001
            notes.append(f"JS render failed: {exc.__class__.__name__}")
    elif not res.get("ok") and want_js and res.get("refused") is False:
        notes.append("static fetch failed")
    if res.get("ok"):
        text = res["text"]
        res["text"] = text[:max_chars] + (f"\n…[{len(text) - max_chars} characters cut]" if len(text) > max_chars else "")
        res["links"] = res.get("links", [])[:20]
        res["notes"] = (res.get("notes") or []) + notes
        res.pop("html_len", None)
    elif notes:
        res["notes"] = notes
    return res
