"""Verified domains of the sandbox (1.19.7): `.sb domain add example.com` (owner only).

What happens when the owner adds a domain
  1. a sub-domain of a domain that already has SSL needs NOTHING (it is served and gets its own certificate on the first visit) -> status "covered";
  2. otherwise the DNS is looked at (A record = this server? MX = this server? does a random sub-domain answer too = wildcard?);
  3. the TLS proxy (Caddy, on-demand TLS) is asked for the certificate RIGHT NOW (one TLS handshake with that name) - no waiting for the first visitor;
  4. the domain is saved (data volume) and used for preview links (`https://domain/p/<secret>/`) and, if its MX points here, for `.mail`.

Caddy asks `/tls/ask?domain=x` before it orders any certificate; only a registered domain (or a sub-domain of one) is approved, so nobody can make the server order certificates for foreign names.

    SANDBOX_PUBLIC_IP   the public IPv4 of this server (empty = found through api.ipify.org)           SANDBOX_TLS_HOST   host[:port] of the TLS proxy inside the compose network (caddy:443)
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import secrets
import socket
import ssl
import threading
import time
from pathlib import Path

LABEL = r"(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)"
DOMAIN_RE = re.compile(rf"^(?=.{{4,253}}$)(?:{LABEL}\.)+(?=[a-z0-9-]*[a-z])[a-z0-9-]{{2,24}}$")
IP_RE = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}$")
FORBIDDEN_SUFFIX = (".local", ".localhost", ".internal", ".lan", ".home", ".arpa", ".test", ".invalid", ".example")


def normalize(name: str) -> str:
    n = (name or "").strip().lower()
    n = re.sub(r"^[a-z]+://", "", n).split("/")[0].split(":")[0].strip(".")
    if n.startswith("*."):
        n = n[2:]
    return n


def valid(name: str) -> bool:
    return bool(DOMAIN_RE.match(name)) and not IP_RE.match(name) and not name.endswith(FORBIDDEN_SUFFIX)


def is_sub_of(name: str, parent: str) -> bool:
    return name == parent or name.endswith("." + parent)


class Registry:
    """A tiny JSON file in the data volume. {name: {added, ssl, ssl_error, mail, wild_mx, a_ok, checked, covered_by}}."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def _load(self) -> dict:
        try:
            return json.loads(self.path.read_text("utf-8"))
        except (OSError, ValueError):
            return {}

    def _save(self, data: dict) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), "utf-8")
        os.replace(tmp, self.path)

    def all(self) -> dict[str, dict]:
        with self._lock:
            return self._load()

    def get(self, name: str) -> dict | None:
        return self.all().get(name)

    def put(self, name: str, **fields) -> dict:
        with self._lock:
            data = self._load()
            row = data.setdefault(name, {"added": time.time()})
            row.update(fields)
            self._save(data)
            return dict(row)

    def remove(self, name: str) -> bool:
        with self._lock:
            data = self._load()
            if name not in data:
                return False
            data.pop(name)
            self._save(data)
            return True

    # ------------------------------------------------------------ rules
    def covering(self, name: str) -> str | None:
        """A REGISTERED PARENT (not the name itself) that already has SSL: then `name` needs nothing."""
        best = None
        for d, row in self.all().items():
            if d != name and is_sub_of(name, d) and row.get("ssl") and (best is None or len(d) < len(best)):
                best = d
        return best

    def allowed(self, name: str) -> bool:
        """Does the TLS proxy / the server answer for this host?  A registered domain or any sub-domain of one."""
        name = normalize(name)
        return valid(name) and any(is_sub_of(name, d) for d in self.all())

    def mail_domains(self) -> list[dict]:
        return [{"name": d, "wild_mx": bool(r.get("wild_mx"))} for d, r in sorted(self.all().items()) if r.get("mail")]

    def ssl_domains(self) -> list[str]:
        return [d for d, r in sorted(self.all().items()) if r.get("ssl")]

    def public_base(self) -> str:
        """https://<one of the domains that has SSL> (random, so previews spread over the domains), or ''."""
        ready = self.ssl_domains()
        return "https://" + secrets.choice(ready) if ready else ""


# ---------------------------------------------------------------- DNS / TLS (all of it is best effort and never raises)
_ip_cache: dict = {"ip": "", "at": 0.0}


async def server_ip() -> str:
    env = os.getenv("SANDBOX_PUBLIC_IP", "").strip()
    if env:
        return env
    if _ip_cache["ip"] and time.time() - _ip_cache["at"] < 3600:
        return _ip_cache["ip"]
    try:
        import aiohttp

        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=6)) as s:
            async with s.get("https://api.ipify.org") as r:
                ip = (await r.text()).strip()
        if IP_RE.match(ip):
            _ip_cache.update(ip=ip, at=time.time())
            return ip
    except Exception:  # noqa: BLE001
        pass
    return ""


async def resolve_a(name: str) -> list[str]:
    try:
        infos = await asyncio.get_running_loop().getaddrinfo(name, None, family=socket.AF_INET, type=socket.SOCK_STREAM)
        return sorted({i[4][0] for i in infos})
    except OSError:
        return []


async def resolve_mx(name: str) -> list[tuple[int, str]]:
    try:
        import dns.asyncresolver  # noqa: PLC0415

        answers = await dns.asyncresolver.resolve(name, "MX", lifetime=6)
        return sorted((int(r.preference), str(r.exchange).rstrip(".").lower()) for r in answers)
    except Exception:  # noqa: BLE001
        return []


async def dns_report(name: str, ip: str) -> dict:
    """a_ok: the name points to this server (None = we do not know our own IP);  mx_ok: some MX host of the name points to this server;
    wild_a / wild_mx: a random sub-domain answers too (needed for mail addresses with a sub-domain label)."""
    probe = "zz" + secrets.token_hex(3) + "." + name
    a, mx, wa, wmx = await asyncio.gather(resolve_a(name), resolve_mx(name), resolve_a(probe), resolve_mx(probe))

    async def points_here(hosts: list[tuple[int, str]]) -> bool:
        for _, host in hosts:
            ips = a if host == name else await resolve_a(host)
            if (ip and ip in ips) or (not ip and ips):
                return True
        return False

    return {"ip": ip, "a": a, "a_ok": (ip in a) if (ip and a) else (False if not a else None), "mx": [h for _, h in mx], "mx_ok": await points_here(mx),
            "wild_a": bool(wa) and ((ip in wa) if ip else True), "wild_mx": bool(wmx) and await points_here(wmx)}


async def warm_tls(name: str, timeout: float = 75.0) -> tuple[bool, str]:
    """One TLS handshake with that name through the proxy: Caddy orders the certificate during it (on-demand TLS), so the cert exists when this returns.
    The handshake VERIFIES the certificate (public CA chain + the name), so `True` means a real, valid certificate."""
    host = os.getenv("SANDBOX_TLS_HOST", "").strip()
    if not host:
        return False, "no TLS proxy configured (SANDBOX_TLS_HOST) - use the docker-compose of sandbox_server/ (Caddy)"
    h, _, p = host.partition(":")
    ctx = ssl.create_default_context()
    try:
        reader, writer = await asyncio.wait_for(asyncio.open_connection(h, int(p or 443), ssl=ctx, server_hostname=name), timeout)
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:  # noqa: BLE001
            pass
        return True, ""
    except asyncio.TimeoutError:
        return False, f"the certificate was not ready after {int(timeout)} s"
    except ssl.SSLError as exc:
        return False, "no valid certificate yet: " + str(exc)[:150]
    except OSError as exc:
        return False, f"the TLS proxy is not reachable: {exc.__class__.__name__}"


def dns_hint(name: str, ip: str) -> str:
    ip = ip or "<IP-سرور>"
    return (f"رکوردهای لازم:\n  A   {name}   {ip}\n  A   *.{name}   {ip}      (برای زیردامنه‌ها)\n"
            f"  MX  {name}   10 {name}      (برای .mail)\n  MX  *.{name}   10 {name}  (برای ایمیل با زیردامنهٔ تصادفی)")


async def add_or_check(reg: Registry, raw: str, *, warm: bool = True) -> dict:
    """The whole `.sb domain add` / `check` flow -> a report for the bot."""
    name = normalize(raw)
    if not valid(name):
        return {"ok": False, "error": "نام دامنه معتبر نیست (مثال: example.com)"}
    parent = reg.covering(name)
    if parent:
        reg.put(name, covered_by=parent)
        return {"ok": True, "status": "covered", "domain": name, "by": parent,
                "note": f"{name} زیردامنهٔ {parent} است که SSL دارد؛ کاری لازم نیست."}
    ip = await server_ip()
    report = await dns_report(name, ip)
    row = reg.put(name, a_ok=report["a_ok"], mx_ok=report["mx_ok"], wild_mx=report["wild_mx"], mail=bool(report["mx_ok"]) or bool((reg.get(name) or {}).get("mail_forced")),
                  checked=time.time(), covered_by=None)
    ssl_ok, ssl_err = False, "DNS هنوز به این سرور نمی‌رسد"
    if report["a_ok"] is not False and warm:
        ssl_ok, ssl_err = await warm_tls(name)
    row = reg.put(name, ssl=ssl_ok, ssl_error=ssl_err if not ssl_ok else "")
    return {"ok": True, "status": "ready" if ssl_ok else "pending", "domain": name, "ssl": ssl_ok, "ssl_error": ssl_err, "dns": report, "mail": bool(row.get("mail")),
            "hint": "" if ssl_ok else dns_hint(name, ip)}
