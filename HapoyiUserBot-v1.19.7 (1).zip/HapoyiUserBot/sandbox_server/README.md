# Sandbox for `.sb` (your own server) — also verified domains + SSL and the mail of `.mail` (1.19.7)

The AI of the self-bot works here: it runs Linux commands and code, writes / edits files, unzips what you send, and gives the result back (a file, or the whole project as one zip).
The commands run **inside this container** - never on the machine / user that holds the bot and its Telegram session.

## 1. Start it (a server with Docker; any VPS, or the same machine as the bot)
```bash
cd sandbox_server
echo "SANDBOX_TOKEN=$(openssl rand -hex 24)" > .env      # the secret; keep it
docker compose up -d --build
curl http://127.0.0.1:8765/health                         # -> {"ok": true, ...}
```
Data lives in the Docker volume `sandbox_data` (it survives restarts). Limits (RAM 2 GB, 2 CPUs, 512 processes) are in `docker-compose.yml` - change them there.
The compose file starts two containers: the sandbox and **Caddy** (HTTPS for your verified domains, ports 80 / 443). Port 25 goes to the mail receiver of `.mail`. Optional in the `.env` next to the compose file: `SANDBOX_PUBLIC_IP=<public IPv4>`.

**Every account may use it (1.19.7).** The server runs as root with only `SETUID SETGID CHOWN KILL` and gives every account (session) its own unix user (uid 20000+): its folder is 0700, its commands run as that user (never root),
and the file API runs as that user too - an account cannot read / delete another account's files, nor read the server's environment (the token) or `.state/`. Per session: 4 commands at once, 2 GB, 3 apps.
`SANDBOX_ISOLATE=0` turns this off (then all sessions share one user - only for a sandbox that you alone use).

## 2. Tell the bot (the .env of the BOT, not of this folder)
```
SANDBOX_URL=http://127.0.0.1:8765
SANDBOX_TOKEN=<the same value as above>
```
Restart the bot, then in Telegram: `.sb status`.

## 3. The sandbox is on ANOTHER machine than the bot
Do not open port 8765 to the internet. Either
- SSH tunnel from the bot machine: `ssh -N -L 8765:127.0.0.1:8765 user@sandbox-server` (keep it with `autossh`/systemd) and keep `SANDBOX_URL=http://127.0.0.1:8765`, or
- put it behind a TLS reverse proxy (Caddy / nginx) and use `SANDBOX_URL=https://sandbox.example.com` - the token is the only lock, so use a long one.

## Domains + SSL (owner: `.sb domain add example.com`)
DNS first: `A example.com → <server IP>`, `A *.example.com → <server IP>`, `MX example.com 10 example.com`, `MX *.example.com 10 example.com`. Then `.sb domain add example.com`: the DNS is checked and the certificate is ordered at once
(Caddy on-demand TLS; `/tls/ask` approves only registered domains and their sub-domains). A sub-domain of a domain that already has SSL needs nothing. Previews come as `https://example.com/p/<secret>/`.
`.sb domain list | check <domain> | del <domain> | mail <domain> on|off`.

## Mail (`.mail`)
The SMTP receiver (`tempmail.py`) listens on 2525 (host port 25). It accepts a mail only for an address that an account made with `.mail`, keeps it 24 h (`SANDBOX_MAIL_TTL_HOURS`), 40 mails per address, text only.
A domain is used for mail when its MX points to this server (checked by `.sb domain add`; `.sb domain mail <domain> on` forces it).

## Use
```
.sb ساده‌ترین ربات تلگرام با aiogram بنویس، تستش کن و زیپ پروژه رو بده
(Reply on a zip)  .sb تو فایل config.py مقدار PORT رو بکن 9000 و زیپ رو برگردون
(send a gif with caption)  .sb سایزش رو کن ۳۲۰ پیکسل و حجمش رو کم کن
.sb sh ls -la          .sb get          .sb up (Reply on a file)          .sb reset
```
Each AI round counts against your daily AI quota like a normal question.

## What it can / cannot do
- Can: python / node / go / java / C builds, git, pip / npm (the container has internet), ffmpeg, imagemagick, gifsicle, zip, any Linux tool; files up to 200 MB (`SANDBOX_MAX_UPLOAD`).
- A single command is killed after its timeout (default 120 s, max 900 s). Installed packages and files stay until `.sb reset`.
- The workspace is per account (own unix user, mode 0700); the file API refuses paths (and symlinks) that leave it. The shell itself is free inside the container - that is the point - so keep secrets out of it.

## Reading sites safely (`.sb web <url>`, and the AI's `web` action)
The sandbox reads a page for the AI **without trusting it**: the address gets a reputation score (https, risky `.xyz/.top/...`, look-alike names, shorteners, spam words in the address; known news / reference sites are trusted),
the name is resolved by our own resolver that hands out **public addresses only** (no 127.x / 10.x / 192.168.x / 169.254.x, re-checked on every connect and every redirect hop), the page gets a quality score
(spam / gambling / adult phrases, link farms, pop-ups, auto-redirects, obfuscated scripts) and is refused below the limit. No cookies, 2 MB, text content only, 15 s.
- `SANDBOX_WEB_ALLOW=site1.com,site2.com` always allowed (still SSRF-protected) • `SANDBOX_WEB_BLOCK=bad.com` never • `SANDBOX_WEB_MIN_URL_SCORE=45` • `SANDBOX_WEB_MIN_CONTENT_SCORE=50` • `SANDBOX_WEB=0` switches it off.
- **JavaScript pages:** build with Chromium `docker compose build --build-arg WITH_BROWSER=1` (or put `WITH_BROWSER=1` in `.env`). Pages that are empty without JS are then rendered automatically; every request of the page goes
  through the same gates, downloads / pop-ups / dialogs / permissions / images / media / fonts / websockets are blocked, each page gets a throw-away browser context.
- **Hard guarantee for the network:** the code blocks private targets, but a firewall is the belt for these braces. On the Docker host: `iptables -I DOCKER-USER -s <container subnet> -d 10.0.0.0/8 -j DROP` (and the same for 172.16.0.0/12, 192.168.0.0/16, 169.254.0.0/16).

## What an AI can never do here
Shell commands written by the AI pass `guardrules.py` on the server (no `rm -rf /`, `sudo`, `docker`, `mount`, reverse shells, `curl | sh`, ssh ...). The owner's own `.sb sh` is not filtered (he typed it; it is a container); `.sb sh` of every other account passes the same rules.
Keep secrets out of the container: nothing of the bot (.env, sessions) is ever copied there by the bot.

## Preview links of apps (`.sb deploy`)
The app must listen on `$PORT`. `.sb deploy python3 -m http.server $PORT` returns a link like `https://sandbox.example.com/p/<secret>/`. The secret is the only lock, so treat the link as private; it expires after 6 hours
(`SANDBOX_DEPLOY_TTL`), at most 3 apps per account. Absolute asset paths (`/static/app.js`) work through a cookie set by the first request.
